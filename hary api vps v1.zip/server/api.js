__path = process.cwd()
//var favicon = require('serve-favicon');
var express = require('express');

const { cekKey, limitAdd, isLimit } = require('../database/db');
const { sleep } = require('../lib/function')
var creator = "HARY-IT"
var neoxr = "yntkts"
var zeks = "administrator"
var zeks2 = "apivinz"
var secure = require('ssl-express-www');
var cors = require('cors');
var fetch = require('node-fetch');
var cheerio = require('cheerio');
var request = require('request');
var zrapi = require("zrapi");
var dotenv = require("dotenv").config()
var fs = require('fs');
var { EmojiAPI } = require("emoji-api");
var emoji = new EmojiAPI();
var router  = express.Router();
var { TiktokDownloader } = require('../lib/tiktokdl.js')
var { color, bgcolor } = require(__path + '/lib/color.js');
var { fetchJson } = require(__path + '/lib/fetcher.js');
var options = require(__path + '/lib/options.js');
//const Apikey = apikey
var {
    Searchnabi,
    Gempa
} = require('./../lib');

var {
  pShadow,
  pRomantic,
  pSmoke,
  pBurnPapper,
  pNaruto,
  pLoveMsg,
  pMsgGrass,
  pGlitch,
  pDoubleHeart,
  pCoffeCup,
  pLoveText,
  pButterfly
} = require("./../lib/utils/photooxy");

var {
  ttdownloader,
  pinterest,
  fbdown,
  igstalk,
  igstory,
  igdl,
  linkwa,
  igDownloader
} = require("./../lib/anjay");

var {
  igStalk,
  igDownloader
} = require("./../lib/utils/igdown");

var {
  ytDonlodMp3,
  ytDonlodMp4,
  ytPlayMp3,
  ytPlayMp4,
  ytSearch
} = require("./../lib/utils/yt");

var { 
  Joox, 
  FB, 
  Tiktok
} = require("./../lib/utils/downloader");

var {
  Cuaca, 
  Lirik
} = require('./../lib/utils/information');

var {
  Base, 
  WPUser
} = require('./../lib/utils/tools');

var {
  fbDownloader,
  fbdown2
} = require('./../lib/utils/fbdl');

//var TiktokDownloader = require('./../lib/tiktokdl');

var tebakGambar = require('./../lib/utils/tebakGambar');

var cookie = process.env.COOCKIE
/*
* @Pesan Error
*/
loghandler = {
    notparam: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'Contact owner to get api key wa.me/6282273128721'
    },
    noturl: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter url'
    },
    notgcname: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan paramer gcname'
        },
    notgcicon: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan paramer gcicon'
        },
    notpp: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan paramer pp'
        },
    notbg: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan paramer bg'
        },
    notmemberCount: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan paramer memberCount'
        },
    notquery: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukkan parameter query'
        },
    notkata: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter kata'
    },
    nottext: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter text'
    },
    nottext2: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter text2'
    },
    notnabi: {
        status: false,
        creator: `${creator}`,
        code: 406, 
        message: 'masukan parameter nabi'
    },
    nottext3: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter text3'
    },
    nottheme: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter theme'
    },
    notusername: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter username'
    },
    notvalue: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'masukan parameter value'
    },
    invalidKey: {
        status: false,
        creator: `${creator}`,
        code: 406,
        message: 'Contact owner to get api key wa.me/6282273128721'
    },
    invalidlink: {
        status: false,
        creator: `${creator}`,
        message: 'error, mungkin link anda tidak valid.'
    },
    invalidkata: {
        status: false,
        creator: `${creator}`,
        message: 'error, mungkin kata tidak ada dalam api.'
    },
    error: {
        status: false,
        creator: `${creator}`,
        message: '404 ERROR'
    }
}

/* 
Akhir Pesan Error
*/

//router.use(favicon(__path + "/views/favicon.ico"));

const listkey = ["iren", "rina", "hary"];

/* ======================================= My Project Area HARY-IT =============================================================*/


router.get('/download/ytmp3', async(req, res, next) => {let apikey = req.query.apikey
    if (!req.query.url) return res.status(400).send({ status: 400, message: 'url parameter cannot be empty' })
    
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
  const url = req.query.url;
  
  if(!url) return res.json(loghandler.noturl)
  if(!apikey) return res.json(loghandler.notparam)
  if(listkey.includes(apikey)){
  ytDonlodMp3(url)
    .then((result) => {
      res.json({
        status: true,
        code: 200,
        creator: `${creator}`,
        result
      })
    })
    .catch((error) => {
      console.log(error)
      res.json(error)
    });
    } else {
        res.json(loghandler.invalidKey)
    }
});

router.get('/download/ytmp4', async(req, res, next) => {let apikey = req.query.apikey
    if (!req.query.url) return res.status(400).send({ status: 400, message: 'url parameter cannot be empty' })
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
  const url = req.query.url;
  

  if(!url) return res.json(loghandler.noturl)
  if(!apikey) return res.json(loghandler.notparam)
  if(listkey.includes(apikey)){
  ytDonlodMp4(url)
    .then((result) => {
      res.json({
        status: true,
        code: 200,
        creator: `${creator}`,
        result
      })
    })
    .catch((error) => {
      res.json(error)
    });
    } else {
        res.json(loghandler.invalidKey)
    }
});

router.get('/nsfw/ahegao', async (req, res, next) => {
          let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {

  const ahegao = JSON.parse(fs.readFileSync(__path +'/data/ahegao.json'));
  const randahegao = ahegao[Math.floor(Math.random() * ahegao.length)];
  data = await fetch(randahegao).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/ahegao.jpeg', data)
  res.sendFile(__path +'/tmp/ahegao.jpeg')
} 
});
router.get('/nsfw/ass', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
    

  const ass = JSON.parse(fs.readFileSync(__path +'/data/ass.json'));
  const randass = ass[Math.floor(Math.random() * ass.length)];
  data = await fetch(randass).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/ass.jpeg', data)
  res.sendFile(__path +'/tmp/ass.jpeg')
}
});

router.get('/nsfw/bdsm', async (req, res, next) => {
        
            // web resmi konanchan kadang err
    let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {

  const bdsm = JSON.parse(fs.readFileSync(__path +'/data/bdsm.json'));
  const randbdsm = bdsm[Math.floor(Math.random() * bdsm.length)];
  data = await fetch(randbdsm).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/bdsm.jpeg', data)
  res.sendFile(__path +'/tmp/bdsm.jpeg') 
}
});

router.get('/cecan', async (req, res, next) => {
         let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const bdsm = JSON.parse(fs.readFileSync(__path +'/data/cecan.json'));
  const randbdsm = bdsm[Math.floor(Math.random() * bdsm.length)];
  data = await fetch(randbdsm).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/bdsm.jpeg', data)
  res.sendFile(__path +'/tmp/bdsm.jpeg')
} 
})

router.get('/asupan/bocilmeresahkan', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    
{
       fetch(encodeURI(`https://raw.githubusercontent.com/MltrCyber/jan/main/bocil.json`))
        .then(response => response.json())
        .then(data => {
        var result = data;
        var result = data[Math.floor(Math.random() * data.length)];
             res.json({
                creator : `${creator}`,
                 result
             })
         })
         .catch(e => {
            res.json(loghandler.error)
})
}
})


router.get('/nsfw/blowjob', async (req, res, next) => {
         let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
             //web resmi konanhan kadang err
    {

  const blowjob = JSON.parse(fs.readFileSync(__path +'/data/blowjob.json'));
  const randblowjob = blowjob[Math.floor(Math.random() * blowjob.length)];
  data = await fetch(randblowjob).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/blowjob.jpeg', data)
  res.sendFile(__path +'/tmp/blowjob.jpeg')
}
})


router.get('/nsfw/cuckold', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const cuckold = JSON.parse(fs.readFileSync(__path +'/data/cuckold.json'));
  const randcuckold = cuckold[Math.floor(Math.random() * cuckold.length)];
  data = await fetch(randcuckold).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/cuckold.jpeg', data)
  res.sendFile(__path +'/tmp/cuckold.jpeg')
}
})

router.get('/nsfw/cum', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {     
    
  const cum = JSON.parse(fs.readFileSync(__path +'/data/cum.json'));
  const randcum = cum[Math.floor(Math.random() * cum.length)];
  data = await fetch(randcum).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/cum.jpeg', data)
  res.sendFile(__path +'/tmp/cum.jpeg')
} 
})

router.get('/nsfw/ero', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const ero = JSON.parse(fs.readFileSync(__path +'/data/ero.json'));
  const randero = ero[Math.floor(Math.random() * ero.length)];
  data = await fetch(randero).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/ero.jpeg', data)
  res.sendFile(__path +'/tmp/ero.jpeg')
}
})


router.get('/nsfw/femdom', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {

  const femdom = JSON.parse(fs.readFileSync(__path +'/data/femdom.json'));
  const randfemdom = femdom[Math.floor(Math.random() * femdom.length)];
  data = await fetch(randfemdom).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/femdom.jpeg', data)
  res.sendFile(__path +'/tmp/femdom.jpeg')
}
})

router.get('/nsfw/foot', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const foot = JSON.parse(fs.readFileSync(__path +'/data/foot.json'));
  const randfoot = foot[Math.floor(Math.random() * foot.length)];
  data = await fetch(randfoot).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/foot.jpeg', data)
  res.sendFile(__path +'/tmp/foot.jpeg')
} 
})

router.get('/nsfw/gangbang', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const gangbang = JSON.parse(fs.readFileSync(__path +'/data/gangbang.json'));
  const randgangbang = gangbang[Math.floor(Math.random() * gangbang.length)];
  data = await fetch(randgangbang).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/gangbang.jpeg', data)
  res.sendFile(__path +'/tmp/gangbang.jpeg')
} 
})

router.get('/nsfw/glasses', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const glasses = JSON.parse(fs.readFileSync(__path +'/data/glasses.json'));
  const randglasses = glasses[Math.floor(Math.random() * glasses.length)];
  data = await fetch(randglasses).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/glasses.jpeg', data)
  res.sendFile(__path +'/tmp/glasses.jpeg')
}
})

router.get('/nsfw/hentai', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const hentai = JSON.parse(fs.readFileSync(__path +'/data/hentai.json'));
  const randhentai = hentai[Math.floor(Math.random() * hentai.length)];
  data = await fetch(randhentai).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/hentai.jpeg', data)
  res.sendFile(__path +'/tmp/hentai.jpeg')
}
})

router.get('/nsfw/gifs', async (req, res, next) => {
     let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const gifs = JSON.parse(fs.readFileSync(__path +'/data/gifs.json'));
  const randgifs = gifs[Math.floor(Math.random() * gifs.length)];
  data = await fetch(randgifs).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/gifs.jpeg', data)
  res.sendFile(__path +'/tmp/gifs.jpeg')
}
})

router.get('/nsfw/jahy', async (req, res, next) => {
    let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const jahy = JSON.parse(fs.readFileSync(__path +'/data/jahy.json'));
  const randjahy = jahy[Math.floor(Math.random() * jahy.length)];
  data = await fetch(randjahy).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/jahy.jpeg', data)
  res.sendFile(__path +'/tmp/jahy.jpeg')
} 
})

router.get('/nsfw/manga', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const manga = JSON.parse(fs.readFileSync(__path +'/data/manga.json'));
  const randmanga = manga[Math.floor(Math.random() * manga.length)];
  data = await fetch(randmanga).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/manga.jpeg', data)
  res.sendFile(__path +'/tmp/manga.jpeg')
} 
})

router.get('/nsfw/masturbation', async (req, res, next) => {
      let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const masturbation = JSON.parse(fs.readFileSync(__path +'/data/masturbation.json'));
  const randmasturbation = masturbation[Math.floor(Math.random() * masturbation.length)];
  data = await fetch(randmasturbation).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/masturbation.jpeg', data)
  res.sendFile(__path +'/tmp/masturbation.jpeg')
}
})

router.get('/nsfw/neko', async (req, res, next) => {
         let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const neko = JSON.parse(fs.readFileSync(__path +'/data/neko.json'));
  const randneko = neko[Math.floor(Math.random() * neko.length)];
  data = await fetch(randneko).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/neko.jpeg', data)
  res.sendFile(__path +'/tmp/neko.jpeg')
}
})

router.get('/nsfw/orgy', async (req, res, next) => {
      let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const orgy = JSON.parse(fs.readFileSync(__path +'/data/orgy.json'));
  const randorgy = orgy[Math.floor(Math.random() * orgy.length)];
  data = await fetch(randorgy).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/orgy.jpeg', data)
  res.sendFile(__path +'/tmp/orgy.jpeg')
}
})

router.get('/nsfw/panties', async (req, res, next) => {
    let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const panties = JSON.parse(fs.readFileSync(__path +'/data/panties.json'));
  const randpanties = panties[Math.floor(Math.random() * panties.length)];
  data = await fetch(randpanties).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/panties.jpeg', data)
  res.sendFile(__path +'/tmp/panties.jpeg')
} 
})

router.get('/nsfw/pussy', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const pussy = JSON.parse(fs.readFileSync(__path +'/data/pussy.json'));
  const randpussy = pussy[Math.floor(Math.random() * pussy.length)];
  data = await fetch(randpussy).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/pussy.jpeg', data)
  res.sendFile(__path +'/tmp/pussy.jpeg')
}
})

router.get('/nsfw/neko2', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const neko2 = JSON.parse(fs.readFileSync(__path +'/data/neko2.json'));
  const randneko2 = neko2[Math.floor(Math.random() * neko2.length)];
  data = await fetch(randneko2).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/neko2.jpeg', data)
  res.sendFile(__path +'/tmp/neko2.jpeg')
}
})

router.get('/nsfw/tentacles', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {

  const tentacles = JSON.parse(fs.readFileSync(__path +'/data/tentacles.json'));
  const randtentacles = tentacles[Math.floor(Math.random() * tentacles.length)];
  data = await fetch(randtentacles).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/tentacles.jpeg', data)
  res.sendFile(__path +'/tmp/tentacles.jpeg')
}
})

router.get('/nsfw/thighs', async (req, res, next) => {
        let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {

  const thighs = JSON.parse(fs.readFileSync(__path +'/data/thighs.json'));
  const randthighs = thighs[Math.floor(Math.random() * thighs.length)];
  data = await fetch(randthighs).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/thighs.jpeg', data)
  res.sendFile(__path +'/tmp/thighs.jpeg')
} 
})

router.get('/nsfw/yuri', async (req, res, next) => {
       let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const yuri = JSON.parse(fs.readFileSync(__path +'/data/yuri.json'));
  const randyuri = yuri[Math.floor(Math.random() * yuri.length)];
  data = await fetch(randyuri).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/yuri.jpeg', data)
  res.sendFile(__path +'/tmp/yuri.jpeg')
}
})

router.get('/nsfw/zettai', async (req, res, next) => {
         let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const zettai = JSON.parse(fs.readFileSync(__path +'/data/zettai.json'));
  const randzettai = zettai[Math.floor(Math.random() * zettai.length)];
  data = await fetch(randzettai).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/zettai.jpeg', data)
  res.sendFile(__path +'/tmp/zettai.jpeg')
} 
})



router.get('/asupan', async (req, res, next) => {
  
  
   let apikey = req.query.apikey
    if (!apikey) return res.status(400).send({ status: 400, message: 'apikey parameter cannot be empty' })
    let check = await cekKey(apikey)
    if (!check) return res.status(404).send({ status: 404, message: `apikey ${apikey} not found, please register first.` })
    let limit = await isLimit(apikey);
    if (limit) return res.status(429).send({ status: 429, message: 'requests limit exceeded (100 req / day), call owner for an upgrade to premium' })
    limitAdd(apikey);
            
    {
  const Asupan = JSON.parse(fs.readFileSync(__path +'/data/asupantiktok.json'));
  const randAsupan = Asupan[Math.floor(Math.random() * Asupan.length)];
  data = await fetch(randAsupan).then(v => v.buffer())
  await fs.writeFileSync(__path +'/tmp/asupan.mp4', data)
  res.sendFile(__path +'/tmp/asupan.mp4')
  }  
});

















































const { nhdetail, nhpdf, nhsearch, nhpopular, nhlatest, nhrandom, doujindesu, doujinsearch, doujinlatest } = require('../features/animanga')
const { bonk, ship, welcome, welcome2, goodbye, goodbye2, rankcard, levelup, hornycard } = require('../features/creator') 
     
router.get('/nhentai', nhdetail)
router.get('/nhentaipdf', nhpdf)
router.get('/nhsearch', nhsearch)
router.get('/nhpopular', nhpopular)
router.get('/nhlatest', nhlatest)
router.get('/nhrandom', nhrandom)
router.get('/doujindesu', doujindesu)
router.get('/doudesusearch', doujinsearch)
router.get('/doudesulatest', doujinlatest)
     
router.get('/bonk', bonk)
router.get('/ship', ship)
router.get('/welcome', welcome)
router.get('/welcome2', welcome2)
router.get('/goodbye', goodbye) 
router.get('/goodbye2', goodbye2)
router.get('/rankcard', rankcard)
router.get('/levelup', levelup)
router.get('/hornycard', hornycard)
     
router.use(function (req, res, next) {
    if (res.statusCode == '200') {
        res.render('notfound', {
            layout: 'notfound'
        })
    }
})

module.exports = router
