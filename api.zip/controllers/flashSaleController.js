const mysql = require('mysql2/promise');
const { getConnection } = require('../config/config');

async function getFlashSaleProducts(req, res) {
  let connection;
  try {
    // Create a connection to the database
    connection = await getConnection();

    // Get the current time in Jakarta timezone
    const tz = 'Asia/Jakarta';
    const now = new Date().toLocaleString('en-US', { timeZone: tz });
    
    // Konversi tanggal ke format yang sesuai dengan MySQL
    const [month, day, year, hour, minute, second] = now.split(/\/|\s|:/);
    const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${hour}:${minute}:${second}`;
    
    // Query to get flash sale products
    const [flashSaleRows] = await connection.query(`
      SELECT * FROM tb_flash_sale WHERE expired_date > ?
      ORDER BY expired_date ASC
    `, [formattedDate]);

    const products = await Promise.all(flashSaleRows.map(async (fsRow) => {
      const paketid = fsRow.produkid;

      // Fetch product details based on paketid
      const [produkRows] = await connection.query(`
        SELECT * FROM tb_produk WHERE cuid = ? AND status = 1
      `, [paketid]);

      if (produkRows.length > 0) {
        const produkRow = produkRows[0];
        const kategori = produkRow.kategori;

        // Fetch category details
        const [kategoriRows] = await connection.query(`
          SELECT * FROM tb_kategori WHERE kategori = ?
        `, [kategori]);

        const kategori_imgku = kategoriRows.length > 0 ? kategoriRows[0].image : 'favicon.png';

        return {
          id: produkRow.cuid,
          kategori,
          image: kategori_imgku,
          title: produkRow.title,
          slug: produkRow.slug,
          harga_jual: produkRow.harga_jual,
          discount: fsRow.harga, // Assuming `harga` is the discount price
        };
      }

      return null; // Handle case where no product is found
    }));

    // Filter out any null values (products that were not found)
    const filteredProducts = products.filter(product => product !== null);

    // Return the products as JSON
    res.json(filteredProducts);
  } catch (error) {
    console.error('Error fetching flash sale products:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

module.exports = {
  getFlashSaleProducts
};