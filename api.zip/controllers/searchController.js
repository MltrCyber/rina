const { getConnection } = require('../config/config');

async function searchKategori(req, res) {
  const { term } = req.query;

  if (!term) {
    return res.status(400).json([]);
  }

  let connection;
  try {
    connection = await getConnection();
    const [rows] = await connection.query(
      'SELECT kategori, image, slug FROM tb_kategori WHERE parent = 1 AND status = 1 AND kategori LIKE ? ORDER BY kategori ASC',
      [`%${term}%`]
    );

    res.json(rows);
  } catch (error) {
    console.error('Database query error:', error);
    res.status(500).json({ error: 'Database error' });
  } finally {
    if (connection) {
      connection.end();
    }
  }
}

module.exports = { searchKategori };