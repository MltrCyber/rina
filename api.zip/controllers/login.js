
const { getConnection } = require('../config/config');


async function getUserByEmail(email) {
  const connection = await getConnection();
  const [rows] = await connection.execute('SELECT * FROM tb_user WHERE email = ?', [email]);
  connection.end();
  return rows[0];
}

module.exports = { getConnection, getUserByEmail };