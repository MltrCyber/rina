const jwt = require('jsonwebtoken');
const { getConnection } = require('../config/config');

const verifyToken = async (req, res, next) => {
  console.log('All cookies:', req.cookies);
  const token = req.cookies.token;

  if (!token) {
    console.log(token);
    return res.json({ error: true, author: 'HARY-IT', redirect: '/id/sign-in' });
  }

  let user;

  try {
    user = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.json({ error: true, author: 'HARY-IT', redirect: '/id/sign-in' });
  }

  const connection = await getConnection();
  const [rows] = await connection.execute('SELECT * FROM tb_user WHERE user = ?', [user.username]);

  if (!rows.length) {
    return res.json({ error: true, author: 'HARY-IT', redirect: '/id/sign-in' });
  }

  const hary = rows[0];
  const [balance] = await connection.execute('SELECT * FROM tb_balance WHERE userID = ?', [hary.cuid]);
  const balanceku = balance[0];
  const formattedBalance = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(balanceku.active);

  if (hary.status == 0) {
    return res.json({ error: true, author: 'HARY-IT', redirect: `/id/confirm/${hary.hary}` });
  }

  let Level;
  if (hary.level == 'superadmin' || hary.level == 'superuser') {
    Level = 'Admin';
  } else if (hary.level == 'reseller') {
    Level = 'Reseller';
  } else {
    Level = 'Member';
  }

  req.user = {
    user: hary.user,
    full_name: hary.full_name,
    email: hary.email,
    no_hp: hary.no_hp,
    level: Level,
    balance: formattedBalance
  };

  next();
};

module.exports = verifyToken;