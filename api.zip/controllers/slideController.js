const { getConnection } = require('../config/config');

async function getSlides(req, res) {
  let connection;
  try {
    connection = await getConnection();
    
    const [rows] = await connection.query('SELECT * FROM `tb_slide` WHERE status = 1 ORDER BY cuid DESC LIMIT 5');
    const [din] = await connection.query('SELECT dash FROM `tb_seo` WHERE cuid = 1');
    
    res.json({
      error: false,
      code: 200,
      message: "Success",
      author: "HARY-IT",
      cdn: din[0],
      data: rows
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    if (connection) {
      connection.end();
    }
  }
}

module.exports = { getSlides };