const mysql = require('mysql2/promise');

const dbConfig = {
  host: '47.250.81.132',
  user: 'hary', // Ganti dengan username database Anda
  password: 'hary', // Ganti dengan password database Anda
  database: 'next-js', // Ganti dengan nama database Anda
};

async function getConnection() {
  return await mysql.createConnection(dbConfig);
}

module.exports = { getConnection };