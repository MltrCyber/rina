const express = require('express');
const fs = require('fs');
require('dotenv').config();
const cookieParser = require('cookie-parser');
const hary = express();
const cors = require('cors');
hary.use(cookieParser());
const allowedOrigins = ['http://localhost', 'http://localhost:80'];

const corsOptions = {
  origin: function (origin, callback) {
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true
};
hary.use(cors(corsOptions));

hary.use(express.json());
const banner = require('./func/banner');
const searchRouter = require('./func/search');
const authRouter = require('./func/confirm');
const flashSaleRouter = require('./func/flashsale');
const categoryRoutes = require('./func/game');
const flashSaleRoutes = require('./func/getflashsale');
const paymentchannel = require('./func/paymentchannel');
const populer = require('./func/populer');
const getData = require('./func/produk');
const getDataProduk = require('./func/produkdata');
const profile = require('./func/profile');
const status = require('./func/status');
const rekomendasi = require('./func/rekomendasi');
const cari = require('./func/cari');
const authenticate = require('./func/sign-in');
const authRoutes = require('./func/sign-out');
const register = require('./func/sign-up');





// Membaca daftar domain yang diizinkan dari file JSON
let allowedDomains = [];

// Fungsi untuk memuat domain dari file JSON
const loadAllowedDomains = () => {
  const data = fs.readFileSync('config.json');
  const jsonData = JSON.parse(data);
  allowedDomains = jsonData.allowedDomains;
};

// Memuat domain saat server dimulai
loadAllowedDomains();

// Fungsi untuk mengecek akses
const checkAccess = (req) => {
  const domain = req.headers['origin'];
  return allowedDomains.includes(domain);
};

// Fungsi untuk menampilkan pesan error
const showError = (res) => {
  res.status(403).json({
    error: true,
    code: 403,
    message: "You don't have permission to access resources on this server."
  });
};

/*
// Middleware untuk mengecek akses
hary.use((req, res, next) => {
  if (!checkAccess(req)) {
    showError(res);
  } else {
    next();
  }
});
*/

// Route untuk sukses
hary.get('/', (req, res) => {
  res.json({ 
    status: true,
    message: 'Success!',
    author: 'HARY-IT',
    data:[
        { 
          name: 'HARY-IT' ,
          domain: 'haryonokudadiri.id',
          status: 'Active',
          expired: 'Never'
        }
    ]
    });
});
hary.use((req, res, next) => {
  console.log(`Received request: ${req.method} ${req.url}`);
  next();
});
hary.use('/api/banner', banner);
hary.use('/api/cari', searchRouter);
hary.use('/api', authRouter); //api/confirm post
hary.use('/api/flashsale', flashSaleRouter);
hary.use('/api/game', categoryRoutes);
hary.use('/api/getflashsale', flashSaleRoutes);
hary.use('/api/paymentchannel', paymentchannel);
hary.use('/api/populer', populer);
hary.post('/api/produk', getData);
hary.get('/api/produk/data', getDataProduk);
hary.use('/api/profile', profile);
hary.use('/api/status', status);
hary.use('/api/rekomendasi', rekomendasi);
hary.use('/api/search', cari);
hary.post('/api/sign-in', authenticate, (req, res) => {
  res.json({ success: true, redirect: '/id/dashboard', message: 'Login berhasil' });
});
hary.use('/api/sign-out', authRoutes);
hary.use('/api/sign-up', register);




















hary.use((req, res, next) => {
  res.status(404).json({
      status: false,
      author: 'HARY-IT',
      message: 'kembalilah ke jalan yang benar'
  });
});
// Menjalankan server
const PORT = process.env.PORT || 3000;
hary.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});