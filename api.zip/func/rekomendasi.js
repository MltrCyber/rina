// routes/kategori.js

const express = require('express');
const router = express.Router();
const mysql = require('mysql2/promise');
const { getConnection } = require('../config/config');

router.get('/', async (req, res) => {
  try {
    const connection = await getConnection();

    const [rows] = await connection.execute(
      'SELECT * FROM tb_kategori WHERE rekomendasi = 1 AND status = 1'
    );

    await connection.end();
    res.json(rows);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

module.exports = router;