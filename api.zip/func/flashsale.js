const express = require('express');
const { getFlashSaleProducts } = require('../controllers/flashSaleController');

const router = express.Router();

// Rute untuk mendapatkan produk flash sale
router.get('/', getFlashSaleProducts);

module.exports = router;