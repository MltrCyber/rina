const express = require('express');
const router = express.Router();
const { getConnection } = require('../config/config');

router.get('/', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    
    // Ambil data kategori
    const [rows] = await connection.execute(
      'SELECT * FROM tb_kategori WHERE status = 1 ORDER BY visitor DESC'
    );

    // Ambil semua data jenis dalam satu query
    const [allJenis] = await connection.execute(
      'SELECT * FROM tb_jenis WHERE status = 1'
    );

    // Buat map untuk mempercepat pencarian jenis
    const jenisMap = new Map(allJenis.map(jenis => [jenis.cuid, jenis.jenis]));

    // Mapping hasil
    const result = rows.map(row => ({
      cuid: row.cuid,
      slug: row.slug,
      kategori: row.kategori,
      cekID: row.cekID,
      image: row.image,
      parent: row.parent,
      bantuan: row.bantuan,
      subtitle: row.subtitle,
      subimage: row.subimage,
      populer: Boolean(row.populer),
      sort: row.sort,
      created_date: row.created_date,
      user: row.user,
      status: Boolean(row.status),
      owner: row.owner,
      rekomendasi: Boolean(row.rekomendasi),
      banner: row.banner,
      visitor: row.visitor,
      categoryName: jenisMap.get(row.parent) || null,
      deskripsi: row.deskripsi,
    }));

    res.json({
      error: false,
      code: 200,
      message: "Success",
      author: "HARY-IT",
      data: result
    });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({
      error: true,
      code: 500,
      message: "Internal Server Error",
      author: "HARY-IT",
      data: null
    });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
});

module.exports = router;