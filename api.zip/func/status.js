const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

router.get('/', (req, res) => {
  const token = req.cookies.token;

  if (!token) {
    console.log('No token found');
    return res.json({ status: false, author: 'HARY-IT', redirect: '/id/sign-in' });
  }

  try {
    // Verifikasi token
    jwt.verify(token, process.env.JWT_SECRET);
    return res.json({ status: true, author: 'HARY-IT' });
  } catch (error) {
    console.log('Invalid token');
    return res.json({ status: false, author: 'HARY-IT', redirect: '/id/sign-in' });
  }
});

module.exports = router;