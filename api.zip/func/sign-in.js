const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../controllers/login'); // import database connection

const JWT_SECRET = process.env.JWT_SECRET;

async function authenticate(req, res, next) {
  

  const { email, password } = req.body;
  //console.log(email);
  //console.log(password); 
  try {
    const user = await db.getUserByEmail(email);
    if (!user || !user.pass) {
      return res.status(401).json({ success: false, message: 'User  not found or password not set' });
    }
    //console.log(user);

    const isPasswordValid = await bcrypt.compare(password, user.pass);
    if (!isPasswordValid) {
      return res.status(401).json({ success: false, message: 'Invalid password' });
    }
    //const token = sign({ pass: user.pass, username: user.user }, JWT_SECRET, { expiresIn: '1h' });
    const token = jwt.sign({ pass: user.pass, username: user.user }, JWT_SECRET, { expiresIn: '1h' });
    res.cookie('token', token, {
      httpOnly: true,
      secure: false, // Set to true if using HTTPS
      sameSite: 'lax',
      maxAge: 36000000,
      path: '/',
    });
  
    next();
    console.log('Response headers:', res.getHeaders());
  } catch (error) {
    console.error('Error occurred:', error);
    res.status(500).json({ success: false, message: 'Internal server error' });
  }
}

module.exports = authenticate;