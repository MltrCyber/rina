// File: routes/kategoriRoutes.js

const express = require('express');
const router = express.Router();
const { getConnection } = require('../config/config');
// Route handler
router.get('/', async (req, res) => {
  let connection;
  try {
    connection = await getConnection();
    const [rows] = await connection.execute(
      'SELECT * FROM tb_kategori WHERE populer = 1 AND status = 1'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ message: 'Terjadi kesalahan server' });
  } finally {
    if (connection) {
      await connection.end();
    }
  }
});

module.exports = router;