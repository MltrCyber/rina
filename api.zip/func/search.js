const express = require('express');
const router = express.Router();
const { searchKategori } = require('../controllers/searchController');

router.get('/', searchKategori);

module.exports = router;