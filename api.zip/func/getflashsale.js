const express = require('express');
const router = express.Router();
const { getConnection } = require('../config/config');

router.get('/', async (req, res) => {
    try {
        const connection = await getConnection();
        const [rows] = await connection.execute(`
            SELECT expired_date FROM tb_flash_sale
            WHERE expired_date > CONVERT_TZ(NOW(), '+00:00', '+07:00')
            ORDER BY expired_date ASC
            LIMIT 1
        `);
        await connection.end();

        if (rows.length > 0) {
            const isoDateTime = rows[0].expired_date; // Get the first expired_date
            const formattedDateTime = new Date(isoDateTime).toISOString().replace('T', ' ').slice(0, 19); // Format the date
            res.json({
                error: false,
                code: 200,
                message: 'Success',
                author: 'HARY-IT',
                dateTime: formattedDateTime
            });
        } else {
            res.json({ dateTime: null });
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router;