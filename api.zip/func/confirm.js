const express = require('express');
const { getConnection } = require('../config/config');
const { sign } = require('jsonwebtoken');
const { sendEmail } = require('../services/emailService');
const { sendOtp, generateOtp } = require('../services/otpService');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET;

router.post('/confirm', async (req, res) => {
  const { token, otp, req: requestType } = req.body;

  // Validate the input
  if (!token) {
    return res.status(400).json({ success: false, message: 'Token is required.' });
  }

  const connection = await getConnection();

  try {
    const [rows] = await connection.execute(
      'SELECT * FROM tb_user WHERE hary = ?',
      [token]
    );

    if (rows.length > 0) {
      const user = rows[0];

      if (!otp && !requestType) {
        return res.json({
          success: true,
          message: 'Token verification successful!',
          author: 'HARY-IT',
          data: {
            user: user.user,
            full_name: user.full_name,
            email: user.email,
            no_hp: user.no_hp
          },
        });
      } else if (requestType === 'resend') {
        const OTP_SEND_INTERVAL = 5 * 60 * 1000; // 5 minutes in milliseconds
        let lastOtpSentTime = user.lastOtpSentTime ;

        const currentTime = Date.now();

        if (lastOtpSentTime && (currentTime - lastOtpSentTime) < OTP_SEND_INTERVAL) {
          return res.json({
            success: false,
            message: 'Please wait before requesting a new OTP.',
            waitTime: Math.ceil((OTP_SEND_INTERVAL - (currentTime - lastOtpSentTime)) / 1000),
            author: 'HARY-IT',
          });
        }

        const otp = generateOtp();
        await connection.execute(
          'UPDATE tb_user SET lastOtpSentTime = ?, otp = ? WHERE user = ? AND cuid = ?',
          [Date.now(), otp, user.user, user.cuid]
        );

        await sendOtp(user, otp);
        await sendEmail(user, otp);

        return res.json({
          success: true,
          message: 'OTP has been sent!',
          author: 'HARY-IT',
        });
      } else {
        if (otp === user.otp) {
          const date = new Date();
          await connection.execute(
            'UPDATE tb_user SET status = ?, otp = ?, hary = ?, last_login = ? WHERE user = ? AND cuid = ?',
            [1, 0, 0, date, user.user, user.cuid]
          );

          const token = sign({ pass: user.pass, username: user.user }, JWT_SECRET, { expiresIn: '1h' });
          response.cookie('token', token, {
            httpOnly: true,
            secure: process.env.NODE_ENV !== 'development',
            sameSite: 'strict',
            maxAge: 3600, // 1 hour
            path: '/',
          });
          const response = res.json({
            success: true,
            message: 'OTP verification successful!',
            author: 'HARY-IT',
            data: {
              user: user.user,
              full_name: user.full_name,
              email: user.email,
              no_hp: user.no_hp,
              redirect: '/id/dashboard'
            },
          });

         

          return response;
        } else {
          return res.status(400).json({
            success: false,
            message: 'OTP is not valid!',
            author: 'HARY-IT',
          });
        }
      }
    } else {
      return res.status(400).json({ success: false, message: 'Token not found' });
    }
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({ success: false, message: 'Database error' });
  } finally {
    await connection.end();
  }
});

module.exports = router;