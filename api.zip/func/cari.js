// routes/recommendations.js

const express = require('express');
const router = express.Router();
const { getConnection } = require('../config/config');

router.get('/', async (req, res) => {
  try {
    const connection = await getConnection();

    const [rows] = await connection.query('SELECT * FROM `tb_kategori` WHERE rekomendasi = 1 AND status = 1 ORDER BY kategori ASC');

    await connection.end(); // Menutup koneksi

    res.json({
      error: false,
      code: 200,
      message: "Success",
      author: "HARY-IT",
      data: rows
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});

module.exports = router;