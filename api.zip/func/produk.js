const { getConnection } = require('../config/config');

async function getData(req, res) {
  console.log(req.body);
  const { slug } = req.body; // Get slug from the request body
  
  if (!slug) {
    return res.status(400).json({ message: 'Slug is required' });
  }

  const connection = await getConnection();

  try {
    // Fetch category data based on slug
    const [results] = await connection.query(
      'SELECT * FROM `tb_kategori` WHERE slug = ?',
      [slug]
    );

    if (results.length > 0) {
      // Update visitor count
      await connection.query(
        'UPDATE tb_kategori SET visitor = visitor + 1 WHERE slug = ?',
        [slug]
      );

      const hary = results[0];
      const [cdns] = await connection.query(
        'SELECT * FROM `tb_seo` WHERE cuid = ?',
        [1]
      );
      const cdnsku = cdns[0];

      return res.json({
        status: true,
        author: 'HARY-IT',
        message: 'Data fetched successfully',
        data: hary,
        config: cdnsku
      });
    } else {
      return res.status(404).json({ status: false, author: 'HARY-IT', message: 'Not found' });
    }
  } catch (error) {
    return res.status(500).json({ status: false, author: 'HARY-IT', message: error.message });
  }
}

module.exports = getData;