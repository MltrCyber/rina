const express = require('express');
const router = express.Router();
const verifyToken = require('../controllers/profile');

// Route yang memerlukan autentikasi
router.get('/', verifyToken, (req, res) => {
  res.json({
    success: true,
    message: 'User verification successful!',
    author: 'HARY-IT',
    data: req.user
  });
});

module.exports = router;