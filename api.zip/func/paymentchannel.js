const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  const products = [
    {
        "id": 29,
        "code": "BJPAY08-MIDGPY",
        "name": "GoPay",
        "description": "",
        "image": "https://client-cdn.bangjeff.com/shinjipedia/common/gopay-97355082.webp",
        "currency": "IDR",
        "feeAmount": 0,
        "feePercentage": 2.5,
        "minAmount": 1,
        "maxAmount": 99999999,
        "type": {
          "id": 1,
          "name": "ewallet",
          "description": "E-Wallet"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 19,
        "code": "BJPAY06-QRISFQ",
        "name": "QRIS SCAN",
        "description": "QRIS SCAN",
        "image": "https://cdn.bangjeff.com/d1e56bdd-a50a-4a63-a8e7-3217c6389236.webp",
        "currency": "IDR",
        "feeAmount": 0,
        "feePercentage": 1.44,
        "minAmount": 100,
        "maxAmount": 999999999,
        "type": {
          "id": 5,
          "name": "qris",
          "description": "QRIS"
        },
        "instruction": "",
        "featured": true
      },
      {
        "id": 18,
        "code": "BJPAY05-DANAX",
        "name": "DANA INSTANT",
        "description": "DANA INSTANT",
        "image": "https://cdn.bangjeff.com/248dc850-d3c9-4408-a5ca-d8fad7cbc665.webp",
        "currency": "IDR",
        "feeAmount": 0,
        "feePercentage": 2.44,
        "minAmount": 0,
        "maxAmount": 999999999,
        "type": {
          "id": 1,
          "name": "ewallet",
          "description": "E-Wallet"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 46,
        "code": "BJPAY00-MANVAPAY",
        "name": "Mandiri VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/396b2c3c-ea70-4dde-badc-c9731c30b63f.webp",
        "currency": "IDR",
        "feeAmount": 1850,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 48,
        "code": "BJPAY00-BCAVAPAY",
        "name": "BCA VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/b5edbd76-4f47-40be-86f3-8f4b084f721a.webp",
        "currency": "IDR",
        "feeAmount": 3600,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 44,
        "code": "BJPAY00-BRIVAPAY",
        "name": "BRI VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/aceb6a51-ee03-4556-8566-a09cd2f88a0b.webp",
        "currency": "IDR",
        "feeAmount": 1600,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 52,
        "code": "BJPAY00-PERVAPAY",
        "name": "Permata VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/e64cdaf2-fb7f-4db7-97e4-474627d05843.webp",
        "currency": "IDR",
        "feeAmount": 1500,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 58,
        "code": "BJPAY06-INDOMARETFAST",
        "name": "INDOMARET LINKITA",
        "description": "Silahkan datang ke Indomaret dan berikan informasi untuk pembayaran \"LINKITA\"",
        "image": "https://cdn.bangjeff.com/f5f420db-44d0-43df-b14f-a12b196e1093.webp",
        "currency": "IDR",
        "feeAmount": 1000,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 2500000,
        "type": {
          "id": 4,
          "name": "cstore",
          "description": "Convenience Store"
        },
        "instruction": "\u003Cp\u003ESilahkan datang ke Indomaret dan berikan informasi untuk pembayaran \"LINKITA\"\u003C/p\u003E",
        "featured": false
      },
      {
        "id": 57,
        "code": "BJPAY06-ALFAMARTFAST",
        "name": "ALFAMART LINKITA",
        "description": "Silahkan datang ke Alfamart dan berikan informasi untuk pembayaran \"LINKITA\"",
        "image": "https://cdn.bangjeff.com/126f7859-404a-4be0-8b8a-869d331c78b7.webp",
        "currency": "IDR",
        "feeAmount": 1000,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 2500000,
        "type": {
          "id": 4,
          "name": "cstore",
          "description": "Convenience Store"
        },
        "instruction": "\u003Cp\u003ESilahkan datang ke Alfamart dan berikan informasi untuk pembayaran \"LINKITA\"\u003C/p\u003E",
        "featured": false
      },
      {
        "id": 53,
        "code": "BJPAY00-BNCVAPAY",
        "name": "BNC VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/4da857da-9db1-4460-ac46-341fc0bd54f8.webp",
        "currency": "IDR",
        "feeAmount": 1600,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 49,
        "code": "BJPAY00-BNIVAPAY",
        "name": "BNI VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/eae6e79d-e035-49e6-be67-bde1563a407b.webp",
        "currency": "IDR",
        "feeAmount": 1700,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "",
        "featured": false
      },
      {
        "id": 47,
        "code": "BJPAY00-BSIVAPAY",
        "name": "BSI VA PAY",
        "description": "",
        "image": "https://cdn.bangjeff.com/eb0c9552-dd04-4d96-a2b1-7c25735abf70.webp",
        "currency": "IDR",
        "feeAmount": 1600,
        "feePercentage": 0,
        "minAmount": 10000,
        "maxAmount": 50000000,
        "type": {
          "id": 3,
          "name": "va",
          "description": "Virtual Account"
        },
        "instruction": "\u003Cp\u003ECara pembayaran BSI Virtual Account melalui mbanking :\u003C/p\u003E\u003Cp\u003E- Login mbanking\u003C/p\u003E\u003Cp\u003E- Pilih menu bayar\u003C/p\u003E\u003Cp\u003E- Pilih E-commerce \" Doku \"\u003C/p\u003E\u003Cp\u003E- Masukan nomor atau kode pembayaran yang ada di invoice\u003C/p\u003E\u003Cp\u003E- Klik selanjutnya\u003C/p\u003E\u003Cp\u003E- Masukan kembali kode pembayaran \u003C/p\u003E\u003Cp\u003E- Selesai\u003C/p\u003E",
        "featured": false
      }
  ];

  res.json({
    success: true,
    message: 'Data produk retrieved successfully',
    data: products,
  });
});

module.exports = router;