const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { getConnection } = require('../config/config');
const { sendEmail } = require('../services/emailSender');
const { sendWhatsApp } = require('../services/whatsappSender');

const router = express.Router();

const generateRandomString = (length) => {
  const characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

const generateOtp = () => {
  return Math.floor(100000 + Math.random() * 900000).toString();
};

router.post('/', async (req, res) => {
  const { user, pass, email, no_hp, full_name } = req.body;

  const connection = await getConnection();

  try {
    // Check if user, email, or no_hp already exists
    const [rows] = await connection.execute(
      'SELECT user, email, no_hp FROM tb_user WHERE user = ? OR email = ? OR no_hp = ?',
      [user, email, no_hp]
    );

    if (rows.length > 0) {
      const existingUser = rows[0];
      let errorMessage;

      if (existingUser.user === user) {
        errorMessage = 'Username sudah terpakai';
      } else if (existingUser.email === email) {
        errorMessage = 'Email sudah terdaftar';
      } else if (existingUser.no_hp === no_hp) {
        errorMessage = 'No HP sudah terdaftar';
      }

      return res.status(400).json({ success: false, message: errorMessage });
    }

    const otp = generateOtp();
    const confirmationToken = generateRandomString(32);

    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(pass, saltRounds);
    const date = new Date();

    const [userResult] = await connection.execute(
      'INSERT INTO tb_user (user, pass, email, no_hp, full_name, otp, hary, level, join_date, lastOtpSentTime, pinTrx,reff,uplineID,last_login,2fa) VALUES (?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [user, hashedPassword, email, no_hp, full_name, otp, confirmationToken, 'user', date, date, 0, 1,1,date,'']
    );

    const lastId = userResult.insertId;

    await connection.execute(
      'INSERT INTO tb_balance (userID, active, pending, payout, created_date) VALUES (?, ?, ?, ?, ?)',
      [lastId, 0, 0, 0, date]
    );

    // Send email with OTP and confirmation link
    await sendEmail(email, otp, confirmationToken);

    // Send WhatsApp message using Fonnte API
    await sendWhatsApp(no_hp, otp, full_name);

    // Create JWT token
    const token = jwt.sign({ username: user }, process.env.JWT_SECRET, { expiresIn: '1h' });

 

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV !== 'development',
      sameSite: 'strict',
      maxAge: 3600, // 1 hour
      path: '/',
    });
    res.json({
      success: true,
      message: 'User created successfully. Please check your email and WhatsApp for confirmation.',
      redirect: `/id/confirm/${confirmationToken}`,
    });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ success: false, message: 'Error creating user' });
  } finally {
    await connection.end();
  }
});

module.exports = router;