const { getConnection } = require('../config/config');

async function getProducts(req, res) {
    const connection = await getConnection();
    const { slug: cat } = req.query; // Get slug from the query parameters

    try {
        const [rows] = await connection.execute('SELECT * FROM tb_kategori WHERE slug = ?', [cat]);
        const hary = rows[0]; 
        const kategori = hary.kategori;

        const sqlPaket = `
            SELECT DISTINCT p.*
            FROM tb_paket p
            WHERE p.status = 1
            AND p.id IN (
                SELECT pl.paketid
                FROM tb_paketlayanan pl
                JOIN tb_produk pr ON pl.produkid = pr.cuid
                WHERE pl.title = ? AND pr.kategori = ?
            )
        `;

        const [paketResults] = await connection.query(sqlPaket, [cat, kategori]);
        const allData = [];

        for (const paket of paketResults) {
            if (!paket || !paket.nama) continue; // Skip if paket is not valid

            const paketid = paket.id;

            const sqlProducts = `
                SELECT p.cuid, p.slug, p.code, p.title, p.kategori, p.harga_jual, p.image, p.jenis, p.product_type, p.created_date
                FROM tb_produk p
                JOIN tb_paketlayanan pl ON p.cuid = pl.produkid
                WHERE pl.paketid = ? AND pl.title = ? AND p.kategori = ?
                ORDER BY p.harga_jual ASC
            `;

            const [productsResults] = await connection.query(sqlProducts, [paketid, cat, kategori]);

            const products = productsResults.map(product => ({
                id: product.cuid || '',
                code: product.code || '',
                name: product.title || '', 
                currency: 'IDR',
                price: product.harga_jual || 0,
                originalPrice: product.harga_jual || 0,
                sectionName: paket.nama || '',
                image: product.image || '',
                info: '',
                processTime: 0
            }));

            allData.push({
                name: paket.nama,
                variants: products
            });
        }

        // Return the response after all packages have been processed
        return res.json({
            success: true,
            message: "Data produk retrieved successfully",
            data: allData,
        });
    } catch (error) {
        console.error('Error retrieving data:', error);
        return res.status(500).json({
            error: true,
            code: 500,
            message: 'Error retrieving data produk',
            data: null
        });
    }
}

module.exports = getProducts;