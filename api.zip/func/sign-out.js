const express = require('express');
const router = express.Router();
const authMiddleware = require('../controllers/logout');

// Rute logout
router.post('/', authMiddleware, (req, res) => {
  // Hapus token dari cookie
  res.clearCookie('token');

  // Kembalikan response yang menunjukkan logout berhasil
  return res.status(200).json({ success: true, message: 'Logout successful.' });
});

module.exports = router;