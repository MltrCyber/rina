// utils/whatsappSender.js

const axios = require('axios');

const sendWhatsApp = async (no_hp, otp, full_name) => {
  const messageContent = `Hai ${full_name},\nTerimakasih Sudah Mendaftar.\nKode verifikasi anda adalah: ${otp}`;
  
  try {
    const response = await axios.post("https://api.fonnte.com/send", {
      target: no_hp,
      message: messageContent,
      countryCode: '62', // Country code for Indonesia
    }, {
      headers: {
        'Authorization': `${process.env.FONNTE_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });

    if (response.status === 200) {
      console.log('WhatsApp message sent successfully to:', no_hp);
    } else {
      console.error('Failed to send WhatsApp message:', response.data);
    }
  } catch (error) {
    console.error('Error sending WhatsApp message:', error.response ? error.response.data : error.message);
  }
};

module.exports = { sendWhatsApp };