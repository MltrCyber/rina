const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_SERVER,
  port: 587,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendEmail = async (email, otp, confirmationToken) => {
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Confirm Your Registration',
    text: `Your OTP is: ${otp}\nPlease confirm your registration by clicking the following link: ${process.env.BASE_URL}/id/confirm/${confirmationToken}`,
  };

  await transporter.sendMail(mailOptions);
  console.log('Email sent successfully to:', email);
};

module.exports = { sendEmail };