const axios = require('axios');

async function sendOtp(user, otp) {
  const messageContent = `Hai ${user.full_name},\nTerimakasih Sudah Mendaftar.\nKode verifikasi anda adalah: ${otp}`;
  
  try {
    const response = await axios.post('https://api.fonnte.com/send', {
      target: user.no_hp,
      message: messageContent,
      countryCode: '62',
    }, {
      headers: {
        'Authorization': `${process.env.FONNTE_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });
//console.log(response);
    console.log('WhatsApp message sent successfully to:', user.no_hp);
  } catch (error) {
    console.error('Failed to send WhatsApp message:', error.response.data);
  }
}

function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

module.exports = { sendOtp, generateOtp };