import type { Metadata } from "next";
import "./globals.css";
import HeadContent from "./harydata/head";



export const metadata: Metadata = {
  title: "HARY-IT - Make Your Heart Comfortable",
  description: "Make Your Heart Comfortable",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="biru" style={{ colorScheme: 'dark' }}>
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
      </body>
    </html>
  );
}