// config.ts
import mysql from 'mysql2/promise';

const dbConfig = {
  host: '47.250.81.132',
  user: 'hary', // Ganti dengan username database Anda
  password: 'hary', // Ganti dengan password database Anda
  database: 'next-js', // Ganti dengan nama database Anda
};

export const getConnection = async () => {
  const connection = await mysql.createConnection(dbConfig);
  return connection;
};
