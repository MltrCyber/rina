import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET as string;

export async function middleware(req: Request) {
  const token = req.cookies.get('token');

  if (!token) {
    return NextResponse.redirect('/id/sign-in');
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    // Menyimpan informasi pengguna di NextRequest
    (req as any).user = decoded; 
    return NextResponse.next();
  } catch (err) {
    return NextResponse.redirect('/id/sign-in');
  }
}

export const config = {
  matcher: ['/id/dashboard'], // Rute yang ingin dilindungi
};
