// app/id/confirm/page.tsx
"use client";
import { useState , useEffect} from 'react';
import ToastNotification from './../components/ToastNotification';
import ErrorMessage from './../components/ErrorMessage';
import NotFound from '/app/not-found';
const ConfirmPage = () => {
  const [otp, setOtp] = useState('');
  const [token, setToken] = useState<string | null>(null);
  const [hary, setRina] = useState<string | null>(null);
  const [notification, setNotification] = useState<{ type: string; message: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
const [loading, setLoading] = useState(false);
const [loadings, setLoadings] = useState(false);
const [memekrina, teterina] = useState(true); // Add loading state
  // Get token from URL
useEffect(() => {
  const path = window.location.pathname;
  const parts = path.split('/');
  const tokenFromUrl = parts[3]; // Get the token from the URL

  setToken(tokenFromUrl);
  
  // Call confirmOTP with the token to validate it
  if (tokenFromUrl) {
    confirmOTP(tokenFromUrl);
    //console.log('Kyaaa');
  }
}, []);



async function confirmOTP(token) {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/confirm`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ token }),
    });

     if (res.ok) {
        const data = await res.json();
        console.log('Response:', data);
        setRina(data.success !== false);
      } else {
        setRina(false);
      }
    } catch (error) {
      console.error('Error:', error);
      setRina(false);
    } finally {
      teterina(false); // Stop loading after the request completes
    }
  }

// Ensure to use this function within a component context
 if (memekrina) {
    return  <div className="bg-background flex items-center justify-center h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-blue-500 border-t-transparent rounded-full"></div>
    </div>; // Show loading while fetching
  }
if (!hary) return <NotFound />;


  




const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!token) return;

  console.log('Submitting...');
  
  setLoadings(true);


  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/confirm`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ token, otp }),
    });

    const data = await res.json();
    console.log('Response:', data);

    if (data.success) {
      setNotification({ type: 'success', message: 'OTP verification successful!' });
      window.location.href = data.data.redirect;
    } else {
      setError(data.message);
    }
  } catch (error) {
    setError('An error occurred. Please try again.');
  } finally {
    setLoadings(false);


    console.log('Loading finished:', loadings);
  }
};

const resendOtp = async () => {
  if (!token) return;

  console.log('Resending OTP...');
  setLoading(true);
  const req = 'resend';

  try {
    const resend = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/confirm`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ token, req }),
    });

    const data = await resend.json();
    if (data.success) {
      setNotification({ type: 'info', message: 'OTP has been resent!' });
      setError(null); // Reset error state if successful
    } else {
      setError(data.message);
     // alert(data.message);
    }

  } catch (error) {
    setError('Failed to resend OTP. Please try again.');
  } finally {
    setLoading(false);
    console.log('Loading finished for resend:', loading);
  }
};





  return (
    <>
    <body className="bg-background bg-gradient-theme text-foreground">
    <div className="absolute left-4 top-4 z-50">
  <a className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 h-9 w-9"
     type="button" style={{ outline:'none' }} href="/">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-x h-5 w-5">
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  </a>
</div>
 <div className="relative flex min-h-dvh shrink-0 justify-center pt-12 md:px-12 md:pt-0 lg:px-0">
                <div className="relative z-10 flex flex-1 flex-col justify-center bg-background/50 px-4 py-10 md:flex-none md:px-24">
                    <div className="mx-auto w-full max-w-md sm:px-4 md:w-[400px] md:px-0">
                        <div className="w-full max-w-md space-y-8">
                            <div>
                                <h2 className="mt-2 text-3xl font-bold tracking-tight text-foreground">OTP Verification</h2>
                                <p className="mt-2 text-sm text-foreground">Terima kasih sudah mendaftar! Sebelum memulai, mohon verifikasi akun kamu dengan kode OTP yang baru saja kami kirimkan ke Whatsapp/Email. Jika tidak menerima Whatsapp/Email, silakan hubungi Admin kami.</p>
                            </div>
 
   {notification && (
        <ToastNotification
          type={notification.type}
          message={notification.message}
          onClose={() => setNotification(null)}
        />
      )}
      {error && <ErrorMessage message={error} onClose={() => setError(null)} />}

   


                            <form className="mt-8 space-y-6"  onSubmit={handleSubmit} >
                                
                                <div className="-space-y-px rounded-md shadow-sm">
                                    <div>
                                        <label for="otp" className="block text-xs font-medium text-foreground pb-2">OTP</label>
                                        <div className="flex flex-col items-start">
                                            <input className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                            type="text" id="otp"
          value={otp}
          onChange={(e) => setOtp(e.target.value)}
          placeholder="6 Digits OTP Code"
          maxLength={6}  />
                                            <input type="hidden" name="token" value="async" />
                                        </div><span className="text-xs text-destructive"></span></div>
                                </div>
                                <div className="flex items-center gap-x-4">
  <button
    className={`items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground duration-300 ${loadings ? 'opacity-75 cursor-not-allowed' : 'hover:bg-primary/75'} group relative flex w-full`}
    type="submit"
    disabled={loadings}
    onClick={handleSubmit} // Pastikan untuk menambahkan event handler
  >
    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5 text-primary-foreground transition-colors group-hover:text-primary-foreground">
        <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5"></path>
      </svg>
    </span>
    {loadings ? (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-refresh-ccw mr-2 h-4 w-4 animate-spin">
        <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
        <path d="M3 3v5h5"></path>
        <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path>
        <path d="M16 16h5v5"></path>
      </svg>
    ) : null}
    {loadings ? 'Loading...' : 'Submit'}
  </button>
  
  <button
    id="resend-otp-btn"
    className={`items-center justify-center rounded-lg bg-muted px-4 py-2 text-sm font-medium text-primary-foreground duration-300 ${loading ? 'opacity-75 cursor-not-allowed' : 'hover:bg-muted/75'} group relative flex w-full`}
    type="submit"
    onClick={resendOtp}
    disabled={loading}
  >
    <span className="absolute inset-y-0 left-0 flex items-center pl-3">
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5 text-muted-foreground transition-colors group-hover:text-muted-foreground">
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"></path>
      </svg>
    </span>
    {loading ? (
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-refresh-ccw mr-2 h-4 w-4 animate-spin">
        <path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path>
        <path d="M3 3v5h5"></path>
        <path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path>
        <path d="M16 16h5v5"></path>
      </svg>
    ) : null}
    {loading ? 'Loading...' : 'Resend OTP Code'}
  </button>
</div>

                            </form>
                        </div>
                    </div>
                </div>
                <div className="hidden sm:block lg:flex-1 xl:relative">
                    <div className="size-full bg-primary"></div>
                </div>
            </div>



</body>
    
      
      
    </>
  );
};

export default ConfirmPage;
