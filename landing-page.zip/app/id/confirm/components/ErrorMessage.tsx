// app/id/confirm/components/ErrorMessage.tsx
import React from 'react';
import { useState , useEffect} from 'react';

interface ErrorMessageProps {
  message: string;
  onClose: () => void;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, onClose }) => {
   useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 1000); // Menutup setelah 1 detik

    return () => clearTimeout(timer); // Membersihkan timer jika komponen di-unmount
  }, [onClose]);
  return (
     <div style={{ position: 'fixed', zIndex: 9999, top: '16px', left: '16px', right: '16px', bottom: '16px', pointerEvents: 'none' }}>
  <div className="globalalerthary hide-after-5s" style={{ left: 0, right: 0, display: 'flex', position: 'absolute', top: 0, justifyContent: 'center' }}>
    <div className="alerthary" style={{ animation: '0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581' }}>
      <div className="alertrina">
        <div className="alertdina"></div>
        <div className="alertfeny">
          <div className="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" className="alertmasalalu">{message}</div>
    </div>
  </div>
</div>

  
  );
};

export default ErrorMessage;
