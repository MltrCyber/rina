"use client"; // Mark this as a client component
import { useEffect, useState } from 'react';
import React, { useRef } from 'react';
import NotFound from './../../not-found';
import Image from 'next/image';
import Navbar from './../../harydata/navbar';
import Footer from './../../harydata/footer';
const CategoryPage = ({ params }: { params: { id: string; slug: string } }) => {
  const { slug } = params; // Extract slug
  const [isNotFound, setIsNotFound] = useState(false); // State for 404
  const [hary, setHary] = useState(null);
  useEffect(() => {
    const postData = async () => {
      if (slug) {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/produk`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ slug }),
        });

        const data = await response.json();
        console.log(data);
        if (data.status === false) {
          setIsNotFound(true); // Set state to true if not found
        }
        setHary(data);
      }
    };

    postData();
  }, [slug]); // Dependency on 'slug'

  const [isOpenDesk, setIsOpenDesk] = useState(true);
  const toggleDropdownDesk = () => {
    setIsOpenDesk(!isOpenDesk);
  };



  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/Produk/Data?slug=${slug}`);
        const data: DataResponse = await response.json();

        if (data.success) {
          setProducts(data.data);
        } else {
          setError(data.message);
        }
      } catch (err) {
        setError('Failed to fetch products');
      } finally {
        setLoading(false);
      }
    };
    

    fetchProducts();
  }, []);


  const [selectedVariant, setSelectedVariant] = useState(null);

  const sectionRefs = useRef([]);
  const handleVariantSelect = (variantId) => {
    setSelectedVariant(variantId);
    
    // Cek elemen dengan id yang berbeda
    const ids = ['2', '3', '4'];
    let found = false;
  
    for (let id of ids) {
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        found = true;
        break; // Keluar dari loop setelah menemukan elemen
      }
    }
    // Jika tidak ada elemen yang ditemukan, Anda dapat menambahkan logika tambahan di sini
    if (!found) {
      console.log("Tidak ada elemen dengan id 2, 3, atau 4.");
    }
  };

  const [quantity, setQuantity] = useState(1);

  const handleIncrement = () => {
    setQuantity(quantity + 1);
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };


  const [selectedPayment, setSelectedPayment] = useState(null);
  const [isEwalletOpen, setIsEWalletOpen] = useState(false);
  const [isVirtualAccountOpen, setIsVirtualAccountOpen] = useState(false);
  const [isConvenienceStoreOpen, setIsConvenienceStoreOpen] = useState(false);
  const [paymentChannels, setPaymentChannels] = useState([]);

  // Fetch payment channels from the API
  useEffect(() => {
    const fetchPaymentChannels = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/paymentchannel`);
        const data = await response.json();
        if (!data.error) {
          setPaymentChannels(data.data); // Store the payment channels in state
        }
      } catch (error) {
        console.error('Error fetching payment channels:', error);
      }
    };

    fetchPaymentChannels();
  }, []);

  const handlePaymentSelect = (code) => {
    setSelectedPayment(code);
  };

  const handleEwalletToggle = () => {
    setIsEWalletOpen(!isEwalletOpen);
  };
  const handleEWalletToggle = () => {
    setIsEWalletOpen(!isEwalletOpen);
  };

  const handleVirtualAccountToggle = () => {
    setIsVirtualAccountOpen(!isVirtualAccountOpen);
  };

  const handleConvenienceStoreToggle = () => {
    setIsConvenienceStoreOpen(!isConvenienceStoreOpen);
  };
  
  const uniquePaymentChannels = [];
const seenDescriptions = new Set();
const filteredPaymentChannels = paymentChannels.filter(channel => channel.featured !== true);

filteredPaymentChannels.forEach((channel) => {
  if (!seenDescriptions.has(channel.type.description)) {
    seenDescriptions.add(channel.type.description);
    uniquePaymentChannels.push(channel);
  }
});


const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
    }).format(price);
  };

  if (!hary) {
    return  <div className="bg-background flex items-center justify-center h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-blue-500 border-t-transparent rounded-full"></div>
    </div>;
  }

  if (isNotFound) {
    return <NotFound />; // Render NotFound if state is true
  }

  return(
    <>
    <Navbar />
    <main className="relative bg-background">
    <div className="relative h-56 w-full bg-muted lg:h-[340px]">
        <Image alt="HARY-IT" fetchpriority="high" decoding="async" data-nimg="fill" className="object-cover object-center" sizes="80vw" 
        src={`${hary.config.dash}/assets/banner/${hary.data.banner}`}  width={100} height={100} style={{position: 'absolute', height: '100%', width: '100%', inset: '0px', color: 'transparent' }} /></div>
    <div className="bg-title-product flex min-h-32 w-full items-center border-y bg-muted lg:min-h-[160px]">
        <div className="container flex items-center gap-2">
            <div>
                <div className="flex items-start gap-4">
                    <div className="product-thumbnail-container relative -top-28"><Image alt="hary" loading="lazy" width="300" height="300" decoding="async" data-nimg="1" className="z-20 -mb-14 aspect-square w-32 rounded-2xl object-cover shadow-2xl md:-mb-20 md:w-60" sizes="100vw" srcset={`${hary.config.dash}/upload/${hary.data.image}`} style= {{color: 'transparent'}} /></div>
                </div>
            </div>
            <div className="py-4 sm:py-0">
                <h1 className="text-xs font-bold uppercase leading-7 tracking-wider sm:text-lg">{hary.data.kategori}</h1>
                <p className="text-xs font-medium sm:text-base/6">{hary.data.owner}</p>
                <div className="mt-4 flex flex-col gap-2 text-xs sm:flex-row sm:items-center sm:gap-8 sm:text-sm/6">
                    <div className="flex items-center gap-2">
                    <Image alt="HARY-IT" loading="lazy" width="150" height="150" decoding="async" data-nimg="1" className="size-8" srcset={`${hary.config.dash}/assets/media/lightning.gif`} src={`${hary.config.dash}/assets/media/lightning.gif`} style={{color: 'transparent' }} /><span>Proses Cepat</span></div>
                    <div className="flex items-center gap-2">
                        <Image alt="HARY-IT" loading="lazy" width="150" height="150" decoding="async" data-nimg="1" className="size-8" srcset={`${hary.config.dash}/assets/media/contact-support.gif`} src={`${hary.config.dash}/assets/media/contact-support.gif`} style={{color: 'transparent' }} /><span>Layanan Chat 24/7</span></div>
                    <div className="flex items-center gap-2">
                       
                        <Image alt="HARY-IT" loading="lazy" width="150" height="150" decoding="async" data-nimg="1" className="size-8" srcset={`${hary.config.dash}/assets/media/globe.gif`} src={`${hary.config.dash}/assets/media/globe.gif`} style={{color: 'transparent' }} /><span>Region Global</span></div>
                </div>
            </div>
        </div>
    </div>
    
    <div className="container relative mt-8 grid grid-cols-3 gap-4 md:gap-8">
    <div className="col-span-3 lg:col-span-1">
            <div className="sticky top-[90px] flex flex-col gap-8">
                <div className="flex flex-col gap-2">
                    <div className="space-y-2">
                        <button className="flex w-full items-center justify-between rounded-lg bg-card/75 px-4 py-2 text-left text-xs font-medium text-card-foreground focus:outline-none"  onClick={toggleDropdownDesk} type="button" aria-expanded="true"
                        data-headlessui-state="open" aria-controls="headlessui-disclosure-panel-:r1f:"><span>Deskripsi dan cara melakukan transaksi</span>
                            <svg 
          className={`lucide lucide-chevron-up h-5 w-5 transform ${isOpenDesk ? 'rotate-180' : ''}`} 
          xmlns="http://www.w3.org/2000/svg" 
          width="24" 
          height="24" 
          viewBox="0 0 24 24" 
          fill="none" 
          stroke="currentColor" 
          strokeWidth="2" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        >
          <path d="m18 15-6-6-6 6"></path>
        </svg>
                        </button>
                        {isOpenDesk && (
                        <div  data-headlessui-state={isOpenDesk ? "open" : "closed"}>
                            <div className="rounded-xl bg-card/50 px-4 pb-4 pt-2 shadow-2xl">
                                <div className="prose prose-sm my-3 text-xs text-foreground prose-p:!m-0">
                                    <div>
                                        <p>Beli top up ML diamond Mobile Legends &amp; Weekly Diamond Pass MLBB harga paling murah, aman, cepat, dan terpercaya.</p>
                                        <p></p>
                                        <p>⚠ Varian Mobile Legends Global hanya bisa dibeli oleh akun Mobile Legends Region Global</p>
                                        <p></p>
                                        <p>Cara topup :
                                            <br />1) Masukkan Data Akun
                                            <br />2) Pilih Nominal
                                            <br />3) Pilih Pembayaran
                                            <br />4) Masukkan Kode Promo (jika ada)
                                            <br />5) Isi Detail Kontak
                                            <br />6) Klik Pesan Sekarang dan lakukan Pembayaran
                                            <br />7) Selesai</p>
                                        <p></p>
                                        <p></p>
                                        <p><strong>Top up dan layanan CS OPEN 24 Jam Non Stop</strong></p>
                                        <p>
                                            <br /><strong>Layanan CS :</strong>
                                            </p>
                                    </div>
                                </div>
                            </div>
                        </div>  )}
                    </div>
                </div>
                <div className="hidden lg:block">
                    <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="Ulasan">
                        <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
                            <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-star h-4 w-4">
                                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                </svg>
                            </div>
                            <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Ulasan</h2></div>
                        <div className="p-4">
                            <div className="pb-4">
                                <div className="mb-6 flex flex-col items-center justify-center">
                                    <div className="flex items-center gap-2">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="h-10 w-10 flex-shrink-0 text-yellow-400">
                                            <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                            clip-rule="evenodd"></path>
                                        </svg>
                                        <div><span className="text-5xl font-semibold text-card-foreground">4.99</span><sub className="text-lg font-semibold text-card-foreground">/ 5.0</sub></div>
                                    </div>
                                    <p className="pt-2 text-center text-sm text-card-foreground">Pelanggan merasa puas dengan produk ini.
                                        <br /> Dari <span className="font-semibold">2.50jt</span> ulasan.</p>
                                </div>
                                <div>
                                    <h3 className="sr-only">Review data</h3>
                                    <dl className="space-y-3 text-card-foreground">
                                        <div className="flex items-center text-sm"><dt className="flex flex-1 items-center pl-1"><p className="text-text-color w-3 font-medium">5<span className="sr-only"> star reviews</span></p><div aria-hidden="true" className="ml-1 flex flex-1 items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-5 w-5 flex-shrink-0"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg><div className="relative ml-3 flex-1"><div className="h-3 rounded-[4px] border border-gray-200 bg-gray-100"></div><div className="absolute inset-y-0 rounded-[4px] border border-yellow-400 bg-yellow-400" style={{ width: '100%'}}></div></div></div></dt>
                                            <dd
                                            className="text-text-color ml-3 w-[3.75rem] text-right text-sm tabular-nums">2.50jt<span className="sr-only"> reviews</span></dd>
                                        </div>
                                        <div className="flex items-center text-sm"><dt className="flex flex-1 items-center pl-1"><p className="text-text-color w-3 font-medium">4<span className="sr-only"> star reviews</span></p><div aria-hidden="true" className="ml-1 flex flex-1 items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-5 w-5 flex-shrink-0"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg><div className="relative ml-3 flex-1"><div className="h-3 rounded-[4px] border border-gray-200 bg-gray-100"></div></div></div></dt>
                                            <dd
                                            className="text-text-color ml-3 w-[3.75rem] text-right text-sm tabular-nums">869<span className="sr-only"> reviews</span></dd>
                                        </div>
                                        <div className="flex items-center text-sm"><dt className="flex flex-1 items-center pl-1"><p className="text-text-color w-3 font-medium">3<span className="sr-only"> star reviews</span></p><div aria-hidden="true" className="ml-1 flex flex-1 items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-5 w-5 flex-shrink-0"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg><div className="relative ml-3 flex-1"><div className="h-3 rounded-[4px] border border-gray-200 bg-gray-100"></div></div></div></dt>
                                            <dd
                                            className="text-text-color ml-3 w-[3.75rem] text-right text-sm tabular-nums">128<span className="sr-only"> reviews</span></dd>
                                        </div>
                                        <div className="flex items-center text-sm"><dt className="flex flex-1 items-center pl-1"><p className="text-text-color w-3 font-medium">2<span className="sr-only"> star reviews</span></p><div aria-hidden="true" className="ml-1 flex flex-1 items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-5 w-5 flex-shrink-0"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg><div className="relative ml-3 flex-1"><div className="h-3 rounded-[4px] border border-gray-200 bg-gray-100"></div></div></div></dt>
                                            <dd
                                            className="text-text-color ml-3 w-[3.75rem] text-right text-sm tabular-nums">64<span className="sr-only"> reviews</span></dd>
                                        </div>
                                        <div className="flex items-center text-sm"><dt className="flex flex-1 items-center pl-1"><p className="text-text-color w-3 font-medium">1<span className="sr-only"> star reviews</span></p><div aria-hidden="true" className="ml-1 flex flex-1 items-center"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-5 w-5 flex-shrink-0"><path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z" clip-rule="evenodd"></path></svg><div className="relative ml-3 flex-1"><div className="h-3 rounded-[4px] border border-gray-200 bg-gray-100"></div></div></div></dt>
                                            <dd
                                            className="text-text-color ml-3 w-[3.75rem] text-right text-sm tabular-nums">242<span className="sr-only"> reviews</span></dd>
                                        </div>
                                    </dl>
                                </div>
                                <div className="mt-6">
                                    <p className="text-sm/6 text-card-foreground">Apakah kamu menyukai produk ini? Beri tahu kami dan calon pembeli lainnya tentang pengalamanmu.</p>
                                </div>
                            </div>
                            <div className="flex flex-col gap-y-4 divide-y divide-card-foreground/25 border-t border-card-foreground/25">
                                <div className="pt-4 text-card-foreground">
                                    <div className="flex items-center">
                                        <div className="w-full">
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <h4 className="mt-0.5 text-xs font-bold text-foreground">628******382</h4></div>
                                                <div className="flex items-center">
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-4 w-4 flex-shrink-0">
                                                        <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                                        clip-rule="evenodd"></path>
                                                    </svg>
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-4 w-4 flex-shrink-0">
                                                        <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                                        clip-rule="evenodd"></path>
                                                    </svg>
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-4 w-4 flex-shrink-0">
                                                        <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                                        clip-rule="evenodd"></path>
                                                    </svg>
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-4 w-4 flex-shrink-0">
                                                        <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                                        clip-rule="evenodd"></path>
                                                    </svg>
                                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="text-yellow-400 h-4 w-4 flex-shrink-0">
                                                        <path fill-rule="evenodd" d="M10.868 2.884c-.321-.772-1.415-.772-1.736 0l-1.83 4.401-4.753.381c-.833.067-1.171 1.107-.536 1.651l3.62 3.102-1.106 4.637c-.194.813.691 1.456 1.405 1.02L10 15.591l4.069 2.485c.713.436 1.598-.207 1.404-1.02l-1.106-4.637 3.62-3.102c.635-.544.297-1.584-.536-1.65l-4.752-.382-1.831-4.401z"
                                                        clip-rule="evenodd"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <p className="sr-only">5 dari 5 bintang</p>
                                        </div>
                                    </div>
                                    <div className="flex w-full justify-between pt-1 text-xxs"><span>Weekly Diamond Pass</span><span>15-10-2024 11:59:34</span></div>
                                    <div className="mt-1 space-y-6 text-xs italic text-foreground">“Proses cepat banget”</div>
                                </div>
                              
                            </div>
                            <div className="flex justify-end pt-4"><a className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input hover:bg-accent/75 hover:text-accent-foreground h-8 rounded-md px-3 bg-secondary/50 pr-3 text-secondary-foreground flex items-center gap-2"
                                type="button" href="/id-id/reviews" style={{ outline: 'none' }}><span>Lihat semua ulasan</span><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-arrow-right h-4 w-4"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg></a></div>
                        </div>
                    </section>
                   


                </div>
            </div>
        </div>

        <form className="col-span-3 col-start-1 flex flex-col gap-4 lg:col-span-2 lg:gap-8">
            <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="1">
                <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
                    <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">1</div>
                    <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Pilih Nominal</h2></div>
                <div className="p-4">
                    <div className="flex flex-col space-y-4">
                       
                        





                    {products.map((product) => (
                <section key={product.name} id={product.name} >
                    <h3 className="pb-4 text-sm/6 font-semibold text-card-foreground">{product.name}</h3>
                    <div role="radiogroup" aria-labelledby={`label-${product.name}`}>
                        <label className="sr-only" id={`label-${product.name}`} role="none">Select a variant list</label>
                        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3" role="none">
                            {product.variants.map((variant) => (
                                 <div
          key={variant.id}
          className={`relative flex cursor-pointer rounded-xl border border-transparent bg-foreground/75 p-2.5 text-background shadow-sm outline-none md:p-4 ${
            selectedVariant === variant.id ? 'bj-shadow ring-2 ring-primary ring-offset-2 ring-offset-card bg-order-variant-background text-order-variant-foreground' : ''
          }`}
          onClick={() => handleVariantSelect(variant.id)}
          //onClick={() => setSelectedVariant(variant.id)}
        >
                                    <span className="flex flex-1">
                                        <span className="flex flex-col justify-between">
                                            <span className="block text-xs font-semibold">{variant.name}</span>
                                            <div>
                                                <span className="mt-1 flex items-center text-[11px] font-semibold text-muted-foreground/60">{formatPrice(variant.price)}</span>
                                                <span className="flex items-center text-[11px] font-semibold italic line-through decoration-[0.9px] text-muted-foreground/60">{formatPrice(variant.originalPrice)}</span>
                                            </div>
                                        </span>
                                    </span>
                                    <Image src={`${hary.config.dash}/assets/banner/${variant.image}`} height={300} width={300}   alt={variant.name} className="object-contain object-right w-8 h-8" />
                                    {selectedVariant === variant.id && (
            <div className="selected-item absolute inset-0 overflow-hidden"></div>
          )}
                                </div>
                            ))}
                        </div>
                    </div>
                </section>
            ))}








                    </div>
                </div>
            </section>
            <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="2">
                <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
                    <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">2</div>
                    <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Masukkan Data Akun</h2></div>
                <div className="p-4">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label for="id" className="block text-xs font-medium text-foreground pb-2">ID</label>
                            <div className="flex flex-col items-start">
                                <input className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                type="number" id="id" name="id" min="0" placeholder="Ketikan ID" autocomplete="id" value="" />
                            </div>
                        </div>
                        <div>
                            <label for="server" className="block text-xs font-medium text-foreground pb-2">Server</label>
                            <div className="flex flex-col items-start">
                                <input className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                type="number" id="server" name="server" min="0" placeholder="Ketikan Server" autocomplete="server" value="" />
                            </div>
                        </div>
                    </div>
                    <div className="mt-4 text-xs text-card-foreground">
                        <div>
                            <p><em>Contoh: 123455789 (12345) maka ID = 123456789 dan Server = 12345</em></p>
                        </div>
                    </div>
                </div>
            </section>
            <section
      className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]"
      id="3"
    >
      <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
        <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">
          3
        </div>
        <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">
          Masukkan Jumlah Pembelian
        </h2>
      </div>
      <div className="p-4">
        <div className="flex items-center gap-x-4">
          <div className="flex-1">
            <div className="flex flex-col items-start">
              <input
                className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                type="text"
                name="quantity"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value, 10))}
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-9 w-9"
              type="button"
              onClick={handleIncrement}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                aria-hidden="true"
                className="h-5 w-5"
              >
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"></path>
              </svg>
            </button>
            <button
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-9 w-9"
              type="button"
              onClick={handleDecrement}
              disabled={quantity === 0}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                aria-hidden="true"
                className="h-5 w-5"
              >
                <path stroke-linecap="round" stroke-linejoin="round" d="M19.5 12h-15"></path>
              </svg> 
            </button>
          </div>
        </div>
      </div>
    </section>

    <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="4">
      <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
        <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">
          4
        </div>
        <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Pilih Pembayaran</h2>
      </div>
      <div className="p-4">
        <dl className="flex w-full flex-col space-y-4">
        {paymentChannels
  .filter((channel) => channel.featured) // Filter for featured channels
  .map((channel) => (
    <div key={channel.id}>
     <div
  className={`relative flex cursor-pointer rounded-lg border border-transparent bg-foreground/75 p-2.5 text-muted-foreground shadow-sm outline-none md:px-5 md:py-3 ${selectedPayment === channel.code ? ' text-primary ring-2 ring-primary ring-offset-2 ring-offset-card' : ''}`}
  role="radio"
  aria-checked={selectedPayment === channel.code}
  aria-disabled={!selectedVariant} // Menandakan status nonaktif
  tabIndex={selectedVariant ? 0 : -1} 
  onClick={selectedVariant ? () => handlePaymentSelect(channel.code) : undefined}
  onKeyPress={(e) => e.key === 'Enter' && selectedVariant && handlePaymentSelect(channel.code)} // Keyboard accessibility
>

        <div className="flex w-full flex-col items-start justify-between py-1 md:flex-row md:items-center">
          <div className="flex items-center gap-4">
            <div className="w-full">
              <span className="block pb-2.5 text-foreground font-semibold sm:text-sm">{channel.name}</span>
              <img src={`${channel.image}`} alt="{channel.image}" class="max-h-6"></img>
            </div>
          </div>
          <div>
       {selectedVariant ? (
  <div className="relative mr-8 text-foreground text-sm font-semibold sm:text-base w-full rounded-md border py-1 text-center md:w-auto md:border-none md:text-right">
  {(() => {
      const price = products.find((p) => p.variants.find((v) => v.id === selectedVariant))
        .variants.find((v) => v.id === selectedVariant).price;

      const fee = channel.feeAmount > 0 
        ? channel.feeAmount 
        : (price * (channel.feePercentage / 100));

      const totalPrice = price + fee;
    const totalPriceRina = totalPrice * quantity;
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalPriceRina);
    })()}
  </div>
) : (
  <div className="relative mr-8 text-xs font-semibold sm:text-base">
    <span className="text-xs text-destructive">Min. Rp&nbsp; {channel.minAmount}</span>
  </div>
)}

          </div>
          <div className="w-[4.5rem] absolute aspect-square -top-[9px] -right-[9px] overflow-hidden rounded-sm">
            <div className="absolute top-0 left-0 bg-primary/50 h-2 w-2"></div>
            <div className="absolute bottom-0 right-0 bg-primary/50 h-2 w-2"></div>
            {channel.featured && (
              <div className="absolute block w-square-diagonal py-1 text-center text-xxs font-semibold uppercase bottom-0 right-0 rotate-45 origin-bottom-right shadow-sm bg-primary text-primary-foreground">
                Best Price
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  ))}
          {/* Virtual Account Section */}

     {uniquePaymentChannels.map((channel) => {
 const channelTypeMap = {
  "Virtual Account": 'va',
  "Convenience Store": 'cstore',
  "E-Wallet": 'ewallet',
  "QRIS": 'qris',
  "OVO": 'ovo',
};

const isOpen = channel.type.description === "Virtual Account" ? isVirtualAccountOpen 
  : channel.type.description === "E-Wallet" ? isEwalletOpen 
  : channel.type.description === "Convenience Store" ? isConvenienceStoreOpen 
  : false;

const handleToggle = channel.type.description === "Virtual Account" ? handleVirtualAccountToggle 
  : channel.type.description === "Convenience Store" ? handleConvenienceStoreToggle 
  : channel.type.description === "E-Wallet" ? handleEWalletToggle 
  : null;

const channelTypeName = channelTypeMap[channel.type.description];

        return (  
         <div className="flex w-full transform flex-col justify-between rounded-xl bg-background/50 text-left text-sm font-medium duration-300 focus:outline-none">
  <div>
    
      
        <div key={channel.id}>
          <button
            className={`w-full rounded-t-xl bg-card text-card-foreground disabled:opacity-75 ${isOpen ? 'hary' : ''}`}
            type="button"
            onClick={handleToggle} disabled={!selectedVariant}
          >
            <div className="flex w-full items-center justify-between px-4 py-2">
              <span className="transform text-sm/6 font-medium leading-7 duration-300">{channel.type.description}</span>
              <span className="ml-6 flex h-7 items-center">
                {isOpen ? (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    strokeWidth="1.5"
                    stroke="currentColor"
                    aria-hidden="true"
                    className="h-5 w-5 transform duration-300 rotate-180"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                  </svg>
                ) : (
                  <span className="ml-6 flex h-7 items-center">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      fill="none"
                      viewBox="0 0 24 24"
                      strokeWidth="1.5"
                      stroke="currentColor"
                      aria-hidden="true"
                      className="h-5 w-5 transform duration-300"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
                    </svg>
                  </span>
                )}
              </span>
            </div>
          </button>
          {!isOpen && (
            <div className="w-full rounded-b-xl bg-secondary/60 px-4 py-3">
              <div className="flex justify-end gap-x-2">
                {paymentChannels
                  .filter((ch) => ch.type.name === channelTypeName)
                  .map((ch) => (
                    <div key={ch.id} className="relative aspect-[6/2] w-10">
                      <Image
                        alt={ch.image}
                        src={ch.image}
                        layout="fill"
                        objectFit="contain"
                        fetchPriority="high"
                        decoding="async"
                        sizes="80vw"
                        loading="lazy"
                      />
                    </div>
                  ))}
              </div>
            </div>
          )}
          {isOpen && (
            <div className="overflow-hidden transform max-h-screen">
              <div className="px-4 pb-4 pt-2 text-sm">
                <div role="radiogroup" aria-labelledby="headlessui-label-:rfm:">
                  <label className="sr-only" id="headlessui-label-:rfm:" role="none">Select a payment list</label>
                  <div className="grid grid-cols-2 gap-4 pt-2 sm:grid-cols-3 md:grid-cols-2 xl:grid-cols-3" role="none">
                    {paymentChannels
                      .filter((ch) => ch.type.name === channelTypeName)
                      .map((ch) => (
                        <div key={ch.id}  className={`relative flex cursor-pointer rounded-lg border border-transparent bg-muted p-2.5 text-muted-foreground shadow-sm outline-none md:px-5 md:py-3 ${selectedPayment === ch.code ? ' text-primary ring-2 ring-primary ring-offset-2 ring-offset-card' : ''}`}
  role="radio"
  aria-checked={selectedPayment === ch.code}
  aria-disabled={!selectedVariant} // Menandakan status nonaktif
  tabIndex={selectedVariant ? 0 : -1} 
  onClick={selectedVariant ? () => handlePaymentSelect(ch.code) : undefined}
  onKeyPress={(e) => e.key === 'Enter' && selectedVariant && handlePaymentSelect(ch.code)}>
                          <span className="flex w-full">
                            <span className="flex w-full flex-col justify-between">
                              <div className="">
                                <Image
                                  src={ch.image}
                                  alt={ch.name}
                                  className="object-scale-down"
                                  width={40}
                                  height={24}
                                />
                              </div>
                              <div className="flex w-full items-center justify-between">
                                <div className="mt-2 w-full">
                                  <div className="mt-1.5 flex items-center gap-2">
                                    <div className="relative z-30 text-xs font-semibold leading-4 text-muted-foreground">
                                      {(() => {
      const price = products.find((p) => p.variants.find((v) => v.id === selectedVariant))
        .variants.find((v) => v.id === selectedVariant).price;

      const fee = channel.feeAmount > 0 
        ? channel.feeAmount 
        : (price * (channel.feePercentage / 100));

      const totalPrice = price + fee;

      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalPrice);
    })()}

                                    </div>
                                  </div>
                                  <div className="mt-0.5 h-px w-full bg-foreground/75"></div>
                                  <div>
                                    <span className="block text-xxs italic text-muted-foreground"></span>
                                  </div>
                                </div>
                              </div>
                            </span>
                          </span>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
   
  </div>
</div>
     );
    })}       </dl>
      </div>
    </section>



    <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="5">
        <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
            <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">5</div>
            <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Kode Promo</h2></div>
        <div className="p-4">
            <div className="flex flex-col gap-4">
                <div className="flex items-center gap-x-4">
                    <div className="flex-1">
                        <div className="flex flex-col items-start">
                            <input className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                            type="text" placeholder="Ketik Kode Promo Anda" name="promo.code" />
                        </div>
                    </div>
                    <button className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 rounded-md px-3"
                    type="button">Gunakan</button>
                </div>
                <div>
                    <button className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 rounded-md px-3 gap-2 pl-3"
                    type="button">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-ticket-percent h-4 w-4">
                            <path d="M2 9a3 3 0 1 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 1 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"></path>
                            <path d="M9 9h.01"></path>
                            <path d="m15 9-6 6"></path>
                            <path d="M15 15h.01"></path>
                        </svg><span>Pakai Promo Yang Tersedia</span></button>
                </div>
            </div>
        </div>
    </section>
    <section className="relative scroll-mt-20 rounded-xl bg-card/50 shadow-2xl md:scroll-mt-[5.75rem]" id="6">
        <div className="flex items-center overflow-hidden rounded-t-xl bg-card">
            <div className="flex h-10 w-10 items-center justify-center bg-primary font-semibold text-primary-foreground">6</div>
            <h2 className="px-4 py-2 text-sm/6 font-semibold text-card-foreground">Detail Kontak</h2></div>
        <div className="p-4">
            <div className="flex flex-col gap-3">
                <div className="flex flex-col gap-2">
                    <label className="block text-xs font-medium text-foreground">Email</label>
                    <div className="flex flex-col items-start">
                        <input className="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                        type="text" placeholder="example@gmail.com" name="contact.email" />
                    </div>
                </div>
               
                            
                <p className="flex items-center gap-2 rounded-md bg-card px-4 py-2.5 text-xs/6 text-card-foreground">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-info h-4 w-4">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 16v-4"></path>
                        <path d="M12 8h.01"></path>
                    </svg><span>Pastikan isi dengan benar, bukti transaksi akan kami kirim ke email/wa yang kamu isi di atas.</span></p>
            </div>
        </div>
    </section>
    <>
  {selectedVariant ? (
    <div className="shad sticky bottom-0 rounded-t-lg pb-4 flex flex-col gap-4 bg-background">
      <div className="rounded-lg border border-dashed bg-secondary p-4 text-sm text-secondary-foreground">
        <div>
          <div className="flex items-center gap-4">
            <div className="aspect-square h-16">
              <Image
                alt={products.find((p) => p.variants.find((v) => v.id === selectedVariant)).variants.find((v) => v.id === selectedVariant).name}
                loading="lazy"
                width="300"
                height="300"
                decoding="async"
                data-nimg="1"
                className="aspect-square h-16 rounded-lg object-cover"
                sizes="100vw"
               // srcset={`${hary.config.dash}/assets/banner/${products.find((p) => p.variants.find((v) => v.id === selectedVariant)).variants.find((v) => v.id === selectedVariant).image}`}
                //src={`${hary.config.dash}/assets/banner/${products.find((p) => p.variants.find((v) => v.id === selectedVariant)).variants.find((v) => v.id === selectedVariant).image}`}
                src={`${hary.config.dash}/upload/${hary.data.image}`}
                
              />
            </div>
            <div>
              <div className="text-xs">{products.find((p) => p.variants.find((v) => v.id === selectedVariant)).variants.find((v) => v.id === selectedVariant).name} x {quantity} Qty</div>
              <div className="flex items-center gap-2 pt-0.5 font-semibold">
                <span className="text-primary">{formatPrice(products.find((p) => p.variants.find((v) => v.id === selectedVariant)).variants.find((v) => v.id === selectedVariant).price)}</span>
              </div>
              <div className="text-xxs italic text-muted-foreground">**Waktu proses instan</div>
            </div>
          </div>
        </div>
      </div>
      <button
        className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 rounded-md px-3 w-full gap-2"
        type="submit"
      >
        <div>
          <svg width="24" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M16.4046 20.9973H8.5882C5.7181 20.9973 3.51348 19.9602 4.13906 15.7864L4.86777 10.1298C5.24916 8.04682 6.58205 7.25 7.7476 7.25H17.2783C18.4613 7.25 19.7125 8.10617 20.1581 10.1298L20.8868 15.7864C21.418 19.4893 19.2757 20.9973 16.4046 20.9973Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            <path opacity="0.4" d="M16.5526 7.04542C16.5526 4.81161 14.742 3.00004 12.5072 3.00004C10.2734 2.99031 8.45407 4.79312 8.44434 7.02791C8.44434 7.03375 8.44434 7.03958 8.44434 7.04542" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
            <path opacity="0.4" d="M15.2169 11.6797C15.2169 13.178 14.0027 14.3922 12.5044 14.3922C11.0071 14.399 9.78708 13.1897 9.78027 11.6914 V11.6797" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
          </svg>
        </div>
        <span>Pesan Sekarang!</span>
      </button>
    </div>
  ) : (
    <div className="flex flex-col gap-4">
      <div className="rounded-lg border border-dashed bg-secondary p-4 text-sm text-secondary-foreground">
        <div className="text-center">Belum ada item produk yang dipilih.</div>
      </div>
      <button
        className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 rounded-md px-3 w-full gap-2"
        type="submit"
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" className="lucide lucide-shopping-bag h-4 w-4">
          <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"></path>
          <path d="M3 6h18"></path>
          <path d="M16 10a4 4 0 0 1-8 0"></path>
        </svg>
        <span>Pesan Sekarang!</span>
      </button>
    </div>
  )}
</>

            </form>

        
        </div>
    











        <div>
        <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 390" xmlns="http://www.w3.org/2000/svg" className="bg-transparent pt-8 transition delay-150 duration-300 ease-in-out md:pt-24 print:hidden">
            <path d="M 0,400 C 0,400 0,200 0,200 C 40.34909359970402,243.0042668639783 80.69818719940804,286.0085337279566 135,268 C 189.30181280059196,249.9914662720434 257.5563448020718,170.97013195215192 311,159 C 364.4436551979282,147.02986804784808 403.07643359230485,202.11093846343573 452,207 C 500.92356640769515,211.88906153656427 560.137920828709,166.58611419410528 626,169 C 691.862079171291,171.41388580589472 764.3718830928599,221.54460476014305 826,248 C 887.6281169071401,274.45539523985695 938.3745467998519,277.2354667653225 985,246 C 1031.625453200148,214.7645332346775 1074.1299297077323,149.51352817856701 1122,137 C 1169.8700702922677,124.48647182143299 1223.1057343692194,164.71042052040943 1277,184 C 1330.8942656307806,203.28957947959057 1385.4471328153904,201.64478973979527 1440,200 C 1440,200 1440,400 1440,400 Z"
            stroke="none" stroke-width="0" fill="currentColor" fill-opacity="1" className="fill-secondary transition-all delay-150 duration-300 ease-in-out"></path>
        </svg>
    </div>



    </main>
    <Footer />
    </>
  ); // Display slug on the page
};

export default CategoryPage;
