"use client";
import React, { useState } from 'react';
import { NextPage } from 'next';
import Navbar from './../../harydata/navbar';
import Footer from './../../harydata/footer';
const Invoices: NextPage = () => {

const [isModalOpencari, setModalOpencari] = useState<boolean>(false);

const toggleModalCari = () => {
  setModalOpencari(currentState => !currentState);
};



    return (
        <div >
        <Navbar onButtonClick={toggleModalCari} />
        <main class="relative bg-background" style={{ zIndex: 1 }}>
    <section id="history" class="relative">
        <div class="space-y-12">
            <div class="relative overflow-hidden shadow-2xl">
                <div class="absolute z-20 h-full w-full">
                    <div class="area">
                        <ul class="rectangle">
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                </div>
                <div class="absolute inset-0 z-10 bg-gradient-to-r from-background via-background/75 to-background/75 sm:to-transparent"></div>
                    <form class="container relative z-20 py-12 text-left" id="invoice-form">
                        <h2 class="max-w-2xl text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Cari pesanan kamu!</h2>
                        <p class="mt-3 max-w-3xl text-foreground">Lacak transaksi kamu dengan cara memasukkan Nomor Invoice dibawah ini:</p>
                        <div class="mt-6 max-w-xl">
                            <label for="invoice" class="block text-xs font-medium text-foreground mb-2 text-left">Nomor Invoice Kamu</label>
                            <div class="flex flex-col items-start">
                                <input class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75 !rounded-md"
                                type="text" id="invoice" placeholder="HRYXXXXXXXXXXXXXX" name="invoice" />
                            </div>
                        </div>
                        <div class="mt-6 flex items-center justify-start gap-x-6">
                            <button class="inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground duration-300 hover:bg-primary/75 disabled:cursor-not-allowed disabled:opacity-75 space-x-2 !pl-3 !pr-4"
                            type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" class="h-5 w-5">
                                    <path fill-rule="evenodd" d="M9 3.5a5.5 5.5 0 100 11 5.5 5.5 0 000-11zM2 9a7 7 0 1112.452 4.391l3.328 3.329a.75.75 0 11-1.06 1.06l-3.329-3.328A7 7 0 012 9z" clip-rule="evenodd"></path>
                                </svg><span>Cari Transaksi</span></button>
                        </div>
                    </form>
                 
            </div>

























            <div class="container sm:flex sm:items-center">
                <div class="sm:flex-auto">
                    <h1 class="text-xl font-semibold text-foreground">Transaksi Real-time</h1>
                    <p class="mt-2 max-w-2xl text-sm text-foreground">Berikut ini Real-time data pesanan masuk terbaru HARY-IT.</p>
                </div>
            </div>
            <div  id="list"class="container">
                <div class="space-y-4">
                    <div class="-mx-4 overflow-x-auto ring-1 ring-muted sm:mx-0 sm:rounded-lg">
                        <table class="min-w-full divide-y divide-muted">
                            <thead>
                                <tr>
                                    <th scope="col" colspan="1" class="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                        <div class="">Tanggal</div>
                                    </th>
                                    <th scope="col" colspan="1" class="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                        <div class="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">Nomor Invoice</div>
                                    </th>
                                    <th scope="col" colspan="1" class="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                        <div class="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">No. Handphone</div>
                                    </th>
                                    <th scope="col" colspan="1" class="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                        <div class="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">Harga</div>
                                    </th>
                                    <th scope="col" colspan="1" class="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                        <div class="">Status</div>
                                    </th>
                                </tr>
                            </thead>
                            
 <tbody>
                                            <tr>
                                                <td colspan="7" class="px-4 py-24 text-center sm:px-6">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="mx-auto h-12 w-12 text-foreground">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z"></path>
                                                    </svg>
                                                    <h3 class="mt-2 font-semibold text-foreground">Data tidak ditemukan!</h3>
                                                    <p class="mt-1 text-sm text-secondary">Tidak ada aktifitasi data.</p>
                                                </td>
                                            </tr>
                                        </tbody>
                            


                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div>
        <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 390" xmlns="http://www.w3.org/2000/svg" class="bg-transparent pt-8 transition delay-150 duration-300 ease-in-out md:pt-24 print:hidden">
            <path d="M 0,400 C 0,400 0,200 0,200 C 40.34909359970402,243.0042668639783 80.69818719940804,286.0085337279566 135,268 C 189.30181280059196,249.9914662720434 257.5563448020718,170.97013195215192 311,159 C 364.4436551979282,147.02986804784808 403.07643359230485,202.11093846343573 452,207 C 500.92356640769515,211.88906153656427 560.137920828709,166.58611419410528 626,169 C 691.862079171291,171.41388580589472 764.3718830928599,221.54460476014305 826,248 C 887.6281169071401,274.45539523985695 938.3745467998519,277.2354667653225 985,246 C 1031.625453200148,214.7645332346775 1074.1299297077323,149.51352817856701 1122,137 C 1169.8700702922677,124.48647182143299 1223.1057343692194,164.71042052040943 1277,184 C 1330.8942656307806,203.28957947959057 1385.4471328153904,201.64478973979527 1440,200 C 1440,200 1440,400 1440,400 Z"
            stroke="none" stroke-width="0" fill="currentColor" fill-opacity="1" class="fill-secondary transition-all delay-150 duration-300 ease-in-out"></path>
        </svg>
    </div>
</main>
<Footer isModalOpen={isModalOpencari} onClose={() => setModalOpencari(false)} />
</div>
    );
};

export default Invoices;
