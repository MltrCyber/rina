// app/id/page.tsx
import HomePage from '../page';

const IdPage = () => {
  return <HomePage />;
};

export default IdPage;
