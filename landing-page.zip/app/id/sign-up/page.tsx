// app/signup/page.tsx
"use client";
import { useState } from 'react';
import { useRouter } from 'next/navigation';




const SignUp = () => {

    const [loading, setLoading] = useState(false);

    const handleClick = () => {
        setLoading(true);
        // Simulasi proses loading (misalnya, panggil API)
        setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 2000); // Misalnya loading selama 2 detik
    };


  const [isChecked, setIsChecked] = useState(false);
  const [errorlol, setErrorlol] = useState('');

  const handleCheckboxChange = (e) => {
    setIsChecked(e.target.checked);
    if (e.target.checked) {
      setErrorlol('');
    }
  };


  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [email, setEmail] = useState('');
  const [no_hp, setNoHp] = useState('');
  const [full_name, setFullName] = useState('');
const [error, setError] = useState('');
  const router = useRouter();

 
  const handleSubmit = async (e: React.FormEvent) => {
    setLoading(true);
        // Simulasi proses loading (misalnya, panggil API)
        
    e.preventDefault();

if (!isChecked) {
    setLoading(false);
      setErrorlol('You must agree to the terms and conditions.');
      return;
    }


 const passwordPattern = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$%^&*()_+=-{};:',./?]).{8,20}$/;
 if (!passwordPattern.test(pass)) {
      setError('Password must be 8-20 characters long and include letters, numbers, and special characters.');
      setLoading(false);
      return;
    }


 


    
    
    if (pass !== confirmPass) {
  
  setError('Password harus sama dengan konfirmasi password!');
      setLoading(false);
      return;
    }

















    if (!user) {
      
      
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please enter your username</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }

    if (!pass) {
      
      
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please enter your password</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }

    if (!confirmPass) {
      
     
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please confirm your password</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }


















   

    if (!email) {
      
      
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please enter your email</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }

    if (!no_hp) {
     
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please enter your phone number</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }

    if (!full_name) {
     
      const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">Please enter your full name</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
      return;
    }

























    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/sign-up`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ user, pass, email, no_hp ,full_name }),
    })
    .then(response => response.json())
.then(data => {
  if (data.success) {

setTimeout(() => {
            setLoading(false);
            window.location.href = data.redirect;
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
    // Redirect to dashboard
    
  } else {
     const errorMessage = `
   <div style="position:fixed;z-index:9999;top:16px;left:16px;right:16px;bottom:16px;pointer-events:none">
  <div class="globalalerthary hide-after-5s" style="left: 0px; right: 0px; display: flex; position: absolute; top: 0px; justify-content: center;">
    <div class="alerthary" style="animation: 0.35s cubic-bezier(0.21, 1.02, 0.73, 1) 0s 1 normal forwards running go3223188581;">
      <div class="alertrina">
        <div class="alertdina"></div>
        <div class="alertfeny">
          <div class="alertharyrina"></div>
        </div>
      </div>
      <div role="status" aria-live="polite" class="alertmasalalu">${data.message}</div>
    </div>
  </div>
</div>
  `;
  const errorDiv = document.createElement('div');
  errorDiv.innerHTML = errorMessage;
  document.body.appendChild(errorDiv);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 4500); // Misalnya loading selama 2 detik
   




  }
})
.catch(error => {
  console.error('Error:', error);

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 2000); // Misalnya loading selama 2 detik

})

setTimeout(() => {
            setLoading(false);
            // Tambahkan logika setelah loading jika perlu
        }, 2000); // Misalnya loading selama 2 detik
};



   const togglePasswordVisibility = (e, inputId) => {
    const input = document.getElementById(inputId);
    input.type = input.type === 'password' ? 'text' : 'password';
    e.currentTarget.classList.toggle('visible'); // Add a class to style if needed
  };



  return (
    <body class="bg-background bg-gradient-theme text-foreground">
     <div class="absolute left-4 top-4 z-50">
  <a class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 h-9 w-9"
     type="button" style={{ outline:'none' }} href="/">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x h-5 w-5">
      <path d="M18 6 6 18"></path>
      <path d="m6 6 12 12"></path>
    </svg>
  </a>
</div>

<div class="relative flex min-h-dvh shrink-0 justify-center pt-12 md:px-12 md:pt-0 lg:px-0">
    <div class="relative z-10 flex flex-1 flex-col justify-center bg-background/50 px-4 py-10 md:flex-none md:px-24">
        <div class="mx-auto w-full max-w-md sm:px-4 md:w-[400px] md:px-0">
            <div class="mx-auto w-full max-w-md space-y-8 lg:mx-0">
                <div>
                    <h2 class="mt-2 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">Daftar</h2>
                    <p class="mt-2 text-sm text-foreground">Masukkan informasi pendaftaran yang valid</p>
                </div>
                <form class="mt-8 space-y-6" onSubmit={handleSubmit}>






                 <div class="space-y-3 rounded-md shadow-sm">
                        <div class="flex space-x-4">
                            <div class="w-1/2">
                                <label for="name" class="block text-xs font-medium text-foreground pb-2">Nama lengkap</label>
                                <div class="flex flex-col items-start">
                                    <input class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                    type="text" id="name" value={full_name}
          onChange={(e) => setFullName(e.target.value)} autocomplete="name" placeholder="Nama lengkap" name="full_name" required />
                                </div><span class="text-xs text-destructive"></span></div>
                            <div class="w-1/2">
                                <label for="username" class="block text-xs font-medium text-foreground pb-2">Username</label>
                                <div class="flex flex-col items-start">
                                    <input class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                    type="text" id="username" value={user}
          onChange={(e) => setUser(e.target.value)} autocomplete="off" placeholder="Username" name="user"required />
                                </div><span class="text-xs text-destructive"></span></div>
                        </div>
<div>
                            <label for="email" class="block text-xs font-medium text-foreground pb-2">Alamat email</label>
                            <div class="flex flex-col items-start">
                               <input class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                type="email" id="email" autocomplete="off" pattern="[a-zA-Z0-9._%+-]+@gmail\.com" title="Hanya email dari Gmail yang diizinkan" placeholder="Alamat email" name="email" value={email}
          onChange={(e) => setEmail(e.target.value)} required />


                            </div><span class="text-xs text-destructive"></span></div>

<div>
                            <label for="no" class="block text-xs font-medium text-foreground pb-2">Nomor whatsapp</label>
                           <div class="flex flex-col items-start">
                                <input class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"
                                type="number" 
          value={no_hp}
          onChange={(e) => setNoHp(e.target.value)}id="phone-number" autocomplete="off" placeholder="Nomor WhatsApp" pattern="[0-9]{11,13}" title="Masukan Nomor WhatsApp" name="no_hp" required />
                            </div>
                           <span class="text-xs text-destructive"></span></div>
                      
                      <div class="flex space-x-4">
  <div class="w-1/2">
    <label for="password" class="block text-xs font-medium text-foreground pb-2">Kata sandi</label>
    <div class="relative">
      <div class="flex flex-col items-start">
        <input id="password" type="password" value={pass}
          onChange={(e) => setPass(e.target.value)} class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75" placeholder="Kata sandi" name="pass"pattern="[a-zA-Z0-9!@#$%^&*()_+=-{};:',./?]{8,20}" title="Kombinasi Huruf dan Angka Dengan Spesial Karakter, Minimal 8 Karakter" required />
      </div>
      <button
            type="button"
            className="absolute right-4 top-0 h-full"
            onClick={(e) => togglePasswordVisibility(e, 'password')}
          >
      <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-4 w-4">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"></path>
        </svg>
      </button>
    </div>
     {error && <span className="text-xs text-destructive">{error}</span>}
  </div>
  <div class="w-1/2">
    <label for="password-confirmation" class="block text-xs font-medium text-foreground pb-2">kata sandi</label>
    <div class="relative">
      <div class="flex flex-col items-start">
        <input id="password-confirmation" type="password" value={confirmPass}
          onChange={(e) => setConfirmPass(e.target.value)} class="relative block w-full appearance-none rounded-lg border border-border bg-input px-3 py-2 text-xs text-foreground placeholder-muted-foreground focus:z-10 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary disabled:cursor-not-allowed disabled:opacity-75"pattern="[a-zA-Z0-9!@#$%^&*()_+=-{};:',./?]{8,20}" title="Kombinasi Huruf dan Angka Dengan Spesial Karakter, Minimal 8 Karakter"  placeholder="Konfirmasi kata sandi" name="pass2"required />
      </div>
      <button
            type="button"
            className="absolute right-4 top-0 h-full"
            onClick={(e) => togglePasswordVisibility(e, 'password-confirmation')}
          ><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-4 w-4">
          <path stroke-linecap="round" stroke-linejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88"></path>
        </svg>
      </button>
    </div>
     {error && <span className="text-xs text-destructive">{error}</span>}
  </div>
</div>


                        </div>
                         <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <input
          type="checkbox"
          className="border-murky-600 bg-murky-700 focus:ring-primary-400 focus:ring-offset-murky-900 h-4 w-4 cursor-pointer rounded text-primary"
          id="tac"
          name="tac"
          required
          checked={isChecked}
          onChange={handleCheckboxChange}
        />
                            <label for="tac" class="block text-xs font-medium text-foreground ml-3 block select-none text-sm text-foreground">Saya setuju dengan <a class="text-primary" href="/id/terms-and-condition" style={{ outline: 'none' }}>Syarat dan Ketentuan</a> dan <a class="text-primary" href="/id/privacy-policy" style={{ outline: 'none' }}>Kebijakan Pribadi</a>.</label>
                        </div>
                    </div>{errorlol && <span className="text-xs text-destructive">{errorlol}</span>}

                    <div>
                        <div>
                        
                          
                        </div>
                    </div>
                    <div>
            <button
                className={`items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground duration-300 
                ${loading ? 'opacity-75 cursor-not-allowed' : 'hover:bg-primary/75'} group relative flex w-full`}
                type="button"
                onClick={handleSubmit}
                disabled={loading}
            >
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            fill="none"
                            viewBox="0 0 24 24"
                            strokeWidth="1.5"
                            stroke="currentColor"
                            aria-hidden="true"
                            className="h-5 w-5 text-primary-foreground transition-colors group-hover:text-primary-foreground/75"
                        >
                            <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z"
                            ></path>
                        </svg>
                    
                </span>
                 {loading ? (
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-refresh-ccw mr-2 h-4 w-4 animate-spin"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"></path><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path><path d="M16 16h5v5"></path></svg>
                    ) : ( '' )}
                {loading ? 'Loading...' : 'Daftar'}
            </button>
        </div>
                    <div class="relative mt-6">
                        <div class="relative flex justify-center text-sm"><span class="px-2 text-foreground">Sudah memiliki akun</span></div>
                    </div>
                    <div><a class="items-center justify-center rounded-lg px-4 py-2 text-sm font-medium duration-300 group relative flex w-full bg-muted text-muted-foreground hover:bg-muted/75" href="/id/sign-in" style={{ outline: 'none' }}><span class="absolute inset-y-0 left-0 flex items-center pl-3"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-5 w-5 text-background transition-colors group-hover:text-muted-foreground"><path stroke-linecap="round" stroke-linejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z"></path></svg></span>Masuk</a></div>

                    
                    </form>
</div>
</div>
</div>
<div class="hidden sm:block lg:flex-1 xl:relative">
        <div class="size-full bg-primary"></div>
    </div>
</div>








</body>










  );
};

export default SignUp;
