// app/id/dashboard/page.tsx
"use client";
import Navbar from './../../harydata/navbar';
import Footer from './../../harydata/footer';
import { useEffect, useState } from 'react';
interface User {
  userId: number;
  username: string;
  password: string; // Add password to the User interface if needed
}


  

const DashboardPage = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState(null);

 useEffect(() => {
  const fetchUser = async () => {
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/profile`, {
        credentials: 'include', // <-- Tambahkan ini
      });
      if (!res.ok) throw new Error('Failed to fetch user details');
      const userData = await res.json();
      if (userData.error) {
        window.location.href = userData.redirect; // Redirect to the specified URL
        return;
      }
      setUser(userData.data);
    } catch (err) {
      setError(err.message);
    }
  };

  fetchUser();
}, []);


  //if (error) return <div>{error}</div>;
  if (!user) return  <div className="bg-background flex items-center justify-center h-screen">
      <div className="animate-spin h-10 w-10 border-4 border-blue-500 border-t-transparent rounded-full"></div>
    </div>;
  

  return (
    <>
     <body className="bg-background bg-gradient-theme text-foreground"  style={{ zIndex: 1}}>
        <div className="bg-background"></div>
    <Navbar />
    <main className="relative bg-background">
            <div className="container grid grid-cols-8 gap-8 pt-8 sm:pt-16">
                <div className="col-span-1 hidden sm:block md:col-span-2">
                    <aside className="sticky top-20 print:hidden">
                        <nav className="h-full content-start lg:grid lg:content-between">
                            <div className="space-y-4">
                                <a className="group flex items-center gap-3 rounded-md border border-muted/50 bg-gradient-to-r to-transparent px-3 py-2 font-bjcredits text-sm font-medium text-foreground hover:from-muted/50" href="/dashboard/reload" style={{ outline: 'none' }}><span className="hidden truncate md:block">Balance</span></a>
                                <a className="group flex items-center gap-3 rounded-md bg-gradient-to-r to-transparent px-3 py-2 text-sm font-medium text-foreground from-primary text-primary-foreground"
                                href="/dashboard" style={{ outline: 'none' }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>
                                    </svg><span className="hidden truncate md:block">Dashboard</span></a>
                                <a className="group flex items-center gap-3 rounded-md bg-gradient-to-r to-transparent px-3 py-2 text-sm font-medium text-foreground hover:from-muted/50" href="/dashboard/history"
                                style={{ outline: 'none' }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg><span className="hidden truncate md:block">Transaksi</span></a>
                                <a className="group flex items-center gap-3 rounded-md bg-gradient-to-r to-transparent px-3 py-2 text-sm font-medium text-foreground hover:from-muted/50" href="/dashboard/mutation"
                                style={{ outline: 'none' }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99"></path>
                                    </svg><span className="hidden truncate md:block">Mutasi</span></a>
                        
                            </div>
                            <div className="w-full pt-4 ">
                                <button type="button" id="logout-btn" className="flex w-full items-center gap-3 rounded-md bg-gradient-to-r px-3 py-2 text-sm font-medium text-destructive hover:from-muted/50">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75"></path>
                                    </svg><span className="hidden md:block">Keluar</span></button>
                            </div>
                        </nav>
                    </aside>
                </div>
                


                <div className="col-span-8 sm:col-span-7 sm:col-start-2 md:col-span-7 md:col-start-3">
                    <div className="grid grid-cols-1 gap-8 lg:gap-8 xl:grid-cols-2">
                        <div className="rounded-lg border bg-card/50 p-6">
                            <figure className="flex items-center justify-between">
                                <figcaption className="flex items-center justify-start space-x-3.5 text-left"><img src={`https://ui-avatars.com/api/?color=FFFFFF&background=f97316&name=${user.full_name}`} alt="" className="h-14 w-14 rounded-full" loading="lazy" decoding="async" />
                                    <div>
                                        <div className="flex items-center gap-x-2 pb-1 font-semibold text-foreground"><span>{user.full_name} </span>
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5 hidden">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12c0 1.268-.63 2.39-1.593 3.068a3.745 3.745 0 01-1.043 3.296 3.745 3.745 0 01-3.296 1.043A3.745 3.745 0 0112 21c-1.268 0-2.39-.63-3.068-1.593a3.746 3.746 0 01-3.296-1.043 3.745 3.745 0 01-1.043-3.296A3.745 3.745 0 013 12c0-1.268.63-2.39 1.593-3.068a3.745 3.745 0 011.043-3.296 3.746 3.746 0 013.296-1.043A3.746 3.746 0 0112 3c1.268 0 2.39.63 3.068 1.593a3.746 3.746 0 013.296 1.043 3.746 3.746 0 011.043 3.296A3.745 3.745 0 0121 12z"></path>
                                            </svg>
                                        </div><span className="inline-flex items-center rounded-md px-2 py-1 text-xs font-medium capitalize ring-1 ring-inset bg-info/10 text-info ring-info/30">
                                        {user.level}
                                        </span></div>
                                </figcaption>


<a className="bg-murky-600 flex items-center justify-center rounded-md p-2" href="/settings" style={{ outline: 'none' }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z"></path>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                    </svg>
                                </a>
                                </figure>
                                <div className="border-murky-600 mt-6 flex items-center space-x-2 border-t pt-6">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z"></path>
                                </svg><span>{user.no_hp}</span>
                                </div>
                </div>
                <div>
                            <div className="border0 rounded-lg border bg-card/50 p-6">
                                <div className="flex items-center justify-between gap-4">
                                    <div>
                                        <div className="font- flex items-center gap-3 font-bjcredits text-sm"><span>Balance</span></div>
                                    </div>
                                    <div className="flex items-center justify-center space-x-2">
                                        <a className="bg-murky-600 rounded-md p-2" href="/dashboard/reload" style={{outline: 'none' }}>
                                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-5 w-5">
                                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                            </svg>
                                        </a><a className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-8 rounded-md px-3"
                                        type="button" href="/topup" >Top Up</a><a className="inline-flex items-center justify-center whitespace-nowrap text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 h-8 rounded-md px-3"
                                        type="button" href="/dashboard/reload/redeem" >Redeem</a></div>
                                </div>
                                <div className="mt-4">
                                    <h3 className="font-bjcredits text-[24px] font-bold lg:text-[26px]"><span className="text-primary"> {user.balance}</span> <span></span></h3></div>
                            </div>
                        </div>


                         <div className="col-span-1 lg:col-span-2">
                            <h1 className="pb-4 text-lg font-semibold">Transaksi Hari Ini</h1>
                            <div className="grid grid-cols-2 gap-4 xl:gap-8">
                                <div className="flex flex-col items-center justify-center rounded-lg border bg-card p-6 col-span-2 duration-200 ease-in-out hover:bg-card/75 xl:col-span-1">
                                    <div className="flex items-center justify-center text-4xl font-semibold">0</div>
                                    <div className="pt-4 text-sm font-medium">Total Transaksi</div>
                                </div>

                                <div className="flex flex-col items-center justify-center rounded-lg border bg-card p-6 col-span-2 duration-200 ease-in-out hover:bg-card/75 xl:col-span-1">
                                    <div className="flex items-center justify-center text-4xl font-semibold">Rp. 0</div>
                                    <div className="pt-4 text-sm font-medium">Total Penjualan</div>
                                </div>
                            </div>

                            <div className="mt-4 grid grid-cols-2 gap-4 xl:mt-8 xl:grid-cols-4 xl:gap-8">
                                <div className="flex flex-col items-center justify-center rounded-lg border p-6 border-warning bg-warning/50 duration-200 ease-in-out hover:bg-warning/75">
                                    <div className="flex items-center justify-center text-4xl font-semibold">0</div>
                                    <div className="pt-4 text-sm font-medium">Menunggu</div>
                                </div>
                                 <div className="flex flex-col items-center justify-center rounded-lg border p-6 border-info bg-info/50 duration-200 ease-in-out hover:bg-info/75">
                                    <div className="flex items-center justify-center text-4xl font-semibold">0</div>
                                    <div className="pt-4 text-sm font-medium">Dalam Proses</div>
                                </div>

                               


                                 <div className="flex flex-col items-center justify-center rounded-lg border p-6 border-success bg-success/50 duration-200 ease-in-out hover:bg-success/75">
                                    <div className="flex items-center justify-center text-4xl font-semibold">0</div>
                                    <div className="pt-4 text-sm font-medium">Sukses</div>
                                </div>
 <div className="flex flex-col items-center justify-center rounded-lg border p-6 border-destructive bg-destructive/50 duration-200 ease-in-out hover:bg-destructive/75">
                                    <div className="flex items-center justify-center text-4xl font-semibold">0</div>
                                    <div className="pt-4 text-sm font-medium">Gagal</div>
                                </div>
                            </div>

                            </div>

                                
<div className="col-span-1 lg:col-span-2">
                            <h1 className="pb-4 text-lg font-semibold">Riwayat Transaksi Terbaru Hari Ini</h1>
                            <div className="space-y-4">
                                <div className="-mx-4 overflow-x-auto ring-1 ring-muted sm:mx-0 sm:rounded-lg">
                                    <table className="min-w-full divide-y divide-muted">
                                        <thead>
                                            <tr>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">Nomor Invoice</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="">ID Trx</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="">Item</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="">User Input</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">Harga</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="cursor-pointer select-none flex whitespace-nowrap items-center justify-between">Tanggal</div>
                                                </th>
                                                <th scope="col" colspan="1" className="table-cell whitespace-nowrap px-3 py-3.5 text-left text-xs font-semibold text-foreground first:table-cell first:pl-4 sm:first:pl-6 first:pr-4 last:relative last:table-cell sm:last:pr-6 [&amp;:nth-last-child(2)]:table-cell">
                                                    <div className="">Status</div>
                                                </th>
                                            </tr>
                                        </thead>
                                        

                                    
                                       <tbody>
                                            <tr>
                                                <td colspan="7" className="px-4 py-24 text-center sm:px-6">
                                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="mx-auto h-12 w-12 text-foreground">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z"></path>
                                                    </svg>
                                                    <h3 className="mt-2 font-semibold text-foreground">Data tidak ditemukan!</h3>
                                                    <p className="mt-1 text-sm text-secondary">Tidak ada aktifitasi data.</p>
                                                </td>
                                            </tr>
                                        </tbody>   
                                    </table>
                                </div>
                            </div>
                        </div>


                
                </div>
                </div>


            </div>







 <div>
                <svg width="100%" height="100%" id="svg" viewBox="0 0 1440 390" xmlns="http://www.w3.org/2000/svg" className="-mt-8 bg-background transition delay-150 duration-300 ease-in-out md:-mt-24 print:hidden">
                    <path d="M 0,400 C 0,400 0,200 0,200 C 40.34909359970402,243.0042668639783 80.69818719940804,286.0085337279566 135,268 C 189.30181280059196,249.9914662720434 257.5563448020718,170.97013195215192 311,159 C 364.4436551979282,147.02986804784808 403.07643359230485,202.11093846343573 452,207 C 500.92356640769515,211.88906153656427 560.137920828709,166.58611419410528 626,169 C 691.862079171291,171.41388580589472 764.3718830928599,221.54460476014305 826,248 C 887.6281169071401,274.45539523985695 938.3745467998519,277.2354667653225 985,246 C 1031.625453200148,214.7645332346775 1074.1299297077323,149.51352817856701 1122,137 C 1169.8700702922677,124.48647182143299 1223.1057343692194,164.71042052040943 1277,184 C 1330.8942656307806,203.28957947959057 1385.4471328153904,201.64478973979527 1440,200 C 1440,200 1440,400 1440,400 Z"
                    stroke="none" stroke-width="0" fill="currentColor" fill-opacity="1" className="fill-secondary transition-all delay-150 duration-300 ease-in-out"></path>
                </svg>
            </div>












                </main>
                <Footer />
                </body>
                </>

  );
};

export default DashboardPage;
