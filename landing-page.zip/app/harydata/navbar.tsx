"use client";
import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Search from './../func/Search';
import Image from 'next/image';
interface User {
  userId: number;
  username: string;
  password: string; // Add password to the User interface if needed
}
const Navbar = ({ onButtonClick }) => {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [isOpens, setIsOpens] = useState(false);
const [user, setUser] = useState(null);
const [error, setError] = useState(null);
  const dropdownRef = useRef(null);

  const [dropdownOpen, setDropdownOpen] = useState(false);
const handleClickOutside = (event) => {
    const dropdownMenu = document.getElementById('dropdown-menu');
    if (dropdownMenu && !dropdownMenu.contains(event.target)) {
      setDropdownOpen(false);
    }
    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
      setIsOpen(false);
    }
  };
  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  const toggleDropdowns = () => {
    setDropdownOpen((prev) => !prev);
  };
const [isModalOpencari, setModalOpencari] = useState<boolean>(false);

const toggleModalCari = () => {
  //setModalOpencari(currentState => !currentState);
  setIsOpens(!isOpens);
};
 

 

  const selectLanguage = (language) => {
    // Handle language selection here
    console.log(`Selected language: ${language}`);
    setIsOpen(false);
  };
    const [isSidebarOpen, updateSidebarOpen] = useState(false);

  const handleToggleSidebar = () => {
    updateSidebarOpen(!isSidebarOpen);
  };

  const handleCloseSidebar = () => {
    updateSidebarOpen(false);
  };

  useEffect(() => {
    let interval;
  
    const fetchUser = async () => {
      try {
        const statusRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/status`, {
          credentials: 'include',
        });
        if (!statusRes.ok) throw new Error('Failed to check user status');
        const statusData = await statusRes.json();
  
        if (statusData.status === true && statusData.author === 'HARY-IT') {
          // Jika status true dan author benar, ambil data profil
          const profileRes = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/profile`, {
            credentials: 'include',
          });
          if (!profileRes.ok) throw new Error('Failed to fetch user details');
          const profileData = await profileRes.json();
          setUser(profileData.data);
          
          // Hentikan interval jika berhasil mendapatkan profil
          if (interval) {
            clearInterval(interval);
          }
        } else {
          // Jika status false, set user ke null
          setUser(null);
        }
      } catch (err) {
        setError(err.message);
      }
    };
  
    fetchUser();
  
    // Hanya set interval jika status false
    interval = setInterval(() => {
      fetchUser();
    }, 5000);
  
    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, []);


const handleLogout = async () => {
  const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/sign-out`, {
    method: 'POST',
  });

  if (response.ok) {
    // Redirect ke halaman login setelah logout
    router.push('/id/sign-in');
  } else {
    console.error('Logout failed');
  }
};


const flagID = (
    <svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g clipPath="url(#clip0_566_17133)">
        <rect width="20" height="15" fill="white"/>
        <path fillRule="evenodd" clipRule="evenodd" d="M0 0V15H20V0H0Z" fill="#F7FCFF"/>
        <mask id="mask0_566_17133" maskUnits="userSpaceOnUse" x="0" y="0" width="20" height="15">
          <path fillRule="evenodd" clipRule="evenodd" d="M0 0V15H20V0H0Z" fill="white"/>
        </mask>
        <g mask="url(#mask0_566_17133)">
          <path fillRule="evenodd" clipRule="evenodd" d="M0 0V7.5H20V0H0Z" fill="#E31D1C"/>
        </g>
      </g>
      <defs>
        <clipPath id="clip0_566_17133">
          <rect width="20" height="15" fill="white"/>
        </clipPath>
      </defs>
    </svg>
  );
const flagEN = (<svg width="20" height="15" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><g clip-path="url(#clip0_566_17133)"><rect width="20" height="15" fill="white"></rect><path fillRule="evenodd" clipRule="evenodd" d="M0 0H20V15H0V0Z" fill="#E31D1C"></path><path fillRule="evenodd" clipRule="evenodd" d="M0 1.25V2.5H20V1.25H0ZM0 3.75V5H20V3.75H0ZM0 7.5V6.25H20V7.5H0ZM0 8.75V10H20V8.75H0ZM0 12.5V11.25H20V12.5H0ZM0 15V13.75H20V15H0Z" fill="#F7FCFF"></path><rect width="11.25" height="8.75" fill="#2E42A5"></rect><path fillRule="evenodd" clipRule="evenodd" d="M1.3 2.71722L1.9624 2.25581L2.47623 2.62572H2.1853L2.77364 3.1461L2.57492 3.87572H2.26369L1.96148 3.2056L1.70375 3.87572H0.935303L1.52364 4.3961L1.3 5.21722L1.9624 4.75581L2.47623 5.12572H2.1853L2.77364 5.6461L2.57492 6.37572H2.26369L1.96148 5.7056L1.70375 6.37572H0.935303L1.52364 6.8961L1.3 7.71722L1.9624 7.25581L2.60332 7.71722L2.40406 6.8961L2.91877 6.37572H2.68136L3.2124 6.00581L3.72623 6.37572H3.4353L4.02364 6.8961L3.8 7.71722L4.4624 7.25581L5.10332 7.71722L4.90406 6.8961L5.41877 6.37572H5.18136L5.7124 6.00581L6.22623 6.37572H5.9353L6.52364 6.8961L6.3 7.71722L6.9624 7.25581L7.60332 7.71722L7.40406 6.8961L7.91877 6.37572H7.68136L8.2124 6.00581L8.72623 6.37572H8.4353L9.02364 6.8961L8.8 7.71722L9.4624 7.25581L10.1033 7.71722L9.90406 6.8961L10.4188 6.37572H9.76369L9.46148 5.7056L9.20375 6.37572H8.83112L8.65406 5.6461L9.16877 5.12572H8.93136L9.4624 4.75581L10.1033 5.21722L9.90406 4.3961L10.4188 3.87572H9.76369L9.46148 3.2056L9.20375 3.87572H8.83112L8.65406 3.1461L9.16877 2.62572H8.93136L9.4624 2.25581L10.1033 2.71722L9.90406 1.8961L10.4188 1.37572H9.76369L9.46148 0.705605L9.20375 1.37572H8.4353L9.02364 1.8961L8.82492 2.62572H8.51369L8.21148 1.9556L7.95375 2.62572H7.58112L7.40406 1.8961L7.91877 1.37572H7.26369L6.96148 0.705605L6.70375 1.37572H5.9353L6.52364 1.8961L6.32492 2.62572H6.01369L5.71148 1.9556L5.45375 2.62572H5.08112L4.90406 1.8961L5.41877 1.37572H4.76369L4.46148 0.705605L4.20375 1.37572H3.4353L4.02364 1.8961L3.82492 2.62572H3.51369L3.21148 1.9556L2.95375 2.62572H2.58112L2.40406 1.8961L2.91877 1.37572H2.26369L1.96148 0.705605L1.70375 1.37572H0.935303L1.52364 1.8961L1.3 2.71722ZM8.82492 5.12572L9.02364 4.3961L8.4353 3.87572H8.72623L8.2124 3.50581L7.68136 3.87572H7.91877L7.40406 4.3961L7.58112 5.12572H7.95375L8.21148 4.4556L8.51369 5.12572H8.82492ZM7.47623 5.12572L6.9624 4.75581L6.43136 5.12572H6.66877L6.15406 5.6461L6.33112 6.37572H6.70375L6.96148 5.7056L7.26369 6.37572H7.57492L7.77364 5.6461L7.1853 5.12572H7.47623ZM5.27364 5.6461L5.07492 6.37572H4.76369L4.46148 5.7056L4.20375 6.37572H3.83112L3.65406 5.6461L4.16877 5.12572H3.93136L4.4624 4.75581L4.97623 5.12572H4.6853L5.27364 5.6461ZM5.45375 5.12572H5.08112L4.90406 4.3961L5.41877 3.87572H5.18136L5.7124 3.50581L6.22623 3.87572H5.9353L6.52364 4.3961L6.32492 5.12572H6.01369L5.71148 4.4556L5.45375 5.12572ZM3.82492 5.12572L4.02364 4.3961L3.4353 3.87572H3.72623L3.2124 3.50581L2.68136 3.87572H2.91877L2.40406 4.3961L2.58112 5.12572H2.95375L3.21148 4.4556L3.51369 5.12572H3.82492ZM7.77364 3.1461L7.57492 3.87572H7.26369L6.96148 3.2056L6.70375 3.87572H6.33112L6.15406 3.1461L6.66877 2.62572H6.43136L6.9624 2.25581L7.47623 2.62572H7.1853L7.77364 3.1461ZM4.97623 2.62572L4.4624 2.25581L3.93136 2.62572H4.16877L3.65406 3.1461L3.83112 3.87572H4.20375L4.46148 3.2056L4.76369 3.87572H5.07492L5.27364 3.1461L4.6853 2.62572H4.97623Z" fill="#F7FCFF"></path></g><defs><clipPath id="clip0_566_17133"><rect width="20" height="15" fill="white"></rect></clipPath></defs></svg>);


  return (
    
    
<>
<Search isOpens={isOpens} onClose={toggleModalCari} />

 <div
        className={`${isSidebarOpen ? 'block' : 'hidden'} fixed top-0 left-0 h-full bg-gray-800 text-white transition-all duration-300 ease-in-out`}
        style={{ zIndex: 10 }}
      >
        <div className="relative z-40 lg:hidden">
          <div className="fixed inset-0 bg-background/25 backdrop-blur-sm opacity-100"></div>
          <div className="fixed inset-0 z-40 flex">
            <div className="relative flex w-full max-w-xs flex-col overflow-y-auto bg-background pb-12 shadow-xl translate-x-0" id="headlessui-dialog-panel-:r7:" data-headlessui-state="open">
              <div className="flex flex-row-reverse items-center justify-between border-b border-dashed p-4">
               <button type="button" className="text-murky-400 -m-2 inline-flex items-center justify-center rounded-md p-2" tabIndex={0} onClick={handleCloseSidebar}>
                  <span className="sr-only">Close menu</span>
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-6 w-6">
 <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"></path>
                  </svg>
                </button>
                <div className="flex items-center">
                  <a className="relative h-10 w-24" href="/id" style={{ outline: 'none' }}>
                    <span className="sr-only">HARY-IT</span>
                    <Image
                      alt="HARY-IT"
                      fetchPriority="high"
                      decoding="async"
                      data-nimg="fill"
                      className="object-contain"
                      sizes="100vw"
                      width={100}
                      height={100}
                      srcSet="https://hary-server.id/logob12.png"
                      src="https://hary-server.id/logob12.png"
                      style={{ position: 'absolute', height: '100%', width: '100%', inset: '0px', color: 'transparent' }}
                    />
                  </a>
                </div>
              </div>
              <div className="space-y-2 border-y border-background p-4">
                <div>
                  <a
                    className="group flex items-center justify-between rounded-md px-4 py-2 font-medium text-foreground hover:bg-muted"
                    href="/id"
                    style={{ outline: 'none' }}
                  >
                    <span>Beranda</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="hidden h-5 w-5 group-hover:block">
                      <path fillRule="evenodd" d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z" clipRule="evenodd"></path>
                    </svg>
                  </a>
                </div>
                <div>
                  <a
                    className="group flex items-center justify-between rounded-md px-4 py-2 font-medium text-foreground hover:bg-muted"
                    href="/id/invoices"
                    style={{ outline: 'none' }}
                  >
                    <span>Cek Transaksi</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className ="hidden h-5 w-5 group-hover:block">
                      <path fillRule="evenodd" d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z" clipRule="evenodd"></path>
                    </svg>
                  </a>
                </div>
              </div>
              <div className="space-y-2 p-4">
                <div>
                  <a
                    className="group flex items-center justify-between rounded-md px-4 py-2 font-medium text-foreground hover:bg-muted"
                    href="/id/sign-in"
                    style={{ outline: 'none' }}
                  >
                    <span>Masuk</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="hidden h-5 w-5 group-hover:block">
                      <path fillRule="evenodd" d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z" clipRule="evenodd"></path>
                    </svg>
                  </a>
                </div>
                <div>
                  <a
                    className="group flex items-center justify-between rounded-md px-4 py-2 font-medium text-foreground hover:bg-muted"
                    href="/id/sign-up"
                    style={{ outline: 'none' }}
                  >
                    <span>Daftar</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" className="hidden h-5 w-5 group-hover:block">
                      <path fillRule="evenodd" d="M5 10a.75.75 0 01.75-.75h6.638L10.23 7.29a.75.75 0 111.04-1.08l3.5 3.25a.75.75 0 010 1.08l-3.5 3.25a.75.75 0 11-1.04-1.08l2.158-1.96H5.75A.75.75 0 015 10z" clipRule="evenodd"></path>
                    </svg>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
     <nav className="sticky top-0 z-40 w-full flex-none border-b border-border/50 bg-secondary/80 backdrop-blur print:hidden" style={{zIndex: 9} }>

        <div className="container">
        <div className="flex h-[60px] items-center">
        
        <button
        type="button"
        id="menu-toggle"
        className="rounded-md bg-secondary p-2 text-foreground lg:hidden"
        onClick={handleToggleSidebar}
      >
        <span className="sr-only">Open menu</span>
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-6 w-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"></path>
        </svg>
      </button>

    










<div className="ml-3 mr-2 flex lg:ml-0">
              <a className="relative h-8 w-24" href="/" style={{ outline: 'none' }}>
                <span className="sr-only">HARY-IT</span>
                <img alt="HARY-IT" fetchPriority="high" decoding="async" data-nimg="fill" className="object-contain" sizes="100vw" src="https://hary-server.id/logob12.png" style={{ position: 'absolute', height: '100%', width: '100%', inset: 0, color: 'transparent' }} />
              </a>
            </div>

              <div className="hidden lg:ml-10 lg:block lg:self-stretch">
                <div className="flex h-full space-x-6">
                  <a className="relative z-10 -mb-px flex items-center space-x-2 border-b-2 pt-px text-sm font-medium transition-colors duration-200 ease-out border-primary text-primary" href="id" style={{ outline: 'none' }}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-4 w-4">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>
                    </svg>
                    <span>Beranda</span>
                  </a>
                  <a style="color: white;" className="relative z-10 -mb-px flex items-center space-x-2 border-b-2 pt-px text-sm font-medium transition-colors duration-200 ease-out hover:text-primary-300 border-transparent hover:border-primary" href="/id/invoices" style={{ outline: 'none' }}>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-4 w-4">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"></path>
                    </svg>
                    <span >Cek Transaksi</span>
                  </a>
                </div>
             
 </div>


              <div className="ml-auto flex h-full items-center space-x-2 lg:space-x-6">
                <div className="flex flex-row-reverse items-center gap-x-2">

  

    <div className="relative inline-block text-left" ref={dropdownRef}>
      <div>
        <button
          onClick={toggleDropdown}
          className="inline-flex w-full items-center justify-center gap-x-2 rounded-lg border border-border/50 bg-transparent py-2 pl-4 pr-3 text-sm font-semibold uppercase text-foreground duration-300 ease-in-out hover:bg-muted/50"
          type="button"
          aria-haspopup="menu"
          aria-expanded={isOpen}
        >
          id
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 20 20"
            fill="currentColor"
            aria-hidden="true"
            className="h-4 w-4"
          >
            <path
              fillRule="evenodd"
              d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
              clipRule="evenodd"
            ></path>
          </svg>
        </button>
      </div>
      {isOpen && (
        <div className="absolute right-0 z-10 mt-2 w-48 origin-top-right divide-y divide-muted rounded-md bg-background shadow-lg ring-1 ring-muted ring-opacity-5 focus:outline-none">
          <div className="py-1" role="none">
            <button
              onClick={() => selectLanguage('Indonesia')}
              className="text-foreground group flex w-full items-center px-4 py-2 text-sm"
            >
              <span>
                {flagID}
              </span>
              <span className="ml-4">Indonesia</span>
            </button>
            <button
              onClick={() => selectLanguage('English')}
              className="text-foreground group flex w-full items-center px-4 py-2 text-sm"
            >
              <span>
                {flagEN}
              </span>
              <span className="ml-4">English</span>
            </button>
          </div>
        </div>
      )}
    </div>




  <button
        type="button" onClick={toggleModalCari}
        className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-border/50 bg-transparent px-2 py-2 text-sm font-semibold text-foreground duration-300 ease-in-out hover:bg-muted/50 sm:pl-3 sm:pr-4"
        
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="h-5 w-5 sm:h-4 sm:w-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"
          />
        </svg>
        <span className="hidden text-sm lg:block">Search</span>
      </button>




</div>
                  









 
  <div>
    {user ? (
      <div className="flex lg:flex-1 lg:items-center lg:justify-end lg:space-x-6">
      
        <div className="relative inline-block text-left">
        <div class="flex lg:flex-1 lg:items-center lg:justify-end lg:space-x-6"><div class="relative inline-block text-left" data-headlessui-state=""><div><button  id="dropdown-button" class="inline-flex w-full items-center justify-center gap-x-2 rounded-lg border border-border/50 bg-transparent p-2 text-sm font-semibold uppercase text-secondary-foreground duration-300 ease-in-out hover:bg-muted/50 hover:text-muted-foreground lg:p-1.5" onClick={toggleDropdowns} type="button" aria-haspopup="menu" aria-expanded={dropdownOpen} data-headlessui-state=""><img src={`https://ui-avatars.com/api/?color=FFFFFF&background=f97316&name=${user.full_name}`} alt="HARY-IT" class="size-5 rounded-full md:size-6" /></button></div></div></div>

          <div className= {`absolute right-0 z-10 mt-5 w-56 origin-top-right divide-y divide-muted rounded-md bg-background shadow-lg outline-none ring-1 ring-muted transform opacity-100 scale-100 ${dropdownOpen ? '' : 'hidden'}`} id="dropdown-menu" role="menu" style={{ outline: 'none'}}>
            <div className="px-4 py-3" role="none">
              <p className="text-sm">Telah masuk sebagai</p>
              <p className="truncate text-sm font-medium text-foreground">{user.email}</p>
            </div>
            <div className="py-1" role="none">

              <a href="/id/dashboard" className="text-murky-100 flex w-full items-center space-x-2 px-4 py-2 text-sm hover:bg-gray-800" role="menuitem">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-4 w-4">
                <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25"></path>
            </svg><span>Dashboard</span>
              </a>
              {user.level === 'Admin' && (
                <a href="/dash/dashboard/" className="text-murky-100 flex w-full items-center space-x-2 px-4 py-2 text-sm hover:bg-gray-800" role="menuitem">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-layout-dashboard h-4 w-4"><rect width="7" height="9" x="3" y="3" rx="1"></rect><rect width="7" height="5" x="14" y="3" rx="1"></rect><rect width="7" height="9" x="14" y="12" rx="1"></rect><rect width="7" height="5" x="3" y="16" rx="1"></rect></svg><span>Admin Dashboard</span>
                </a>
              )}
               <a className="text-murky-100 flex w-full items-center space-x-2 px-4 py-2 text-sm hover:bg-gray-800" id="headlessui-menu-item-:rf:" role="menuitem" tabindex="-1" data-headlessui-state="" href="/dashboard/reload" style={{ outline: 'none' }}>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-4 w-4">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H15a3 3 0 11-6 0H5.25A2.25 2.25 0 003 12m18 0v6a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18v-6m18 0V9M3 12V9m18 0a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 9m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v3"></path>
                                </svg><span>{user.balance}</span></a>
              <a href="/settings" className="text-murky-100 flex w-full items-center space-x-2 px-4 py-2 text-sm hover:bg-gray-800" role="menuitem">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" class="h-4 w-4">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z"></path>
                <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
            </svg> <span> Pengaturan </span>
              </a>
            </div>
            <div className="py-1" role="none">
              <button type="button" onClick={handleLogout} className="text-murky-100 flex w-full items-center space-x-2 px-4 py-2 text-left text-sm hover:bg-gray-800">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" className="h-4 w-4">
                <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9"></path>
            </svg>
               <span> Keluar</span>
              </button>
            </div>
          </div>
        </div>
        </div>

    ) : (
      <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-end lg:space-x-2">
        <a className="inline-flex items-center justify-center rounded-lg border border-border/50 px-4 py-2 text-sm font-medium text-foreground duration-300 ease-in-out hover:bg-muted/75" href="/id/sign-in" style={{ outline: 'none' }}>Masuk</a>
        <a className="inline-flex items-center justify-center rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground duration-300 hover:bg-primary/75" href="/id/sign-up" style={{ outline: 'none' }}>Daftar</a>
      </div>
    )}
  </div>


  </div>
            </div>
          </div>



   
      
    



        </nav>
       
</ >



  );
};

export default Navbar;