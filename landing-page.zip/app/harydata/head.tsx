// harydata/head.tsx
"use client";
import React from 'react';
import Script from 'next/script';

export default function HeadContent() {
  return (
    <>
      <link rel="shortcut icon" href="https://haryonokudadiri.com/favicon.png" />
      <Script src="https://code.jquery.com/jquery-3.6.0.min.js" />
    <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=haryalert.css" />
    <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=successhary.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/fs.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/dinda.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/swiper.css" />    
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/color.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/goober.css" /> 
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/fenyku.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/tabbody.css" />
      <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
      <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/tobrut.css" />
      
      

      <Script src="https://haryonokudadiri.com/check-file/?url=assets/js/tabhary.js" />
     
    </>
  );
}
