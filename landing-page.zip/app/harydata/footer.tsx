import type { NextPage } from 'next';
import CustomerSupport from './../func/CustomerSupport';
//import Search from './../func/Search';
const Footer = ({ isModalOpen, onClose }) => {
  return (

<footer className="bg-secondary print:hidden" aria-labelledby="footer-heading">
    <h2 id="footer-heading" className="sr-only">Footer</h2>
    <div className="container py-12 pb-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
            <div className="space-y-8"><img alt="Logo" fetchpriority="high" width="64" height="64" decoding="async" data-nimg="1" className="h-16 w-auto" srcset="https://haryonokudadiri.com/logob12.png" style={{ color: 'transparent'}} />
                <p className="text-sm leading-6 text-foreground">
                Menyediakan Top-Up Game Favorit Kamu Agar Main Game Semakin Seru. Pengiriman Cepat dan berbagai macam metode Pembayaran. Layanan 24 Jam, Proses hitungan detik. </p>
                <div className="flex space-x-6"><a href="https://www.facebook.com/haryonokudadiri" className="text-murky-400 hover:text-murky-500" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span className="sr-only">Facebook</span><img alt="Logo" fetchpriority="high" width="24" height="24" decoding="async" data-nimg="1" srcset="https://cdns.mobi/assets/media/fb.jpg" style={{ color: 'transparent'}} /></a>
                    <a
                    href="https://www.instagram.com/haryonokudadiri" className="text-murky-400 hover:text-murky-500" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span className="sr-only">Instagram</span><img alt="Logo" fetchpriority="high" width="24" height="24" decoding="async" data-nimg="1" srcset="https://cdns.mobi/assets/media/ig.jpg" style={{ color: 'transparent'}} /></a>
                        <a href="https://wa.me/6282273128721" className="text-murky-400 hover:text-murky-500" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span className="sr-only">Whatsapp</span><img alt="Logo" fetchpriority="high" width="24" height="24" decoding="async" data-nimg="1" srcset="https://cdns.mobi/assets/media/wa.jpg" style={{ color: 'transparent'}} /></a>
                </div>
            </div>
              <div className="mt-16 grid grid-cols-2 gap-8 md:grid-cols-4 xl:col-span-2">
                <div>
                    <h3 className="text-sm font-semibold leading-6 text-primary">Tentang Kami</h3>
                    <ul role="list" className="mt-6 space-y-4">
                        <li><a href="https://www.facebook.com/haryonokudadiri" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Facebook</span></a></li>
                        <li><a href="/" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Instagram</span></a></li>
                        <li><a href="/" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Linkedin</span></a></li>
                        <li><a href="/" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Corporate Site</span></a></li>
                    </ul>
                </div>
                <div>
                    <h3 className="text-sm font-semibold leading-6 text-primary">Peta Situs</h3>
                    <ul role="list" className="mt-6 space-y-4">
                        <li><a className="text-sm leading-6 text-foreground hover:text-primary/75" href="/" style={{ outline: 'none' }}><span>Beranda</span></a></li>
                        <li><a className="text-sm leading-6 text-foreground hover:text-primary/75" href="/" style={{ outline: 'none' }}><span>Masuk</span></a></li>
                        <li><a className="text-sm leading-6 text-foreground hover:text-primary/75" href="/" style={{ outline: 'none' }}><span>Daftar</span></a></li>
                        <li><a className="text-sm leading-6 text-foreground hover:text-primary/75" href="/" style={{ outline: 'none' }}><span>Cek Transaksi</span></a></li>
                        <li><a className="text-sm leading-6 text-foreground hover:text-primary/75" href="/" style={{ outline: 'none' }}><span>Ulasan</span></a></li>
                    </ul>
                </div>
                <div>
                    <h3 className="text-sm font-semibold leading-6 text-primary">Informasi</h3>
                    <ul role="list" className="mt-6 space-y-4">
                        <li><a href="/privacy-policy" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Kebijakan Privasi</span></a></li>
                        <li><a href="/terms-and-condition" className="text-sm leading-6 text-foreground hover:text-primary/75" target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}><span>Syarat &amp; Ketentuan</span></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div className="mt-16 flex items-center justify-between border-t border-background/50 pt-8 sm:mt-20 lg:mt-24">
            <p className="text-xs leading-5 text-foreground">© 2024 HARY-IT. All rights reserved.</p>
        </div>
    </div>

<CustomerSupport />

    </footer>



    );
};

export default Footer;