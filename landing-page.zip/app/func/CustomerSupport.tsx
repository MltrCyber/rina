// app/components/CustomerSupport.tsx
import React, { useState, useRef, useEffect } from 'react';

const CustomerSupport: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    const toggleMenu = () => {
        setIsOpen((prev) => !prev);
    };

    const handleClickOutside = (event: MouseEvent) => {
        if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
            setIsOpen(false);
        }
    };

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    return (
        <div>
            <button
                type="button"
                className="fixed bottom-0 right-4 z-50 inline-flex items-center space-x-2.5 rounded-t-lg bg-primary pb-2 pl-3 pr-3 pt-3 uppercase text-primary-foreground duration-300 ease-in-out hover:bg-primary md:pr-5"
                onClick={toggleMenu}
                aria-haspopup="menu"
                aria-expanded={isOpen}
            >
                <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-headset h-4 w-4"
                >
                    <path d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z" />
                    <path d="M21 16v2a4 4 0 0 1-4 4h-5" />
                </svg>
                <span className="hidden text-xs font-medium md:inline">Chat CS</span>
            </button>

            {isOpen && (
                <div
                    ref={menuRef}
                    style={{
                        position: 'fixed',
                        bottom: '40px',
                        right: '16px',
                        zIndex: 100,
                    }}
                    data-side="top"
                    data-align="end"
                    role="menu"
                    aria-orientation="vertical"
                    className="z-50 min-w-[200px] max-w-[300px] rounded-md border bg-popover p-2 text-popover-foreground shadow-md"
                >
                    <div className="px-2 py-1.5 text-sm font-semibold">Customer Support</div>
                    <div role="separator" className="-mx-1 my-1 h-px bg-muted"></div>
                    <div>
                        <div>
                            <a
                                href="https://www.facebook.com/YOUR_FACEBOOK_LINK"
                                className="relative flex items-center rounded-sm px-2 py-2 text-sm transition-colors duration-300 hover:bg-green-500 hover:text-white"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <span>Facebook</span>
                            </a>
                        </div>
                        <div>
                            <a
                                href="https://www.instagram.com/YOUR_INSTAGRAM_LINK"
                                className="relative flex items-center rounded-sm px-2 py-2 text-sm transition-colors duration-300 hover:bg-green-500 hover:text-white"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <span>Instagram</span>
                            </a>
                        </div>
                        <div>
                            <a
                                href="https://wa.me/YOUR_WHATSAPP_LINK"
                                className="relative flex items-center rounded-sm px-2 py-2 text-sm transition-colors duration-300 hover:bg-green-500 hover:text-white"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                <span>Whatsapp</span>
                            </a>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CustomerSupport;
