// app/components/ProdukRekomendasi.tsx

import { useEffect, useState } from 'react';

interface Kategori {
  cuid: number;
  kategori: string;
  image: string; // Ganti sesuai dengan field gambar
  owner: string; // Ganti sesuai dengan field deskripsi
}

const ProdukRekomendasi: React.FC = () => {
  const [kategori, setKategori] = useState<Kategori[]>([]);
const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    const fetchKategori = async () => {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/populer`);
      const data = await res.json();
      setKategori(data);
      setLoading(false);
    };

    fetchKategori();
  }, []);

 if (loading) {
    return ( 
      <div className="container">
     <div class="mb-5 text-foreground">
                <h3 class="text-lg font-semibold uppercase leading-relaxed tracking-wider">✨ REKOMENDASI</h3>
                <p class="pl-6 text-xs">Berikut adalah beberapa produk yang kami rekomendasikan untuk kamu.</p>
              </div>
            <div class="grid grid-cols-2 gap-4 md:grid-cols-3">
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
                <div class="h-[96px] w-full animate-pulse rounded-lg bg-muted"></div>
            </div>
            </div>
            );
  }

  return (
    <div className="container">
      <div className="mb-5">
        <h3 className="text-lg font-semibold uppercase leading-relaxed tracking-wider">✨ REKOMENDASI</h3>
        <p className="pl-6 text-xs">Berikut adalah beberapa produk yang kami rekomendasikan untuk kamu.</p>
      </div>

      <ul className="grid grid-cols-2 gap-4 rounded-3xl bg-muted/50 p-3 md:grid-cols-3 lg:min-h-[120px]">
        {kategori.map(item => (
          <li key={item.id} className="[--card-padding:theme(spacing.2)] [--card-radius:theme(borderRadius.2xl)]">
            <a className="flex items-center gap-x-2 rounded-[--card-radius] bg-muted duration-300 ease-in-out hover:shadow-2xl hover:ring-2 hover:ring-primary hover:ring-offset-2 hover:ring-offset-background md:gap-x-3 bg-title-product" href="/">
              <div className="flex items-center gap-3 p-[--card-padding]">
                <img 
                  alt={item.kategori} 
                  fetchpriority="high" 
                  width="56" 
                  height="56" 
                  className="aspect-square h-14 w-14 rounded-[calc(var(--card-radius)-var(--card-padding))] object-cover object-center ring-1 ring-background md:h-20 md:w-20" 
                  src={`https://cdns.mobi/upload/${item.image}`} // Ganti dengan URL gambar yang sesuai
                />
                <div className="relative flex w-full flex-col">
                  <h2 className="text-murky-200 w-[100px] truncate text-xxs font-semibold sm:w-[125px] md:w-[150px] md:text-base lg:w-[175px]">{item.kategori}</h2>
                  <p className="text-murky-300 text-xxs md:text-sm">{item.owner}</p> {/* Ganti dengan deskripsi yang sesuai */}
                </div>
              </div>
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProdukRekomendasi;
