import { useEffect, useState } from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import { Autoplay , Pagination , Navigation } from 'swiper'; // Import Autoplay

interface Slide {
  image: string;
  deskripsi: string;
  url: string;
}

const SlideShow = () => {
  const [slides, setSlides] = useState<Slide[]>([]);
  const [cdn, setCdn] = useState<string | null>(null);

  useEffect(() => {
    const fetchSlides = async () => {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/banner`);
        const data = await response.json();
        setSlides(data.data);
        setCdn(data.cdn.dash); // Access 'dash' directly from the 'cdn' object
      } catch (error) {
        console.error('Error fetching slides:', error);
      }
    };
  
    fetchSlides();
  }, []);

  return (
    <Swiper
      className="swiper-container container swiper-backface-hidden"
      direction="horizontal"
      loop={true}
      autoplay={{
        delay: 2500,
      }}
      pagination={{
        clickable: true,
        el: '.swiper-pagination',
      }}
      navigation={{
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }}
      modules={[Autoplay , Pagination , Navigation]}
    >
      {slides.map((slide) => (
        <SwiperSlide key={slide.cuid} className="swiper-slide">
          <a href={slide.url} target="_blank" rel="noopener noreferrer" style={{ outline: 'none' }}>
            <div className="relative aspect-[1080/424] h-full">
              <img
                alt={slide.deskripsi}
                fetchPriority="high"
                decoding="async"
                data-nimg="fill"
                className="rounded-3xl"
                sizes="100vw"
                srcSet={`${cdn}/upload/${slide.image}`} 
                src={`${cdn}/upload/${slide.image}`} 
                style={{ position: 'absolute', height: '100%', width: '100%', inset: 0, color: 'transparent' }}
              />
            </div>
          </a>
        </SwiperSlide>
      ))}
      <div className="swiper-pagination"></div>
      <div className="z-50 hidden items-center justify-end space-x-2 md:flex">
        <button type="button" className="swiper-button swiper-button-prev !ml-8">
          <div className="flex aspect-square h-12 w-12 scale-75 items-center justify-center rounded-full bg-muted/50 shadow-2xl sm:scale-100">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-8 w-8 pr-1">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5"></path>
            </svg>
          </div>
        </button>
        <button type="button" className="swiper-button swiper-button-next !mr-8">
          <div className="flex aspect-square h-12 w-12 scale-75 items-center justify-center rounded-full bg-muted/50 shadow-2xl sm:scale-100">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" aria-hidden="true" className="h-8 w-8 pl-1">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"></path>
            </svg>
          </div>
        </button>
      </div>
    </Swiper>
  );
};

export default SlideShow;