import { useRef, useEffect, useState } from 'react';

interface Kategori {
  cuid: number;
  kategori: string;
  image: string;
  owner: string;
  slug: string;
  parent: number;
  categoryName: string;
}

const ProdukGame: React.FC = () => {
  const [kategori, setKategori] = useState<Kategori[]>([]);
  const [visibleCount, setVisibleCount] = useState(12); // Untuk melacak jumlah item yang ditampilkan
    const [loadMoreCount, setLoadMoreCount] = useState(0);
    const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const fetchKategori = async () => {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/Game`);
      const data = await res.json();
      setKategori(data.data);
       setLoading(false);
    };

    fetchKategori();
  }, []);

  const loadMore = () => {
    setVisibleCount((prevCount) => prevCount + 12); // Menambah jumlah item yang ditampilkan
       setLoadMoreCount((prevCount) => prevCount + 1); 
  };
   const [activeTab, setActiveTab] = useState(1);
const tabListRef = useRef<HTMLDivElement>(null);
  const showTab = (tabIndex: number) => {
    setActiveTab(tabIndex);
  };

const scrollTab = (direction: 'left' | 'right') => {
    if (tabListRef.current) {
      const { scrollLeft, clientWidth } = tabListRef.current;
      const scrollAmount = direction === 'left' ? scrollLeft - clientWidth : scrollLeft + clientWidth;
      tabListRef.current.scrollTo({ left: scrollAmount, behavior: 'smooth' });
    }
  };

const uniqueCategories = Array.from(new Set(kategori.map(item => item.categoryName)))
  .filter(categoryName => categoryName !== null); // Filter untuk menghindari null

const uniqueParents = Array.from(new Set(kategori.map(item => item.parent)))
  .map(parentId => kategori.find(item => item.parent === parentId));



 if (loading) {
    return (
       <div class="container">
            <button
      type="button"
      aria-hidden="true"
      style={{
        position: 'absolute', // Gunakan absolute agar tidak mengganggu layout
        width: '1px',
        height: '1px',
        padding: 0,
        margin: '-1px',
        overflow: 'hidden',
        clip: 'rect(0, 0, 0, 0)',
        whiteSpace: 'nowrap',
        border: 0,
      }}
    ></button>
            <div role="tablist" aria-orientation="horizontal">
                <div class="hide-scrollbar -mb-px flex space-x-3 overflow-auto">
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                    <div class="h-9 w-24 animate-pulse whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm outline-none"></div>
                </div>
            </div>
            <div>
                <div class="my-8 grid grid-cols-3 gap-4 sm:grid-cols-4 sm:gap-x-6 sm:gap-y-8 lg:grid-cols-5 xl:grid-cols-6">
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                    <div class="relative aspect-[4/6] w-full animate-pulse overflow-hidden rounded-xl bg-muted"></div>
                </div>
            </div>
        </div>);
}

  return (
    <div>

              <div role="tablist" aria-orientation="horizontal">
    <div class="flex items-center gap-2">
                 <div class="block lg:hidden">



            <button
          className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90 h-9 w-9"
          type="button"
          onClick={() => scrollTab('left')}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-left h-4 w-4">
            <path d="m15 18-6-6 6-6"></path>
          </svg>
        </button>
        </div>
        <div class="apapunitusayang hide-scrollbar -mb-px flex transform items-center gap-2 space-x-3 overflow-auto duration-300 ease-in-out" ref={tabListRef}>

{uniqueCategories.map((categoryName, index) => {
  const item = kategori.find(item => item.categoryName === categoryName) || {}; // Menghindari error jika tidak ditemukan

  const isSelected = activeTab === item.parent;
  const buttonClassName = isSelected
    ? 'whitespace-nowrap rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-semibold outline-none duration-300 focus:bg-primary focus-visible:bg-primary hover:bg-primary/75'
    : 'whitespace-nowrap rounded-lg bg-muted px-4 py-2 text-sm font-semibold text-foreground outline-none duration-300 focus:bg-primary focus-visible:bg-primary';




 return (
    <button
      key={index}
      className={buttonClassName}
      role="tab"
      type="button"
      aria-selected={activeTab === item.parent}
      tabIndex={0}
      onClick={() => showTab(item.parent)}
    >
      {categoryName}
    </button>
  );
})}
                  </div>


            <div class="block lg:hidden">
            <button
          className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90 h-9 w-9"
          type="button"
          onClick={() => scrollTab('right')}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-chevron-right h-4 w-4">
            <path d="m9 18 6-6-6-6"></path>
          </svg>
        </button>
        </div>

    </div>
</div>

 {uniqueParents.map((item) => (
  <ul className="my-8" key={item?.parent}>
    <div 
      id={`tab-${item?.parent}`} 
      className={`tab-panel ${activeTab === item?.parent ? 'active' : 'hidden'}`} 
      role="tabpanel" 
      tabIndex={0} 
      aria-labelledby={`tab-${item?.parent}`}>
      <div>
        <div id="data-container" className="mb-4 grid grid-cols-3 gap-4 sm:mb-8 sm:grid-cols-4 sm:gap-x-6 sm:gap-y-8 lg:grid-cols-5 xl:grid-cols-6">
          {kategori
            .filter(k => k.parent === item.parent) // Filter sesuai parent
            .slice(0, visibleCount)
            .map((item, index) => (
              <a className="tobrut" key={item.cuid} tabIndex={0} href={`/id/${item.slug}`} style={{ outline: 'none', '--i': index % 12 }}>
                <div className="scale-on-hover group relative transform overflow-hidden rounded-2xl bg-muted duration-300 ease-in-out hover:shadow-2xl hover:ring-2 hover:ring-primary hover:ring-offset-2 hover:ring-offset-background">
                  <img
                    alt={item.kategori}
                    fetchPriority="high"
                    width="192"
                    height="288"
                    decoding="async"
                    className="aspect-[4/6] object-cover object-center"
                    srcSet={`https://cdns.mobi/upload/${item.image}`}
                  />
                  <article className="absolute inset-x-0 -bottom-10 z-10 flex transform flex-col px-3 transition-all duration-300 ease-in-out group-hover:bottom-3 sm:px-4 group-hover:sm:bottom-4">
                    <h2 className="text-murky-200 truncate text-sm font-semibold sm:text-base">{item.kategori}</h2>
                    <p className="text-murky-400 truncate text-xxs sm:text-xs">{item.owner}</p>
                  </article>
                  <div className="absolute inset-0 transform bg-gradient-to-t from-transparent transition-all duration-300 group-hover:from-background"></div>
                </div>
              </a>
            ))}
        </div>
        <div className="text-center">
          {visibleCount < kategori.filter(k => k.parent === item.parent).length && ( // Hanya tampilkan tombol jika masih ada item yang bisa dimuat
            <button
              id="show-more-button"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2"
              type="button"
              onClick={loadMore}
            >
              Tampilkan Lainnya...
            </button>
          )}
        </div>
      </div>
    </div>
  </ul>
))}

    </div>
  );
};

export default ProdukGame;
