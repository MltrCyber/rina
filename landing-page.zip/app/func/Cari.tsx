// components/SearchButton.tsx
import React, { useState, useEffect } from 'react';
import Search from './Search';

const SearchButton: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleButtonClick = () => {
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  useEffect(() => {
    

    // Cleanup function to reset the overflow when the component unmounts
    return () => {
      //document.body.style.overflow = 'auto';
    };
  }, [isModalOpen]);

  return (
    <>
      <button
        type="button"
        className="inline-flex w-full items-center justify-center gap-2 rounded-lg border border-border/50 bg-transparent px-2 py-2 text-sm font-semibold text-foreground duration-300 ease-in-out hover:bg-muted/50 sm:pl-3 sm:pr-4"
        onClick={handleButtonClick}
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          strokeWidth="1.5"
          stroke="currentColor"
          className="h-5 w-5 sm:h-4 sm:w-4"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z"
          />
        </svg>
        <span className="hidden text-sm lg:block">Search</span>
      </button>
      <Search  isOpen={isModalOpen} onClose={handleCloseModal} />
    </>
  );
};

export default SearchButton;
