import React, { useEffect, useState } from 'react';
import Script from 'next/script';
import Image from 'next/image';
interface Product {
  id: number;
  kategori: string;
  image: string;
  title: string;
  slug: string;
  harga_jual: number;
  discount: number; // New field for the discount amount
}

const FlashSale: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/flashsale`); // Adjust your API endpoint
      const data: Product[] = await res.json();
      setProducts(data);
    };

    fetchProducts();
  }, []);


  const baseSpeed = 20; // Kecepatan dasar
  const speedFactor = 2; // Faktor untuk penyesuaian kecepatan
  const speed = baseSpeed + (products.length * speedFactor);


  
    const [dateTime, setDateTime] = useState(null);
    //const [loading, setLoading] = useState(true);
    const [loading, setLoading] = useState<boolean>(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/getflashsale`);
                const result = await response.json();
                setDateTime(result.dateTime);
            } catch (error) {
                console.error('Error fetching data:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchData();
    }, []);

     if (loading) {
    return (


<div className="flex flex-col gap-y-8 pt-8">
<div className="container">
<div className="rounded-2xl bg-muted/50">
        <div className="px-4 pb-3 pt-4">
            <h3 className="flex items-center space-x-4 text-foreground"><div className="text-lg font-semibold uppercase leading-relaxed tracking-wider">⚡️ FLASH SALE</div><div className="flex items-center gap-1 text-sm capitalize"><div className="flex h-7 w-7 items-center justify-center rounded-md bg-background animate-pulse " id="dayas"></div><div className="flex h-7 w-7 items-center justify-center rounded-md bg-background animate-pulse " id="ahours"></div><div className="flex h-7 w-7 items-center justify-center rounded-md bg-background animate-pulse " id="minutaes"></div><div className="flex h-7 w-7 items-center justify-center rounded-md bg-background animate-pulse " id="secoands"></div></div></h3>
            <p className="pl-6 text-xs text-foreground">Pesan sekarang! Persediaan terbatas. </p>
        </div>
        <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden pb-2 pt-1">
            <div className="group flex overflow-hidden p-2 [--gap:1rem] [gap:var(--gap)] flex-row container [--duration:20s]">

              



                                        <a className="relative w-[265px] animate-pulse  cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60" style={{ outline: 'none'}}>
                        <div className="flex flex-row items-center gap-3"><Image src="https://cdns.mobi/assets/banner/subimage.png" loading="lazy" width="48" height="48" decoding="async" data-nimg="1" className="rounded-lg bg-muted" />
                            <div className="flex flex-col">
                                <figcaption className="text-sm font-medium text-foreground"></figcaption>
                                <p className="text-xs font-medium text-destructive line-through"></p>
                                <p className="text-xs font-medium text-primary"></p>
                            </div>
                        </div>
                        <div className="mt-2 text-sm text-foreground"></div>
                       
                    </a>
                     <a className="relative w-[265px] animate-pulse  cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60" style={{ outline: 'none'}}>
                        <div className="flex flex-row items-center gap-3"><Image src="https://cdns.mobi/assets/banner/subimage.png" loading="lazy" width="48" height="48" decoding="async" data-nimg="1" className="rounded-lg bg-muted" />
                            <div className="flex flex-col">
                                <figcaption className="text-sm font-medium text-foreground"></figcaption>
                                <p className="text-xs font-medium text-destructive line-through"></p>
                                <p className="text-xs font-medium text-primary"></p>
                            </div>
                        </div>
                        <div className="mt-2 text-sm text-foreground"></div>
                       
                    </a>
                     <a className="relative w-[265px] animate-pulse  cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60" style={{ outline: 'none'}}>
                        <div className="flex flex-row items-center gap-3"><Image src="https://cdns.mobi/assets/banner/subimage.png" loading="lazy" width="48" height="48" decoding="async" data-nimg="1" className="rounded-lg bg-muted" />
                            <div className="flex flex-col">
                                <figcaption className="text-sm font-medium text-foreground"></figcaption>
                                <p className="text-xs font-medium text-destructive line-through"></p>
                                <p className="text-xs font-medium text-primary"></p>
                            </div>
                        </div>
                        <div className="mt-2 text-sm text-foreground"></div>
                       
                    </a>
                     <a className="relative w-[265px] animate-pulse  cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60" style={{ outline: 'none'}}>
                        <div className="flex flex-row items-center gap-3"><Image src="https://cdns.mobi/assets/banner/subimage.png" loading="lazy" width="48" height="48" decoding="async" data-nimg="1" className="rounded-lg bg-muted" />
                            <div className="flex flex-col">
                                <figcaption className="text-sm font-medium text-foreground"></figcaption>
                                <p className="text-xs font-medium text-destructive line-through"></p>
                                <p className="text-xs font-medium text-primary"></p>
                            </div>
                        </div>
                        <div className="mt-2 text-sm text-foreground"></div>
                       
                    </a>
                     <a className="relative w-[265px] animate-pulse  cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60" style={{ outline: 'none'}}>
                        <div className="flex flex-row items-center gap-3"><Image src="https://cdns.mobi/assets/banner/subimage.png" loading="lazy" width="48" height="48" decoding="async" data-nimg="1" className="rounded-lg bg-muted" />
                            <div className="flex flex-col">
                                <figcaption className="text-sm font-medium text-foreground"></figcaption>
                                <p className="text-xs font-medium text-destructive line-through"></p>
                                <p className="text-xs font-medium text-primary"></p>
                            </div>
                        </div>
                        <div className="mt-2 text-sm text-foreground"></div>
                       
                    </a>
                    
                               </div>
            </div>
        </div>
        </div>
        </div>
        


      );
  }
  return (

    <div className="flex flex-col gap-y-8 pt-8">
     {dateTime ? (
      <Script src="https://haryonokudadiri.com/check-file/?url=assets/times.js" data-time={dateTime}  />
 ) : (
                ''
            )}
      <div className="container">
        <div className="rounded-2xl bg-muted/50">
          <div className="px-4 pb-3 pt-4">
            <h3 className="flex items-center space-x-4 text-foreground">
              <div className="text-lg font-semibold uppercase leading-relaxed tracking-wider">⚡️ FLASH SALE</div>
              <div className="flex items-center gap-1 text-sm capitalize">
                <div className="flex h-7 w-7 items-center justify-center rounded-md bg-background" id="days">0</div>
                <div className="flex h-7 w-7 items-center justify-center rounded-md bg-background" id="hours">0</div>
                <div className="flex h-7 w-7 items-center justify-center rounded-md bg-background" id="minutes">0</div>
                <div className="flex h-7 w-7 items-center justify-center rounded-md bg-background" id="seconds">0</div>
              </div>
            </h3>
            <p className="pl-6 text-xs text-foreground">Berikut adalah beberapa produk yang kami rekomendasikan untuk kamu.</p>
          </div>
          <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden pb-2 pt-1">
            <div className="group flex overflow-hidden p-2 [--gap:1rem] [gap:var(--gap)] flex-row container"style={{ '--duration': `${speed}s` }}>
              <div
                data-run-marquee="true"
                data-run-marquee-vertical="false"
                className="flex shrink-0 justify-around [gap:var(--gap)] data-[run-marquee-vertical=true]:animate-marquee-vertical data-[run-marquee=true]:animate-marquee data-[run-marquee]:flex-row data-[run-marquee-vertical=true]:flex-col group-hover:[animation-play-state:paused]"
                
              >
                {products.map((product) => (
                  <a
                    key={product.id}
                    href={`/id/${product.slug}?hary=${product.id}`}
                    className="relative w-[265px] cursor-pointer rounded-xl border p-4 border-muted/75 bg-muted/50 hover:bg-muted/60"
                  >
                    <div className="flex flex-row items-center gap-3">
                      <Image
                        src={`https://cdns.mobi/upload/${product.image}`}
                        alt={product.title}
                        width={48}
                        height={48}
                        className="rounded-lg bg-muted"
                      />
                      <div className="flex flex-col">
                        <figcaption className="text-sm font-medium text-foreground">
                          {product.kategori}
                        </figcaption>
                        <p className="text-xs font-medium text-destructive line-through">
                          Rp. {new Intl.NumberFormat('id-ID').format(product.harga_jual)}
                        </p>
                        <p className="text-xs font-medium text-primary">
                          Rp. {new Intl.NumberFormat('id-ID').format(product.discount)}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 text-sm text-foreground">{product.title}</div>
                    <div className="w-24 absolute aspect-square -top-[9px] -right-[9px] overflow-hidden rounded-sm">
                      <div className="absolute top-0 left-0 bg-primary/50 h-2 w-2"></div>
                      <div className="absolute bottom-0 right-0 bg-primary/50 h-2 w-2"></div>
                      <div className="absolute block w-square-diagonal py-1 text-center text-xxs font-semibold uppercase bottom-0 right-0 rotate-45 origin-bottom-right shadow-sm bg-primary text-primary-foreground">
                        Rp. {new Intl.NumberFormat('id-ID').format(product.harga_jual - product.discount)}
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FlashSale;
