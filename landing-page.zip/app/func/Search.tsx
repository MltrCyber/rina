import React, { useEffect, useState } from 'react';
import Image from 'next/image';

interface Recommendation {
  kategori: string;
  slug: string;
  image: string;
}

interface ModalProps {
  isOpens: boolean;
  onClose: () => void;
}

const defaultRecommendations: Recommendation[] = [
  // Add your default/popular recommendations here
  
];


const Modal: React.FC<ModalProps> = ({ isOpens, onClose }) => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>(defaultRecommendations);
  const [searchTerm, setSearchTerm] = useState('');
const [hoveredIndex, setHoveredIndex] = useState(-1); 
  useEffect(() => {
    if (isOpens) {
      const fetchRecommendations = async () => {
        try {
          const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/search`);
          if (!response.ok) throw new Error('Network response was not ok');
          const data = await response.json();
          setRecommendations(data.data);
        } catch (error) {
          console.error('Failed to fetch recommendations:', error);
        }
      };

      fetchRecommendations();
      document.body.style.overflow = 'hidden'; // Menonaktifkan scroll saat modal terbuka
    } else {
      document.body.style.overflow = 'unset'; // Mengembalikan scroll saat modal tertutup
    }
  }, [isOpens]);
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const modalElement = document.getElementById('modal');
      if (modalElement && !modalElement.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpens) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpens, onClose]);

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value.trim();
    
  
    setSearchTerm(term);

    if (term.length > 0) {
      try {
        const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/cari?term=${encodeURIComponent(term)}`);
        if (!response.ok) throw new Error('Network response was not ok');
        const data: Recommendation[] = await response.json();
        setRecommendations(data);
      } catch (error) {
        console.error('Failed to fetch recommendations:', error);
        setRecommendations([]); // Clear recommendations on error
      }
    } else {
      setRecommendations(defaultRecommendations); // Reset to default when input is empty
    }
  };

  if (!isOpens) return null;

  return (
    <div>
      <div style={{ zIndex: 10 }} className="fixed inset-0 bg-muted/25 transition-opacity opacity-100"></div>

      <div className="relative z-50" role="dialog" aria-modal="true">
        <div className="fixed inset-0 z-50 overflow-hidden p-4 py-20 sm:px-6 sm:py-20 md:p-20">
          <div className="mx-auto max-w-2xl transform divide-y divide-muted divide-opacity-10 overflow-hidden rounded-xl bg-muted bg-opacity-80 font-sans shadow-2xl ring-1 ring-black ring-opacity-5 backdrop-blur backdrop-filter transition-all">
            <div id="modal">
              <div className="relative">
                <input
                  className="h-12 w-full border-0 bg-transparent pl-11 pr-4 text-foreground placeholder:text-foreground focus:ring-0 sm:text-sm"
                  placeholder="Search..."
                  id="search-input"
                  type="text"
                  onChange={handleSearch}
                  value={searchTerm}
                />
              </div>

            {recommendations.length > 0 ? (
        <ul className="max-h-80 overflow-y-auto divide-y divide-muted divide-opacity-10" role="listbox">
          <li className="p-2">
            {searchTerm === '' && (
        <h2 className="mb-2 mt-4 px-3 text-xs font-semibold text-foreground">Rekomendasi</h2>
      )}
            <ul className="text-sm text-foreground">
              {recommendations.map((item, index) => (
                <a href={`/id/${item.slug}`}  key={index}>

                <li
                  key={item.slug}
                  className={`flex cursor-default select-none items-center rounded-lg px-3 py-2 transition-colors duration-200 ${
                    hoveredIndex === index ? 'bg-background/50 bg-opacity-5' : ''
                  }`}
                 
                  onMouseEnter={() => setHoveredIndex(index)}
                  onMouseLeave={() => setHoveredIndex(-1)}
                >
                  <Image
                    alt={item.kategori}
                    loading="lazy"
                    width={300}
                    height={300}
                    className="aspect-square w-24 rounded-2xl object-cover"
                    src={`https://cdns.mobi/upload/${item.image}`} // Update with your CDN or path
                  />
                  <span className="ml-3 flex-auto truncate">{item.kategori}</span>
                  {hoveredIndex === index && (
              <span className="ml-3 flex-none text-foreground">Jump to...</span>
            )}
                </li></a>
              ))}
            </ul>
          </li>
        </ul>
      ) : (
        <div className="flex flex-col items-center justify-center px-6 py-14 sm:px-14">
          <p className="mt-4 text-sm text-foreground">We couldn&apos;t find any products with that term. Please try again.</p>
        </div>
      )}
    



            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modal;
