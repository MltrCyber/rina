// ../../app/assets/login.js
const Head = () => (
    <>
        <link rel="shortcut icon" href="https://haryonokudadiri.com/favicon.png" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/fs.css" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/dinda.css" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/swiper.css" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/color.css" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/goober.css" />
        <link rel="stylesheet" type="text/css" href="https://haryonokudadiri.com/check-file/?url=assets/css/fenyku.css" />
    </>
);

export default Head;
