// pages/index.tsx
import Link from 'next/link';

const Home = () => {
  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-background/50 text-primary-foreground md:flex-row">
      <svg
        width="1024"
        height="244"
        viewBox="0 0 1024 244"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="absolute right-0 top-0 text-background"
      >
        <path d="M61.5 65C33.1 55.4 8.66667 17.6667 0 0H1024V244C970.833 196.667 847.1 97 777.5 77C690.5 52 97 77 61.5 65Z" fill="currentColor"></path>
      </svg>
      <svg
        width="1024"
        height="244"
        viewBox="0 0 1024 244"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="absolute bottom-0 left-0 text-background"
      >
        <path d="M962.5 179C990.9 188.6 1015.33 226.333 1024 244H0V0C53.1667 47.3333 176.9 147 246.5 167C333.5 192 927 167 962.5 179Z" fill="currentColor"></path>
      </svg>
      <Link href="https://hary-server.id">
        <img
          alt="HARY IT Logo"
          src="https://hary-server.id/H_A_R_Y_-_I_T.png"
          width={765}
          height={765}
          className="size-56 md:size-96"
        />
      </Link>
      <div className="relative z-20 flex flex-col items-center justify-center gap-3 px-4 text-center md:items-start md:text-left">
        <h1 className="text-2xl font-bold md:text-4xl">404</h1>
        <p className="order-first text-base font-semibold">This page does not exist</p>
        <p className="text-base font-semibold">Sorry, we couldn’t find the page you’re looking for.</p>
        <div className="flex gap-2 pt-2">
          <Link href="/">
            <button className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-xs font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-transparent bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2">
              Go back home
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
