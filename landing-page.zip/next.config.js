module.exports = {
  // ... konfigurasi lainnya
  env: {
    JWT_SECRET: process.env.JWT_SECRET,
  },
  images: {
    domains: ['hary-server.id','haryonokudadiri.com','cdns.mobi','cdn.bangjeff.com','client-cdn.bangjeff.com'],
  },
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:3000/api/:path*'
      }
    ]
  }
}