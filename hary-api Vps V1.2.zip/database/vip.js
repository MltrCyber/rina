const { User } = require('./model');
const toMs = require('ms');
const { limitCount, limitVip } = require('../lib/settings');

    async function addVip(username, expired) {
        User.updateOne({username: username}, { vip: Date.now() + toMs(expired), limit: limitVip, function (err, res) {
            if (err) throw err;
        })
    }
    module.exports.addVip = addVip

    async function ExpiredTime() {
        let users = await User.find({});
        users.forEach(async(data) => {
            let { vip, defaultKey, username } = data
            if (!vip || vip === null) return
            if (Date.now() >= vip) {
                User.updateOne({username: username}, {apikey: defaultKey, vip: null, limit: limitCount}, function (err, res) {
                    if (err) throw err;
                    console.log(`Masa vip ${username} sudah habis`)
                })
            }
        })
    }
    module.exports.ExpiredTime = ExpiredTime

    async function deletevip(username) {
        let users = await User.findOne({username: username});
        let key = users.defaultKey
        User.updateOne({username: username}, {apikey: key, vip: null, limit: limitCount}, function (err, res) {
            if (err) throw err;
        })
    }
    module.exports.deletevip = deletevip

    async function checkvip(username) {
        let users = await User.findOne({username: username});
        if (users.vip === null) {
            return false;
        } else {
            return true;
        };
    };
    module.exports.checkvip = checkvip;

    async function changeKey(username, key) {
        User.updateOne({username: username}, {apikey: key}, function (err, res) {
            if (err) throw err;
        });
    }
    module.exports.changeKey = changeKey

    async function getTotalUser() {
        let db = await User.find({})
        return db.length
    }
    module.exports.getTotalUser = getTotalUser