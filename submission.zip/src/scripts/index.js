import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

document.addEventListener("DOMContentLoaded", async () => {
    // set toggle sidebar
    const sidebar = document.querySelector("#sidebar");
    const buttonNav = document.querySelector("#hamburger");

    buttonNav.addEventListener('click', e => {
        sidebar.classList.toggle('active');
        e.stopPropagation();
    })

    // remove active sidebar when user click outside sidebar
    document.addEventListener('click', e => {
        if (e.target !== sidebar && e.target !== buttonNav) {
            sidebar.classList.remove('active');
            e.stopPropagation();
        }
    })

    // mapping data restaurant
    const restaurantContainer = document.querySelector(".restaurant-list");
    const datas = await getDataRestaurant();
    datas.restaurants.forEach(data => {
        restaurantContainer.innerHTML += createCardRestaurant(data);
    });
});

// function for create card restaurant element
const createCardRestaurant = function (data) {
    return `
    <div class="card" tabindex="0">
        <div class="card-img">
            <span>${data.city}</span>
            <img src="${data.pictureId}" alt="${data.name}">
        </div>
        <div class="card-content">
            <span class="card-rating">${data.rating}</span>
            <h3 class="card-title">${data.name}</h3>
            <p class="card-description">${data.description}</p>
        </div>
    </div>
    `
}

// function for get data restaurant
const getDataRestaurant = function () {
    return new Promise((resolve, reject) => {
        fetch(`${window.location.origin}/DATA.json`)
            .then(res => res.json())
            .then(data => {
                resolve(data);
            }).catch(err => {
                reject(err);
            })
    });
}