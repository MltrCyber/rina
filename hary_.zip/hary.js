    //const { Client, Location, List, Buttons, LocalAuth } = require('./index');
  const cors = require("cors");
  const session = require('express-session');
  const cookieParser = require('cookie-parser');
  const expressLayout = require('express-ejs-layouts');
  const passport = require('passport');
  const flash = require('connect-flash');
  const schedule = require('node-schedule');
  const MemoryStore = require('memorystore')(session);
  const rateLimit = require("express-rate-limit");
  var logger = require('morgan');
  const apikey = ('hary');
const CFonts = require('cfonts');
const mime = require('mime-types');
const yt = require('yt-converter')
const {
    color
} = require('./lib/color')
const owner = ('6282273128721@c.us');
//const config = ('hary.json')
//const bgapi = config.api

/* Cara Mudah Install This Tools


npm i express-session cookie-parser  express-ejs-layouts passport connect-flash node-schedule fs memorystore express-rate-limit morgan cfonts mime-types yt-converter express http ytdl-core child_process qrcode-terminal whatsapp-web.js axios spinnies path jszip


*/









const socketIO = require('socket.io');
const express = require('express');
const port = process.env.PORT || 8000;
    
const app = express();
const http = require ('http')
const server = http.createServer(app);
const io = socketIO(server);
/*
app.get('/', (req, res) => {
  res.sendFile('index.html', {
    root: __dirname
  });
});

*/













const ytdl = require('ytdl-core');
const { spawn } = require('child_process')
  const qrcode = require('qrcode-terminal');
  //const qrcode = require('qrcode');
  const { Client, MessageMedia, LocalAuth, Buttons, GroupChat, Util,chat ,List} = require('whatsapp-web.js');
  const filename = new Date().getTime();
  const axios = require('axios');
  //const SESSION_FILE_PATH = 'session.json';
  const fs = require('fs');
const Spinnies = require('spinnies')
//const msgHandler = require('./utils/msgHandler')
//const {myFiglet} = require('./utils/utils')
const spinnies = new Spinnies()
const Path = require('path')  
  const client = new Client({
  restartOnAuthFail: true,
   authStrategy: new LocalAuth(), 
   puppeteer: {  
     // executablePath: '/usr/bin/google-chrome',
         //  executablePath: '/usr/bin/google-chrome-stable',
          executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
       args: ['--no-sandbox'],
       headless: false ,
    }
  });



if(!fs.existsSync('./.wwebjs_auth/')){
    spinnies.add('generateQr', {text: 'Generating QR Code'})
    // Generate QR code
   client.on('qr', qr => {
    qrcode.generate(qr, {small: true});

        spinnies.succeed('generateQr', {text: 'QR Code Generated'})
        spinnies.add('Connecting', { text: 'Connecting'})
    })
} else {
    spinnies.add('Connecting', { text: 'Connecting'})
}




client.on('qr', qr => {
    qrcode.generate(qr, {small: true});
});

  client.on('authenticated', () => {
      console.log('AUTHENTICATED'); 
  });

  client.on('auth_failure', msg => {
      // Fired if session restore was unsuccessful
      console.error('AUTHENTICATION FAILURE', msg);
  });

  client.on('ready', () => {
     
      console.clear()
 
console.log(color('=> Source code version:', 'yellow'), color('Hary X Rina v1.1', 'cyan'))
console.log(color('=> Bug? Error? Suggestion? Visit here:', 'yellow'), color('https://instagram.com/haryonokudadiri'))
console.log(color(`SYSTEM`,'cyan'), color(`BOT is now online!`, 'green'))
console.log(color('[DEV]', 'cyan'), color('Welcome back, Owner! Hope you are doing well~', 'blue'))

    spinnies.succeed('Connecting', { text: 'Connected!', successColor: 'greenBright' })
  });

  client.on('message', async msg => {
    const contact = await msg.getContact();
        console.log(color('[','white'), color('!'), color(']','white'),`  ${contact.pushname} : ${msg.body}`);

  });


client.on("message_create", (msg) => {
    if (msg.body === 'me'){
    if (msg.fromMe) {
      let filename = `./downloads/logo.png` // you will get file with path using parametes
      const media = MessageMedia.fromFilePath(filename);
      chat.sendMessage(req.query.message);
      chat.sendMessage(media);
    }}
  })

  client.on('message',async message => {
    const chats = await message.getChat();
  

    client.sendSeen(message.from)
  const content = message.body
const from = message.from
 const contact = await message.getContact(); 
const author = message.author

        let chat = await message.getChat();
        chat.sendSeen();   

 
//===================================  STICKER ====================================///


        if(message.body === 'sticker'){
                if(message.hasMedia){
                    message.downloadMedia().then(media => {
                        if (media) {
                            const mediaPath = './tmp';
                            if (!fs.existsSync(mediaPath)) {
                                fs.mkdirSync(mediaPath);
                            }
                            const extension = mime.extension(media.mimetype);
                            const filename = new Date().getTime();
                            const filename1 = mediaPath + filename + '.' + extension;
                            try {
                                fs.writeFileSync(filename1, media.data, {encoding: 'base64'});
                                MessageMedia.fromFilePath(filePath = filename1)
                                client.sendMessage(message.from, new MessageMedia(media.mimetype, media.data, filename), {sendMediaAsSticker: true,stickerAuthor:"Make Your Heart Comfortable",stickerName:"HARY-IT"})
                                fs.unlinkSync(filename1)
                            } catch (err) {
                                console.log(err);
                            }
                        }
                    });
                }
            }
        
    if(message.body === 'stiker'){
                if(message.hasMedia){
                    message.downloadMedia().then(media => {
                        if (media) {
                            const mediaPath = './tmp';
                            if (!fs.existsSync(mediaPath)) {
                                fs.mkdirSync(mediaPath);
                            }
                            const extension = mime.extension(media.mimetype);
                            const filename = new Date().getTime();
                            const filename1 = mediaPath + filename + '.' + extension;
                            try {
                                fs.writeFileSync(filename1, media.data, {encoding: 'base64'});
                                MessageMedia.fromFilePath(filePath = filename1)
                                client.sendMessage(message.from, new MessageMedia(media.mimetype, media.data, filename), {sendMediaAsSticker: true,stickerAuthor:"Make Your Heart Comfortable",stickerName:"HARY-IT"})
                                fs.unlinkSync(filename1)
                            } catch (err) {
                                console.log(err);
                            }
                        }
                    });
                }
            }
        

else if (message.body === ('msg')){
    message.reply('Untuk Mengirim Pesan Rahasia ketik  _msg 628xxxxxx pesan kamu_')
    message.reply('ex _msg 6282273128721 Hai :)_')
}
else if (message.body.startsWith('msg')){

const petik = '```'
const miring = '_'
const number = message.body.split(' ')[1]
    const id = `@c.us`
    //const tag = message.body.split(' ')[1]
 
    

    let nomor
    if (number.includes('@')){
        nomor = number.slice(1)}else{
            nomor = number
            
        }
    
    const messageIndex = message.body.indexOf(number) + number.length;
    const pesan = message.body.slice(messageIndex, message.body.length);
    //const pesan = message.body.slice(18)


const chat = await message.getChat();
 if (!chat.isGroup){
            return   
            console.log('MSG ON PRIVATE CHAT ONLY')
        }




    client.sendMessage(`${nomors}`,`${petik}Hallo Anda Mendapat Pesan:${petik}`)
    client.sendMessage(`${nomors}`,`${pesan}`)
    client.sendMessage(`${owner}`,`${contact.pushname} / ${from} Mengirim Pesan Kepada ${link} dengan Pesan ${petik}${pesan}${petik}`)
    message.reply(`Sukses Mengirim Pesan Kepada ${link}` )
}


  



//===================================  STICKER ====================================///








    else if(content === "meme" ){

        const meme = await axios ("https://meme-api.herokuapp.com/gimme")
        .then(res => res.data)

        client.sendMessage(message.from, await MessageMedia.fromUrl(meme.url))

    }else if (content=== "jokes"){
            const joke = await axios ("https://v2.jokeapi.dev/joke/Any?safe-mode")
            .then (res => res.data)

            const jokeMsg = await client.sendMessage(message.from, joke.setup || joke.joke)
            if(joke.delivery) setTimeout(function()
                {jokeMsg.reply(joke.delivery)},5000)}

        else if (content=== "cecan")
                     {

                     const media = await MessageMedia.fromUrl ('https://haryonokudadiri.pw/api/cecan?apikey=hary');


     
                  client.sendMessage(message.from,media)
                   }
                   else if (content=== "cecandoc")
                     {

                     const media = await MessageMedia.fromUrl ('https://haryonokudadiri.pw/api/cecan?apikey=hary');


     
                  client.sendMessage(message.from,media,{sendMediaAsDocument: true})
                   }


                  

 else if (content=== "asupan")
                     {

                     const media = await MessageMedia.fromUrl ('https://haryonokudadiri.pw/api/asupan?apikey=hary');


     
                  client.sendMessage(message.from,media, { sendMediaAsDocument: true })
                   }

                   else if (content=== "bocil")
                     {

                     const media = await axios ('https://haryonokudadiri.pw/api/asupan/bocilmeresahkan?apikey=hary')
                     .then(res => res.data)

     
                  client.sendMessage(message.from, await MessageMedia.fromUrl(media.result, { sendMediaAsDocument: true }))
                   }














else if(message.body === 'hidetag') {
        
const chat = await message.getChat();
 if (!chat.isGroup){
            return message.reply(`gunakan *hidetag* hanya saat didalam grup chat!`);
        }

        let text = "";
        let mentions = [];

        for(let participant of chat.participants) {
            const contact = await client.getContactById(participant.id._serialized);
            
            mentions.push(contact);
            text += `@${participant.id.user} `;
        }

        await chat.sendMessage(text, { mentions });
    }


//=====================================================================//




else if (message.body === '!ytmp3'){
    message.reply('_Linknya?_')
}




// ========================================== stiker =============================//








/*
else if (message.body === 'sticker'){
    message.reply('Kirim Gambar dengan Caption sticker')
}
*/









// =============================== stiker ==========================================//

















//---------------------------------------------YTMP3 WORKS -------------------------------------------//

else if (message.body.startsWith('!ytmp3 ')) {

    message.reply('_Okee.._')
    const link = message.body.slice(7)
    const id = link.split('=')[1]

    async function ytmp3(link){
    const getIngfo = ytdl.getBasicInfo(link).then(info => {
        return {
            thumb: info.videoDetails.thumbnails[3]['url'],
            author: info.videoDetails.ownerChannelName,
            view: info.videoDetails.viewCount,
            title: info.videoDetails.title,
            likes: info.videoDetails.likes
        }
        })

    function downDir() {
            if (!fs.existsSync('./downloads/')){
                fs.mkdirSync('./downloads')
            } else { }
        } downDir()

    const ingfo = await getIngfo
    const hatiku = (ingfo.title)
    ytdl(link, {quality: '140', filter: 'audioonly', })
        .pipe(fs.createWriteStream(`./downloads/${id}.mp3`))
        .on('finish', async () => {
            const thumb = await MessageMedia.fromUrl(ingfo.thumb)
const oldPath = Path.join(__dirname, `./downloads/${id}.mp3`)  
const newPath = Path.join(__dirname, `./downloads/${hatiku}.mp3`)

 fs.renameSync(oldPath, newPath) 
                const media = MessageMedia.fromFilePath(`./downloads/${hatiku}.mp3`)

 //var fs = require("fs"); // Load the filesystem module
var stats = fs.statSync(`./downloads/${hatiku}.mp3`)
var fileSizeInBytes = stats.size;
const allow_size = 15;
// Convert the file size to megabytes (optional)
var fileSizeInMegabytes = fileSizeInBytes / (1024*1024);
    if (fileSizeInMegabytes > allow_size) {
        console.log(`Batas Maximum File Adalah ${allow_size} MB`)
        message.reply(`Batas Maximum Pengiriman File Audio Adalah ${allow_size} Mb , Mencoba Mengirim Dalam ZIP File ...`)
        const JSZip = require('jszip');

            const zip = new JSZip();

try {
    const hary = fs.readFileSync(`./downloads/${hatiku}.mp3`);
    zip.file(`${hatiku}.mp3`, hary);

    zip.file("Readme.txt", "HARY-IT - Make Your Heart Comfortable\n");

     const haryY = fs.readFileSync('./downloads/logo.png');
    zip.file("hary.png", haryY);

    zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
        .pipe(fs.createWriteStream(`./downloads/${hatiku}.zip`))
        .on('finish', function () {
            console.log(`${hatiku}.zip created.`);
            const media = MessageMedia.fromFilePath(`./downloads/${hatiku}.zip`)
                console.log(`   Sending ${hatiku}.zip`)
                client.sendMessage(message.from, media , { sendMediaAsDocument: true })
        });

} catch (err) {
    console.error(err)
}






    }else{
        console.log('Okee')
                client.sendMessage(message.from, media , { sendMediaAsDocument: true })
                console.log(`Sending ${hatiku}.mp3`)
    }
             
                
        })
        }

    ytmp3(link)
}


else if (message.body.startsWith('!ytmp4 ')) {


    message.reply('⏳ _Tunggu sebentar!_')
    let link = message.body.slice(7)
    let id
    if (link.includes('youtu.be')){
        id = link.split('/')[3]
    } else if (link.includes('youtube.com')){
        id = link.split('=')[1]
    } else {
        chat.sendMessage('_Sertakan link youtube yang benar! [youtu.be / youtube.com]_')
    }
    async function yttmp4(id){
        const getIngfo = ytdl.getBasicInfo(id).then(info => {
            return {
                author: info.videoDetails.ownerChannelName,
                view: info.videoDetails.viewCount,
                title: info.videoDetails.title,
                likes: info.videoDetails.likes
            }
        })

        function downDir() {
            if (!fs.existsSync('./downloads/')){
                fs.mkdirSync('./downloads')
            } else { }
        } downDir()

        const ingfo = await getIngfo
        const hatiku = (ingfo.title)
        ytdl(id, {quality: 'highest', filter: 'videoandaudio', })
            .pipe(fs.createWriteStream(`./downloads/${id}.mp4`))
            .on('finish', async () => {
/*
const oldPath = Path.join(__dirname, `./downloads/${id}.mp4`)  
const newPath = Path.join(__dirname, `./downloads/${hatiku}.mp4`)

 fs.renameSync(oldPath, newPath) 
*/
const JSZip = require('jszip');


const zip = new JSZip();

try {
    const hary = fs.readFileSync(`./downloads/${id}.mp4`);
    zip.file(`${hatiku}.mp4`, hary);

    zip.file("Readme.txt", "HARY-IT - Make Your Heart Comfortable\n");

     const haryY = fs.readFileSync('./downloads/logo.png');
    zip.file("hary.png", haryY);

    zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
        .pipe(fs.createWriteStream(`./downloads/${hatiku}.zip`))
        .on('finish', function () {
            console.log(`${hatiku}.zip created.`);
            const media = MessageMedia.fromFilePath(`./downloads/${hatiku}.zip`)
                console.log(`   Sending ${hatiku}.zip`)
                client.sendMessage(message.from, media , { sendMediaAsDocument: true })
        });

} catch (err) {
    console.error(err)
}







/*
 const jokeMsg = await client.sendMessage(message.from,`Create ${hatiku} to zip`)
 const media = MessageMedia.fromFilePath(`./downloads/${hatiku}.zip`);
              //  console.log(`   Sending ${hatiku}.zip`)
                //client.sendMessage(message.from, media , { sendMediaAsDocument: true })
            if ('finish') setTimeout(function()
                {jokeMsg.reply(media)},5000
                )

chat.sendMessage(media);
 
*/







               
            }) 
    }
    yttmp4(id)
}


//========================================== YTMP3 WORKS ====================================================================//


else if (message.body === '!buttons') {
        let button = new Buttons('Button body',[{body:'bt1'},{body:'bt2'},{body:'bt3'}],'title','footer');
        client.sendMessage(message.from, button);
    } else if (message.body === '!list') {
        let sections = [{title:'sectionTitle',rows:[{title:'ListItem1', description: 'desc'},{title:'ListItem2'}]}];
        let list = new List('List body','btnText',sections,'Title','footer');
        client.sendMessage(message.from, list);
    } else if (message.body === '!reaction') {
        message.react('🥱');
    }


else if (message.body.startsWith('setstatus ')) { 
     if (!chats.isGroup){
      
         if (from === owner){
       const newStatus = message.body.slice(10);
      return await client.setStatus(newStatus);
        message.reply(`Status was updated to *${newStatus}*`);
    } message.react('🗿');
} if (author === owner){
       const newStatus = message.body.slice(10);
      return await client.setStatus(newStatus);
        message.reply(`Status was updated to *${newStatus}*`);
    } message.react('🗿');
}



else if (message.body.startsWith('setname ')) {
   if (!chats.isGroup){
      
         if (from === owner){
       const newStatus = message.body.slice(8);
      return await client.setStatus(newStatus);
        message.reply(`Name was updated to *${newStatus}*`);
    } message.react('🗿');
} if (author === owner){
       const newStatus = message.body.slice(8);
      return await client.setDisplayName(newStatus);
        message.reply(`Name was updated to *${newStatus}*`);
    } message.react('🗿');
    
}




else if(message.body === 'wget'){
    message.reply('_Link?_')
}



else if (message.body.startsWith('wget')) {

   
    message.reply('_Tunggu sebentar Yaa!_')
    //const domain = message.body.slice(5)
    const domain = message.body.split(' ')[1] 
    const outputs = `./downloads/pekop`
    const knockpath = './hary/knockpy.py'
    const filename = new Date().getTime();
const file = message.body.split(' ')[2] 
    if(!fs.existsSync(outputs)){
        fs.mkdirSync(outputs)
    }



var src = `${domain}`;
var output = `${filename}.${file}`;



 const child = spawn('wget', [`-O ${output} ${domain}`], {shell: true});
// Wget Configuration //



// =============================================//

if (message.reply ===('Download')) {
          
 let button = new Buttons('Button body',[{body:'bt1'},{body:'bt2'},{body:'bt3'}],'title','footer');
        client.sendMessage(message.from, button);
const JSZip = require('jszip');


const zip = new JSZip()

try {
    const hary = fs.readFileSync(`${filename}.${file}`);
    zip.file(`${filename}.${file}`, hary);

    zip.file("Readme.txt", "HARY-IT - Make Your Heart Comfortable\n");

     const haryY = fs.readFileSync('./downloads/logo.png');
    zip.file("hary.png", haryY);

    zip.generateNodeStream({ type: 'nodebuffer', streamFiles: true })
        .pipe(fs.createWriteStream(`./downloads/${filename}.zip`))
        .on('finish', function () {
            console.log(`${filename}.zip created.`);
            const media = MessageMedia.fromFilePath(`./downloads/${filename}.zip`)
                console.log(`   Sending ${filename}.zip`)
                client.sendMessage(message.from, media , { sendMediaAsDocument: true })
        });

} catch (err) {
    console.error(err)
}

/*
          const media = MessageMedia.fromFilePath(`hary.${file}`);
          console.log(`   Sending`)
                client.sendMessage(message.from, media , { sendMediaAsDocument: true })
        });*/
            } else {
                message.reply('I can only delete my own messages');
            }
  
        }
    




  else if (message.body === 'del') {
 if (message.hasQuotedMsg) {
            const quotedMsg = await message.getQuotedMessage();
            if (quotedMsg.fromMe) {
                quotedMsg.delete(true);
            } else {
                message.reply('I can only delete my own messages');
            }
        }}





//Private Message //
else if (message.body === 'Harry'){

    if (from === '6283165030458@c.us'){
        return message.reply('dalem din')}
    else if (from === '6282273128721@c.us'){
        return message.reply('Hallo Harry')
    }
    else if (from === '6281364124664@c.us'){
        return message.reply('dalem rin')}
     message.reply('Iya?')

}
else if (message.body === 'Hary'){

    if (from === '6283165030458@c.us'){
        return message.reply('dalem din')}
    else if (from === '6282273128721@c.us'){
        return message.reply('Hallo Harry')
    }
    else if (from === '6281364124664@c.us'){
        return message.reply('dalem rin')}
     message.reply('Iya?')

}
else if (message.body === 'hary'){

    if (from === '6283165030458@c.us'){
        return message.reply('dalem din')}
    else if (from === '6282273128721@c.us'){
        return message.reply('Hallo Harry')
    }
    else if (from === '6281364124664@c.us'){
        return message.reply('dalem rin')}
     message.reply('Iya?')

}
else if (message.body === 'Hary'){

    if (from === '6283165030458@c.us'){
        return message.reply('dalem din')}
    else if (from === '6282273128721@c.us'){
        return message.reply('Hallo Harry')
    }
    else if (from === '6281364124664@c.us'){
        return message.reply('dalem rin')}
     message.reply('Iya?')

}


//Private Message //





else if (message.body === 'button'){


const TEST_JID = message.from // modify
//const TEST_GROUP = 'GROUP_ID'; // modify
const buttons_reply = new Buttons('test', [{body: 'Test', id: 'test-1'}], 'title', 'footer') // Reply button

//const buttons_reply_url = new Buttons('test', [{body: 'Test', id: 'test-1'}, {body: "Test 2", url: "https://wwebjs.dev"}], 'title', 'footer') // Reply button with URL

const buttons_reply_call = new Buttons('test', [{body: 'Test', id: 'test-1'}, {body: "Test 2 Call", url: "+1 (234) 567-8901"}], 'title', 'footer') // Reply button with call button

//const buttons_reply_call_url = new Buttons('test', [{body: 'Test', id: 'test-1'}, {body: "Test 2 Call", url: "+1 (234) 567-8901"}, {body: 'Test 3 URL', url: 'https://wwebjs.dev'}], 'title', 'footer') // Reply button with call button & url button

const section = {
  title: 'HARY-IT - Make Your Heart Comfortable',
  rows: [
    {
      title: 'Test 1',
    },
    {
      title: 'Test 2',
      id: 'test-2'
    },
    {
      title: 'Test 3',
      description: 'This is a smaller text field, a description'
    },
    {
      title: 'Test 4',
      description: 'This is a smaller text field, a description',
      id: 'test-4',
    }
  ],
};

// send to test_jid
for (const component of [buttons_reply,  buttons_reply_call]) client.sendMessage(TEST_JID, component);

// send to test_group
//for (const component of [buttons_reply, buttons_reply_url, buttons_reply_call, buttons_reply_call_url])client.sendMessage(TEST_GROUP, component);

const list = new List('test', 'click me', [section], 'title', 'footer')
client.sendMessage(TEST_JID, list);
//client.sendMessage(TEST_GROUP, list);

client.on("message", (message) => {
if(message.type === 'list_response'){
message.reply(`You've selected ${message.body}`)
}
});

}

else if (message.body === 'docxtopdf' && message.hasQuotedMsg){
    message.reply('_Tunggu sebentar Yaa_')

const axios = require('axios')
const FormData = require('form-data')
const fs = require('fs')
const quotedMsg = await message.getQuotedMessage();
    if (quotedMsg.hasMedia) {
            quotedMsg.downloadMedia().then(media => {
                if (media) {
                    const mediaPath = './downloads/';
                    if (!fs.existsSync(mediaPath)) {
                        fs.mkdirSync(mediaPath);
                    }
                    const extension = mime.extension(media.mimetype);
                
                    const filename = new Date().getTime();
                
                    const fullFilename = mediaPath + filename + '.' + extension;
                    const haryapi = `${config.api}`
                    // Save to file
                    try {
                        fs.writeFileSync(fullFilename, media.data, { encoding: 'base64' });
                        console.log('File downloaded successfully!', fullFilename);
                        console.log(fullFilename);
                        MessageMedia.fromFilePath(filePath = fullFilename);




const formData = new FormData()
formData.append('instructions', JSON.stringify({
  parts: [
    {
      file: "document"
    }
  ]
}))
formData.append('document', fs.createReadStream('1.docx'))

;(async () => {
  try {
    const response = await axios.post('https://api.pspdfkit.com/build', formData, {
      headers: formData.getHeaders({
          'Authorization': 'Bearer pdf_live_I8Mul0N9hgq1hoeQdCEVadJAQWu9inVTGnb19WUUJIy'
      }),
      responseType: "stream"
    })

    response.data.pipe(fs.createWriteStream("result.pdf"))
  } catch (e) {
    const errorString = await streamToString(e.response.data)
    console.log(errorString)
  }
})()

function streamToString(stream) {
  const chunks = []
  return new Promise((resolve, reject) => {
    stream.on("data", (chunk) => chunks.push(Buffer.from(chunk)))
    stream.on("error", (err) => reject(err))
    stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")))
  })
}





}
  
                        catch (err) {
                            console.log('Failed to save the file:', err);
                            console.log(`File Deleted successfully!`,);
                    }
}

//
})}}




else if (content === ('nobg')){
    message.reply('_Tunggu sebentar Yaa_')


const path = require('path') 
const FormData = require('form-data');
const inputPath = '/path/to/file.jpg';
const formData = new FormData();
 if(message.hasMedia){
            message.downloadMedia().then(media => {
                if (media) {
                    const mediaPath = './downloads/';
                    if (!fs.existsSync(mediaPath)) {
                        fs.mkdirSync(mediaPath);
                    }
                    const extension = mime.extension(media.mimetype);
                
                    const filename = new Date().getTime();
                
                    const fullFilename = mediaPath + filename + '.' + extension;
                    const haryapi = `${config.api}`
                    // Save to file
                    try {
                        fs.writeFileSync(fullFilename, media.data, { encoding: 'base64' });
                        console.log('File downloaded successfully!', fullFilename);
                        console.log(fullFilename);
                        MessageMedia.fromFilePath(filePath = fullFilename);

                    formData.append('size', 'auto');
formData.append('image_file', fs.createReadStream(fullFilename), path.basename(fullFilename));

axios({
  method: 'post',
  url: 'https://api.remove.bg/v1.0/removebg',
  data: formData,
  responseType: 'arraybuffer',
  headers: {
    ...formData.getHeaders(),
    'X-Api-Key': 'jo7sfS2p15iePwT3ugGDzK2D',
  },
  encoding: null
})
.then((response) => {
  if(response.status != 200) return console.error('Error:', response.status, response.statusText);
  fs.writeFileSync(`${fullFilename}`, response.data);
  const rina = MessageMedia.fromFilePath(fullFilename)
                        client.sendMessage(message.from,rina,{sendMediaAsDocument:true} );
                        fs.unlinkSync(fullFilename);
                        console.log(`File Deleted successfully!`,);
})
.catch((error) => {
    return console.error('Request failed:', error);
});




                      
                    } 
                        catch (err) {
                            console.log('Failed to save the file:', err);
                            console.log(`File Deleted successfully!`,);
                    }
}

//

})}


}




else if (content.startsWith ('bg')){
    message.reply('_Tunggu sebentar Yaa_')
    const color = message.body.split('/')[1];


const path = require('path') 
const FormData = require('form-data');
const inputPath = '/path/to/file.jpg';
const formData = new FormData();
 if(message.hasMedia){
            message.downloadMedia().then(media => {
                if (media) {
                    const mediaPath = './downloads/';
                    if (!fs.existsSync(mediaPath)) {
                        fs.mkdirSync(mediaPath);
                    }
                    const extension = mime.extension(media.mimetype);
                
                    const filename = new Date().getTime();
                
                    const fullFilename = mediaPath + filename + '.' + extension;
                    const haryapi = `${config.api}`
                    // Save to file
                    try {
                        fs.writeFileSync(fullFilename, media.data, { encoding: 'base64' });
                        console.log('File downloaded successfully!', fullFilename);
                        console.log(fullFilename);
                        MessageMedia.fromFilePath(filePath = fullFilename);

                    formData.append('size', 'auto');
                    formData.append(`bg_color`,color)
                    formData.append('image_file',
                     fs.createReadStream(fullFilename), 
                     path.basename(fullFilename));

axios({
  method: 'post',
  url: 'https://api.remove.bg/v1.0/removebg',
  data: formData,
  responseType: 'arraybuffer',
  headers: {
    ...formData.getHeaders(),
    'X-Api-Key': 'jo7sfS2p15iePwT3ugGDzK2D',
  },
  encoding: null
})
.then((response) => {
  if(response.status != 200) return console.error('Error:', response.status, response.statusText);
  fs.writeFileSync(`${fullFilename}`, response.data);
  const rina = MessageMedia.fromFilePath(fullFilename)
                        client.sendMessage(message.from,rina,{sendMediaAsDocument:true} );
                        fs.unlinkSync(fullFilename);
                        console.log(`File Deleted successfully!`,);
})
.catch((error) => {
    return console.error('Request failed:', error);
});




                      
                    } 
                        catch (err) {
                            console.log('Failed to save the file:', err);
                            console.log(`File Deleted successfully!`,);
                    }
}

//

})}


}













//================================================ test =====================================================//



else if (message.body.startsWith('ytmxxp3')){ //if your link youtube.com/xxxx

    message.reply('_Wait!_')
    const link = message.body.slice(6)
    const id = link.split('=')[1]


                     const media = await axios (`https://haryonokudadiri.pw/api/download/ytmp3?url=${link}&apikey=${apikey}`)
                     .then(res => res.data)

     
                  client.sendMessage(message.from, await MessageMedia.fromUrl(media.result, { sendMediaAsDocument: true }))
        

}/*
else if (message.body.startsWith('yytmp3')){ //don't remove this code to see link youtube valid or no

    message.reply('_Wait!_')
    const link = message.body.slice(7)
    const id = link.split('=')[1]

 const media =  (`https://haryonokudadiri.pw/api/download/ytmp4?url=${link}&apikey=${apikey}`);


     
                  client.sendMessage(message.from,media)
                   
        

}*/

else if (message.body.startsWith('ytmp4be')){ //if your link youtu.be/xxx

    message.reply('_Wait!_')
    const link = message.body.slice(7)
    const id = link.split('=')[1]

 const media = await axios (`https://haryonokudadiri.pw/api/download/ytmp4?url=${link}&apikey=${apikey}`)
                     .then(res => res.data)

     
                  client.sendMessage(message.from, await MessageMedia.fromUrl(media.result, { sendMediaAsDocument: true}) )
                   
        

}
else if (message.body.startsWith('ytmp4XX')){ //if your link youtu.be/xxx

    message.reply('_Wait!_')
    const link = message.body.slice(6)
    const id = link.split('=')[1]

 const media = await axios (`https://haryonokudadiri.pw/api/download/ytmp4?url=${link}&apikey=${apikey}`)
                     .then(res => res.data)

     
                  client.sendMessage(message.from, await MessageMedia.fromUrl(media.result, { sendMediaAsDocument: true }))
                   
        

}





//=======================================================================//


      //                nsfw menu 

else if 

 ( from === `${author}` ) {
        return 

          if  ( content === "q" ) {

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/cecan?apikey=hary")
      
     client.sendMessage(message.from,media)
                
           }
        
                    
    
     else if (content === "ass"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/ass?apikey=hary")
      

     client.sendMessage(message.from,media)}
    
}

/*
     else if (content === "ahegao"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/ahegao?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "bdsm"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/bdsm?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "blowjob"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/blowjob?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "cukold"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/cukold?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "cum"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/cum?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "ero"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/ero?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "femdom"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/femdom?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content === "foot"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/foot?apikey=hary")
      
     client.sendMessage(message.from,media)
    }

     else if (content === "gangbang"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/gangbang?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content=== "glasses"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/glasses?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content=== "hentai"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/hentai?apikey=hary")
      

     client.sendMessage(message.from,media)
    }

     else if (content=== "jahy"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/jahy?apikey=hary")
      
     client.sendMessage(message.from,media)
    }
 else if (content=== "masturbation"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/masturbation?apikey=hary")
      

     client.sendMessage(message.from,media)

    }
     else if (content=== "neko"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/nsfwNeko?apikey=hary")
      

     client.sendMessage(message.from,media)
    }
     else if (content=== "panties"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/panties?apikey=hary")
      

     client.sendMessage(message.from,media)
    }
     else if (content=== "pussy"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/pussy?apikey=hary")
      

     client.sendMessage(message.from,media)
    }
     else if (content=== "thighs"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/thighs?apikey=hary")
      

     client.sendMessage(message.from,media)
    }
     else if (content=== "yuri"){

          const media = await MessageMedia.fromUrl  ("https://haryonokudadiri.pw/api/nsfw/yuri?apikey=hary")
      

     client.sendMessage(message.from,media)


}*/








else if (message.body === 'cc'){
    const media = await MessageMedia.fromUrl('https://haryonokudadiri.pw/api/cecan?apikey=hary')
    client.sendMessage(message.from,media);
    
}















// ====================================           End Of nsfw           ===================================  //


//=====================================          Start Menu                   ======================================//

else if (message.body == `menu`)  {
  const petik = '```'
    message.reply(`✇ *REST API*
https://haryonokudadiri.pw/

╭─❒ *INFO BOT* 
├◪
│❒ ${petik}𝖭𝖺𝗆𝖺  : HARY-IT${petik}
│❒ ${petik}Author : HARY-IT${petik}
│❒ ${petik}Server : WhatsApp-Web.js${petik}
│❒ ${petik}Instagram : https://Instagram.com/haryonokudadiri${petik}
│❒${petik}Facebook : https://facebook.com/haryono.franskudir.96${petik}
│❒${petik}Github : https://github.com/MltrCyber${petik}
│❒${petik}WhatsApp : https://wa.me/6282273128721${petik}
│❒${petik}Website : https://haryonokudadiri.pw${petik}
│❒${petik}Telegram : https:/t.me/haryonokudadiri${petik}
╰───────────────┈ ⳹

╭─❒ *DOWNLOAD MENU* 
├◪
│❒ ${petik}!ytmp3 (Dowload audio/MP3 from youtube)${petik}
│❒ ${petik}!ytmp4 (Download Video Youtube All video support)${petik}
│❒ ${petik}ttmu (Download Video Tiktok No Watermark)${petik}
╰───────────────┈ ⳹

╭─❒ *WEBSITE SERVER MENU*
├◪ ${petik}. (Manage server With WhatsApp Bot)${petik}
├◪ ${petik}send (kirim File Dari Server filePath)${petik}
├◪ ${petik}add (add namauser namawebsite {Membuat User Dan Menambahkan Domain Costum})${petik}
├◪ ${petik}delete (menghapus domain) Ex : delete hary.cloud${petik}
├◪ ${petik}deluser (menghapus user ) Ex : deluser namauser${petik}
├◪ ${petik}restart (Restart Bot If Down${petik}
├◪ ${petik}Coming Soon${petik}
╰───────────────┈ ⳹
╭─❒ *OTHER MENU* 
├◪
│❒ ${petik}menu${petik}
│❒ ${petik}meme${petik}
│❒ ${petik}jokes${petik}
│❒ ${petik}cecan${petik}
│❒ ${petik}hidetag${petik}
│❒ ${petik}bocil${petik}
│❒ ${petik}infogrup${petik}
│❒ ${petik}sticker${petik}
│❒ ${petik}author${petik}
│❒ ${petik}nobg${petik}
│❒ ${petik}edit/warna${petik}
│❒ ${petik}${petik}
│❒ ${petik} ${petik}
│❒ ${petik} ${petik}
╰───────────────┈ ⳹
`)
  }


else if (message.body === ('author')){
    client.sendMessage(message.from,('https://instagram.com/haryonokudadiri'))
}



else if(message.body === ('restart')){
    
   if (!chats.isGroup){
      
         if (from === owner){
      
//here your codec
client.sendMessage('62882017496449@c.us','restart')

 } message.react('🗿');
} if (author === owner){
  client.sendMessage('62882017496449@c.us','restart')

//here your code

   
}

message.react('🗿');

}


// ===================================================================================================================//
   else if(message.body === '-cmd') {
        client.sendMessage(message.from, `*Perintah Umum*` + "\n" +
                                     `*-sticker* untuk mengkonversi gambar ke stiker` + "\n" + 
                                     `*-cmd* untuk menampilkan pesan ini` + "\n" +
                                     `*Perintah Grup*` + "\n" +
                                     `*-everyone* mention semua orang dalam grup` + "\n" +
                                     `*-infogrup* menampilkan informasi grup`);
    }

    //sticker command
    else if(message.body === 'sticker'){
       const quotedMsg = await message.getQuotedMessage();
    if (quotedMsg.hasMedia) {
            quotedMsg.downloadMedia().then(media => {
                if (media) {
                    const mediaPath = './downloads';
                    if (!fs.existsSync(mediaPath)) {
                        fs.mkdirSync(mediaPath);
                    }
                    const extension = mime.extension(media.mimetype);
                
                    const filename = new Date().getTime();
                
                    const fullFilename = mediaPath + filename + '.' + extension;
                
                    // Save to file
                    try {
                        fs.writeFileSync(fullFilename, media.data, { encoding: 'base64' });
                        console.log('File downloaded successfully!', fullFilename);
                        console.log(fullFilename);
                        MessageMedia.fromFilePath(filePath = fullFilename);
                        client.sendMessage(message.from, new MessageMedia(media.mimetype, media.data, filename), { sendMediaAsSticker: true,stickerAuthor:"Dibuat dengan cinta",stickerName:"Stickers"} );
                        fs.unlinkSync(fullFilename);
                        console.log(`File Deleted successfully!`,);
                    } 
                        catch (err) {
                            console.log('Failed to save the file:', err);
                            console.log(`File Deleted successfully!`,);
                    }
                }
            });
        }
        else {
            message.reply(`kirim gambar dengan caption *-sticker* `);
        }
    }

    //tag everyone
    else if(message.body === '-everyone') {
        if (!chat.isGroup){
            return message.reply(`gunakan *-everyone* hanya saat didalam grup chat!`);
        }
        
        let text = "";
        let mentions = [];

        for(let participant of chat.participants) {
            const contact = await client.getContactById(participant.id._serialized);
            
            mentions.push(contact);
            text += `@${participant.id.user} `;
        }

        await chat.sendMessage(text, { mentions });
    }

    //group info
    else if (message.body === 'infogrup') {
        if (chat.isGroup) {
            message.reply(`*Info Grup*`+"\n\n"+
            `Nama Grup: ${chat.name}`+"\n"+
            `Deskripsi: ${chat.description}`+"\n"+
            `Tgl Dibuat: ${chat.createdAt.toString()}`+"\n"+
            `Dibuat Oleh: ${chat.owner.user}`+"\n"+
            `Jumlah Member: ${chat.participants.length}`);
        } else {
            message.reply('gunakan *-infogrup* hanya saat didalam grup chat!');
        }
    }




else if (message.body.startsWith('ttmu')){

     message.reply('_Okee.._')
    const link = message.body.slice(5)
    const id = link.split('=')[1]

const media = await axios(`https://api.douyin.wtf/api?url=${link}`) //nwm_video_url_HQ  
.then (res => res.data)
client.sendMessage(message.from, await MessageMedia.fromUrl(media.video_data["nwm_video_url"],{sendMediaAsDocument:true
}))
   
}







else if(content.startsWith('.')){ //` ls //command line di awali dari spasi`

   const bash = message.body.slice(2)
if (!chats.isGroup){
      
         if (from === owner){
      

const { exec, spawn } = require('node:child_process');
const bat = spawn(`${bash}`, { shell: true });
return bat.stdout.on('data', (data) => {
console.log(data.toString())
client.sendMessage(message.from,data.toString())
});

bat.stderr.on('data', (data) => {});

bat.on('exit', (code) => {
 
});

    } message.react('🗿');
} if (author === owner){
      
const { exec, spawn } = require('node:child_process');
const bat = spawn(`${bash}`, { shell: true });
return bat.stdout.on('data', (data) => {
console.log(data.toString())
client.sendMessage(message.from,data.toString())
});

bat.stderr.on('data', (data) => {});

bat.on('exit', (code) => {
 
});
    } message.react('🗿');

}

else if(content.startsWith('send')){ //` ls //command line di awali dari spasi`

    const bash = message.body.split(' ')[1]


   if (!chats.isGroup){
      
         if (from === owner){
      
const media = MessageMedia.fromFilePath(`${bash}`)
return client.sendMessage(message.from,media)
    } message.react('🗿');
} if (author === owner){
      
const media = MessageMedia.fromFilePath(`${bash}`)
return client.sendMessage(message.from,media)
    } message.react('🗿');
    
}



else if(message.body === 'admin') {
    if (!isCreator) throw global.owner
        {
            return message.reply(`Perintah hanya dapat digunakan oleh Author!`);
        }
        client.sendMessage(message.from,('https://instagram.com/haryonokudadiri'))
        }







else if (message.body === ('chat')){
    message.reply('Untuk Mengirim Pesan Rahasia ketik  _msg 628xxxxxx pesan kamu_')
    message.reply('ex _msg 6282273128721 Hai :)_')
}
else if (message.body.startsWith('chat')){

const petik = '```'
const miring = '_'
const link = message.body.split(' ')[1]
    const id = `@c.us`
    //const tag = message.body.split(' ')[1]
 
    const pesan = message.body.slice(18)

const chat = await message.getChat();

 if (!chat.isGroup){
            return     client.sendMessage(`${link}${id}`,`${petik}Hallo Anda Mendapat Pesan:${petik}`)
    client.sendMessage(`${link}${id}`,`${pesan}`)
    client.sendMessage(`${author}`,`${contact.pushname} / ${from} Mengirim Pesan Kepada ${link} dengan Pesan ${petik}${pesan}${petik}`)
    message.reply(`Sukses Mengirim Pesan Kepada ${link}` )
        }




    client.sendMessage(`${link}`,`${petik}Hallo Anda Mendapat Pesan:${petik}`)
    client.sendMessage(`${link}`,`${pesan}`)
    client.sendMessage(`${author}`,`${contact.pushname} / ${from} Mengirim Pesan Kepada ${link} dengan Pesan ${petik}${pesan}${petik}`)
    message.reply(`Sukses Mengirim Pesan Kepada ${link}` )
}








//================================================== END MENU ====================================================//
        });

  client.initialize();
/*
const PORT = process.env.PORT || 80;
server.listen(PORT,()=>{
    console.log(`server Connected in port http://localhost:${PORT}`)
    client.on('authenticated', ()=>{
        console.log('auth success ...');
    })
    client.on('qr',(qr)=> {
        console.log(`SCAN THE RECEIVED`,qr)
    })
    client.on('ready',() => {
        console.log('Client is ready!')
    })
})*/